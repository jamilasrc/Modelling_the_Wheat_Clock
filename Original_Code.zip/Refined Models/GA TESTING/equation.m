function solved = equation(par,beta)

solved = (beta - par^2)^2;

end






