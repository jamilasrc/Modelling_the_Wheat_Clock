function outputs = parms_test(parms,data_in,data_period,var_correspond_wt,init_cond_wt)

%parms = parm_og;

data = data_in;

init_conditions_wheatwt = init_cond_wt;

LDLD_or_LDLL = "LDLD";
LD_cyc_typ = [30,0.75];
t_end = 480;

[~,sol_init_LD] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_wheatwt);
init_cond_upd = sol_init_LD(end,:);

%[~,sol_i_mut_ld] = ode15s(@(t,vars)wheat_elf3mut(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ), ...
%       [0,t_end],init_conditions_mut);
%init_cond_upd_mut = sol_i_mut_ld(end,:);
    
LDLD_or_LDLL = "LDLL";
[times_i,sol_i] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond_upd);

%[times_i_mut,sol_i_mut] = ode15s(@(t,vars)wheat_elf3mut(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ), ...
 %     [0,t_end],init_cond_upd_mut);

cost_wt = cost_function(data,data_period,times_i,sol_i,var_correspond_wt);
           
%cost_mut = cost_function(mutant_data,times_i_mut,sol_i_mut,var_correspond_mut);
            
%cost_out = cost_wt + cost_mut;

%outputs = cost_out;
outputs = 0.001*cost_wt;
%disp(outputs)

end 