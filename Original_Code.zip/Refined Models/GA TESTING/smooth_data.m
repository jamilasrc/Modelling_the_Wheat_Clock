function new_matrix = smooth_data(og_matrix,colms2mod,reps)

new_matrix = og_matrix;

true_reps = unique(og_matrix(:,1));

for col = colms2mod
    
    for r = reps 
        
        smooth_var = smooth(new_matrix(new_matrix(:,1) == r,2), ...
            new_matrix(new_matrix(:,1) == r,col),0.35,'loess');
        
        new_matrix(new_matrix(:,1) == r,col) = smooth_var;

    end

    new_matrix(new_matrix(:,col) < 0,col) = 0;
   
end

 rem_rep = true_reps; 
 rem_rep(ismember(rem_rep,reps)) = [];
    
 new_matrix(ismember(new_matrix(:,1),rem_rep),:) = [];
