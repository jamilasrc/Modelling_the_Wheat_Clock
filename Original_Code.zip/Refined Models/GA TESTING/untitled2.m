
parms(1) = 4.58;
parms(2) = 3.0; %3.0
parms(3) = 1.27;
parms(4) = 0.5;
parms(5) = 5.0;
parms(6) = 1.0;
parms(7) = 1.1;
%parms(7) = 2;
parms(8) = 1.1;
parms(9) = 1;
parms(10) = 2; % 1

parms(11) = 0.53;
parms(12) = 0.21;
parms(13) = 0.35;
parms(14) = 0.56;
parms(15) = 0.57;
parms(16) = 0.4;
parms(17) = 0.4;
parms(18) = 0.5;

parms(19) = 0.76;
parms(20) = 0.42;
parms(21) = 1.01;
parms(22) = 0.64;
parms(23) = 0.22; % 0.6
parms(24) = 0.6;
parms(25) = 0.6;
parms(26) = 0.8;
parms(27) = 0.68;
parms(28) = 0.5;
parms(29) = 0.29; % 0.29
parms(30) = 0.48; 
parms(31) = 0.38;
parms(32) = 1.2; % 1.21
parms(33) = 0.38; % 0.38
parms(34) = 0.5;
parms(35) = 0.8;
parms(36) = 0.5;
parms(37) = 0.8;
parms(38) = 0.7;
parms(39) = 0.7;
parms(40) = 0.6;

parms(41) = 2.80;
parms(42) = 0.16; %0.16
parms(43) = 1.18;
parms(44) = 0.5;
parms(45) = 0.2; % 0.24
parms(46) = 0.23; % 0.28
parms(47) = 0.63; % 0.57
parms(48) = 1.73; % 1.73
parms(49) = 0.46;
parms(50) = 0.5; 
parms(51) = 0.6;
parms(52) = 0.3;
parms(53) = 1.9;
parms(54) = 0.3;
parms(55) = 0.5;
parms(56) = 2.0;
parms(57) = 0.3;
parms(58) = 0.5;
parms(59) = 2.0;
parms(60) = 0.8; % 0.8
parms(61) = 1.9;

parms(62) = 1; % 1 2.5
parms(63) = 0.7;
parms(64) = 0.35; % 0.35 0.34
parms(65) = 0.2; % 0.2
parms(66) = 1;
parms(67) = 3; % 3 1

%parms_to_fit_s = parms;
parm_og = parms;
clear parms 

LHYm_init = 4.5;
LHYp_init = 4.5;
Pp_init = 3;
P95m_init = 0.9;
P95p_init = 0.9;
P73m_init = 1.5;
P73p_init = 1.5;
P5T1m_init = 0.6;
P5T1p_init = 0.6;
E4m_init = 0.5;
E4p_init = 0.5;
LUXm_init = 0.5;
LUXp_init = 0.5;
E3m_init = 1.3;
E3p_init = 1.3;
EC_init = 0.5;

init_cond_wt = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init];
init_cond_mut = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,EC_init];

webb_data_wt = readtable("webb_data_wt.csv"); 
webb_mat_wt = table2array(webb_data_wt);
webb_data_mut = readtable("webb_data_mut.csv"); 
webb_mat_mut = table2array(webb_data_mut);

webb_smooth_wt = smooth_data(webb_mat_wt,[3:8],[1,2,3]);
webb_smooth_mut = smooth_data(webb_mat_mut,[3:8],[1,2,3]);

plot(webb_smooth_wt(webb_smooth_wt(:,1) == 1,2), ...
    webb_smooth_wt(webb_smooth_wt(:,1) == 1,3:8))
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0]) 

plot(webb_smooth_wt(webb_smooth_wt(:,1) == 1,2), ...
    webb_smooth_wt(webb_smooth_wt(:,1) == 1,3), ...
    webb_smooth_mut(webb_smooth_mut(:,1) == 1,2), ...
    webb_smooth_mut(webb_smooth_mut(:,1) == 1,3))
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0]) 


w_wt_small = webb_smooth_wt;
w_wt_small(:,5) = [];

w_mut_small = webb_smooth_mut;
w_mut_small(:,[4,5]) = [];


%data_in = w_wt_small;
%data_in_mut = w_mut_small;

mat = zeros(length(1:3),length(3:7));
i = 1;
for v = 3:7
    for r = 1:3
        [~,tt] = findpeaks(w_wt_small(w_wt_small(:,1) == r,v));
        num_peak = length(tt);
        mat(i) = num_peak;
        i = i + 1;
    end
end 
      
peaks_wt = [];
av_period_wt = [];

for v = 3:7
    
    period_diffs = [];
    
    for r = 1:3
        
        clear mat_add
        
        sub_data = w_wt_small(w_wt_small(:,1) == r,[2,v]);
        [~,p_t] = findpeaks(sub_data(:,2));
        peak_timings = sub_data(p_t,1);

        if(v == 3)

            peak_diffs = [period_diffs;diff([0;peak_timings])];
            
        end

            mat_add = zeros(length(peak_timings),3);
            mat_add(:,1) = r;
            mat_add(:,2) = v;
            mat_add(:,3) = peak_timings;

            peaks_wt = [peaks_wt;mat_add];
    end 

    if(v == 3)
    av_period_wt = mean(peak_diffs);
    end 
   
end



clear sub_data
%sub_data = w_wt_small(w_wt_small(:,1) == 1,[2,3]);
%[~,p_t] = findpeaks(sub_data(:,2));
%peak_timings = sub_data(p_t,1);

var_correspond_wt = [3:7;1,14,12,6,8];
var_correspond_mut = [3:6;1,12,6,8];

options = optimoptions('gamultiobj','InitialPopulationMatrix',parm_og,'MaxGenerations',6700,'MaxStallGenerations',300,...
     'FunctionTolerance',1e-12,'ConstraintTolerance',1e-12);

lower_lims = zeros(1,67);
upper_lims = zeros(1,67);

for p = 1:length(parm_og)

    if(parm_og(p) >= 1) 
        upper_lims(p) = upper_lims(p) + 2;
    else 
        upper_lims(p) = 1;
    end

end

peaks_wt(48,:) = [];
data_in = peaks_wt;
data_period = av_period_wt;


[a0,fval,exitflag,output] = gamultiobj(@(parms)parms_test(parms,data_in,data_period, ...
    var_correspond_wt,init_cond_wt),67,[],[],[],[], ...
    lower_lims,upper_lims,[],options);

parms = a0;
parms = parm_og;
LD_cyc_typ = [30,0.75]; % LD cycle ratio
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD
t_end = 480;

% Run LDLD to get initial conditions
[t_wheatwt_ldld,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);

% Model Testing 
LDLD_or_LDLL = "LDLL";
[t_wheatwt,v_wheatwt] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_upd);
findpeaks(v_wheatwt(:,1),t_wheatwt);
plot(t_wheatwt,)

plot(t_wheatwt,v_wheatwt(:,1),t_wheatwt,v_wheatwt(:,14),t_wheatwt,v_wheatwt(:,8))
legend("LHY","ELF3","TOC1")
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])


%beta = 6;
%options = optimoptions('ga','InitialPopulationMatrix',6);
%answers = ga(@(par)equation(par,beta),1,[],[],[],[],[],[],[],[],options);


