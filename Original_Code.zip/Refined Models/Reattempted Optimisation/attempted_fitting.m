
parms(1) = 4.58;
parms(2) = 3.0; %3.0
parms(3) = 1.27;
parms(4) = 0.5;
parms(5) = 5.0;
parms(6) = 1.0;
parms(7) = 1.1;
%parms(7) = 2;
parms(8) = 1.1;
parms(9) = 1;
parms(10) = 2; % 1

parms(11) = 0.53;
parms(12) = 0.21;
parms(13) = 0.35;
parms(14) = 0.56;
parms(15) = 0.57;
parms(16) = 0.4;
parms(17) = 0.4;
parms(18) = 0.5;

parms(19) = 0.76;
parms(20) = 0.42;
parms(21) = 1.01;
parms(22) = 0.64;
parms(23) = 0.22; % 0.6
parms(24) = 0.6;
parms(25) = 0.6;
parms(26) = 0.8;
parms(27) = 0.68;
parms(28) = 0.5;
parms(29) = 0.29; % 0.29
parms(30) = 0.48; 
parms(31) = 0.38;
parms(32) = 1.2; % 1.21
parms(33) = 0.38; % 0.38
parms(34) = 0.5;
parms(35) = 0.8;
parms(36) = 0.5;
parms(37) = 0.8;
parms(38) = 0.7;
parms(39) = 0.7;
parms(40) = 0.6;

parms(41) = 2.80;
parms(42) = 0.16; %0.16
parms(43) = 1.18;
parms(44) = 0.5;
parms(45) = 0.2; % 0.24
parms(46) = 0.23; % 0.28
parms(47) = 0.63; % 0.57
parms(48) = 1.73; % 1.73
parms(49) = 0.46;
parms(50) = 0.5; 
parms(51) = 0.6;
parms(52) = 0.3;
parms(53) = 1.9;
parms(54) = 0.3;
parms(55) = 0.5;
parms(56) = 2.0;
parms(57) = 0.3;
parms(58) = 0.5;
parms(59) = 2.0;
parms(60) = 0.8; % 0.8
parms(61) = 1.9;

parms(62) = 1; % 1 2
parms(63) = 0.7;
parms(64) = 0.35; % 0.35 0.3
parms(65) = 0.2; % 0.2
parms(66) = 1;
parms(67) = 3; % 3 1

%parms_to_fit_s = parms;
%parms_w_noise = parms_to_fit_s;
%parms_w_noise([62:65,67]) = parms_w_noise([62:65,67]) + normrnd(0,0.2,[1,5]);
parm_og = parms;

clear parms 

LHYm_init = 4.5;
LHYp_init = 4.5;
Pp_init = 3;
P95m_init = 0.9;
P95p_init = 0.9;
P73m_init = 1.5;
P73p_init = 1.5;
P5T1m_init = 0.6;
P5T1p_init = 0.6;
E4m_init = 0.5;
E4p_init = 0.5;
LUXm_init = 0.5;
LUXp_init = 0.5;
E3m_init = 1.3;
E3p_init = 1.3;
EC_init = 0.5;

init_cond_wt = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init];
init_cond_mut = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,EC_init];

webb_data_wt = readtable("webb_data_wt.csv"); 
webb_mat_wt = table2array(webb_data_wt);
webb_data_mut = readtable("webb_data_mut.csv"); 
webb_mat_mut = table2array(webb_data_mut);

webb_smooth_wt = smooth_data(webb_mat_wt,[3:8],[1,2,3]);
webb_smooth_mut = smooth_data(webb_mat_mut,[3:8],[1,2,3]);

%plot(webb_smooth_wt(webb_smooth_wt(:,1) == 1,2), ...
%    webb_smooth_wt(webb_smooth_wt(:,1) == 1,3:8))
%xline([0:24:240],':','HandleVisibility','off');
%set(gcf,'color','w');
%set(gca,'TickLength',[0,0]) 

%plot(webb_smooth_wt(webb_smooth_wt(:,1) == 1,2), ...
%    webb_smooth_wt(webb_smooth_wt(:,1) == 1,3), ...
%    webb_smooth_mut(webb_smooth_mut(:,1) == 1,2), ...
%    webb_smooth_mut(webb_smooth_mut(:,1) == 1,3))
%xline([0:24:240],':','HandleVisibility','off');
%set(gcf,'color','w');
%set(gca,'TickLength',[0,0]) 


w_wt_small = webb_smooth_wt;
w_wt_small(:,5) = [];

w_mut_small = webb_smooth_mut;
w_mut_small(:,[4,5]) = [];


%data_in = w_wt_small;
%data_in_mut = w_mut_small;

mat = zeros(length(1:3),length(3:7));
i = 1;
for v = 3:7
    for r = 1:3
        [~,tt] = findpeaks(w_wt_small(w_wt_small(:,1) == r,v));
        num_peak = length(tt);
        mat(i) = num_peak;
        i = i + 1;
    end
end 
      
peaks_wt = [];

for v = 3:7
    
    period_diffs = [];
    
    for r = 1:3
        
        clear mat_add
        
        sub_data = w_wt_small(w_wt_small(:,1) == r,[2,v]);
        [~,p_t] = findpeaks(sub_data(:,2));
        peak_timings = sub_data(p_t,1);

        if(v == 3)

            peak_timings = [0;peak_timings];
            
        end

            mat_add = zeros(length(peak_timings),3);
            mat_add(:,1) = r;
            mat_add(:,2) = v;
            mat_add(:,3) = peak_timings;

            peaks_wt = [peaks_wt;mat_add];
    end 

   
end

clear sub_data
%sub_data = w_wt_small(w_wt_small(:,1) == 1,[2,3]);
%[~,p_t] = findpeaks(sub_data(:,2));
%peak_timings = sub_data(p_t,1);

var_correspond_wt = [3:7;1,14,12,6,8];
%var_correspond_mut = [3:6;1,12,6,8];
%var_correspond_wt = [3;1];
%var_correspond_wt = [3,4;1,14];

data_in = peaks_wt;

%% Genetic Algorithm 

options2 = optimoptions('gamultiobj','InitialPopulationMatrix',parms_to_fit_s([62:65,67]), ...
    'MaxGenerations',6000,'MaxStallGenerations',70,...
     'FunctionTolerance',1e-1,'ConstraintTolerance',1e-12);
[a0,fval,exitflag,output] = gamultiobj(@(parameters)parms_test_ga(parameters,@wheat_wt, ...
    [62:65,67],parms_to_fit_s, ...
    data_in,var_correspond_wt,init_cond_wt),5,[],[],[],[], ...
    [0,0,0,0,0],[3,1,1,1,3],[],options2);

options3 = optimoptions('gamultiobj','InitialPopulationMatrix',parm_og([62:65,67]), ...
    'MaxGenerations',6000,'MaxStallGenerations',70,...
     'FunctionTolerance',1e-1,'ConstraintTolerance',1e-12);
[a02,fval2,exitflag2,output2] = gamultiobj(@(parameters)parms_test_ga(parameters,@wheat_wt, ...
    [62:65,67],parm_og, ...
    data_in,var_correspond_wt,init_cond_wt),5,[],[],[],[], ...
    [0,0,0,0,0],[3,1,1,1,3],[],options3);

options4 = optimoptions('gamultiobj','InitialPopulationMatrix',parms_w_noise([62:65,67]), ...
    'MaxGenerations',6000,'MaxStallGenerations',70,...
     'FunctionTolerance',1e-1,'ConstraintTolerance',1e-12);
[a03,fval3,exitflag3,output3] = gamultiobj(@(parameters)parms_test_ga(parameters,@wheat_wt, ...
    [62:65,67],parms_w_noise, ...
    data_in,var_correspond_wt,init_cond_wt),5,[],[],[],[], ...
    [0,0,0,0,0],[3,1,1,1,3],[],options4);


fval = sortrows(fval,1);
fval2 = sortrows(fval2,1);
fval3 = sortrows(fval3,1);

plot1 = plot(fval(:,1),fval(:,2),"-o", ...
    fval2(:,1),fval2(:,2),"-o", ...
    fval3(:,1),fval3(:,2),"-o");
plot1(1).MarkerFaceColor = [0 0.4470 0.7410];
plot1(1).Color = [0 0.4470 0.7410];
plot1(2).MarkerFaceColor = [0.9290 0.6940 0.1250];
plot1(2).Color = [0.9290 0.6940 0.1250];
plot1(3).MarkerFaceColor = [0.3010 0.7450 0.9330];
plot1(3).Color = [0.3010 0.7450 0.9330];
plot1(1).LineWidth = 2;
plot1(2).LineWidth = 2;
plot1(3).LineWidth = 2;
legend("Partially Optimised Parameters","Original Parameters","Noisy Partially Optimised Parameters")
grid on
xlabel("Objective Function")
ylabel("Barrier Function")
title("Pareto Front for Local Minima")
xlim([9,50])
ylim([-0.1,30])
set(gca,'fontname','times')
set(gca,"FontSize",15)
set(gca,'TickLength',[0,0])


parms = parms_to_fit_s;
parms([62:65,67]) = optim_parm1(5,1:5); % sols off - 3,4,6,7,8,9,10,15,17
%parms = parm_og;
%parms([62:65,67]) = a02(18,:); % sols off - 1,4,6,7,8,9,10,11,12,13,14,17,18
%parms = parms_w_noise;
%parms_w_noise([62:65,67]) = a03(18,:); % sols off - 1,2,3,4,6,9,10,11,14,15,16,17,18

LD_cyc_typ = [30,0.75]; % LD cycle ratio
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD
t_end = 480;

% Run LDLD to get initial conditions
[t_wheatwt_ldld,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);

% Model Testing 
LDLD_or_LDLL = "LDLL";
[t_wheatwt,v_wheatwt] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_upd);

plot(t_wheatwt,v_wheatwt(:,1),t_wheatwt,v_wheatwt(:,14),t_wheatwt,v_wheatwt(:,8))
legend("LHY","ELF3","TOC1")
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])
%plot(t_wheatwt,v_wheatwt(:,16))

[t_wheatmut_ldld,v_wheatmut_ldld] = ode15s(@(t,vars)wheat_elf3mut(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond_mut);
init_cond_mut = v_wheatmut_ldld(end,:);

% Model Testing 
LDLD_or_LDLL = "LDLL";
[t_wheatmut,v_wheatmut] = ode15s(@(t,vars)wheat_elf3mut(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond_mut);
plot(t_wheatmut,v_wheatmut(:,1),t_wheatmut,v_wheatmut(:,14),t_wheatmut,v_wheatmut(:,8))
legend("LHY","ELF3","TOC1")
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])

%% Plotting Phenotypes 
optim_parm1 = a0;
optim_parm2 = a02;
optim_parm3 = a03;

optim_parm1([3,4,6,7,8,9,10,15,17],:) = [];
optim_parm2([1,4,6,7,8,9,10,11,12,13,14,17,18],:) = [];
optim_parm3([1,2,3,4,6,9,10,11,14,15,16,17,18],:) = [];

optim_p_ss_tt = {optim_parm1,optim_parm2,optim_parm3};

mean_act = [];
max_act = [];

for pset_i = 1:length(optim_p_ss_tt)

    clear parms
    pset = optim_p_ss_tt{pset_i};

    if(pset_i == 1)
        parms = parms_to_fit_s;
    elseif(pset_i == 2)
        parms = parm_og;
    elseif(pset_i == 3) 
        parms = parms_w_noise;
    end 
   
    pset = [parms([62:65,67]);pset];

    for par = 1:height(pset)
        
        parms([62:65,67]) = pset(par,:);

        LD_cyc_typ = [30,0.75]; 
        LDLD_or_LDLL = "LDLD"; % LDLL or LDLD
        t_end = 480;

        [t_wheatwt_ldld,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond_wt);
        init_conditions_upd = v_wheatwt_ldld(end,:);
        
        LDLD_or_LDLL = "LDLL";
        [t_wheatwt,v_wheatwt] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_upd);

        [~,range_48] = min(abs(t_wheatwt - 48));
        data_interest = v_wheatwt(1:range_48,[1,16]);

        LC_act = pset(par,1)*data_interest(:,1);
        EC_act = pset(par,5)*data_interest(:,2);

        mean_lc = mean(LC_act);
        mean_ec = mean(EC_act);
       
        max_lc = max(LC_act);
        max_ec = max(EC_act);
        
        if(par == 1)
            mean_act = [mean_act;[mean_lc,mean_ec,"Unoptimised"]];
            max_act = [max_act;[max_lc,max_ec,"Unoptimised"]];
        else 
             mean_act = [mean_act;[mean_lc,mean_ec,pset_i]];
             max_act = [max_act;[max_lc,max_ec,pset_i]];
        end 

    end 

end 

max_plot = str2double(max_act(:,1:2));
mean_plot = str2double(mean_act(:,1:2));

mean_act(17,3) = NaN;
max_act(17,3) = NaN;

plot2 = plot(mean_plot(mean_act(:,3) == "1",1),mean_plot(mean_act(:,3) == "1",2),"o", ...
    mean_plot(mean_act(:,3) == "2",1),mean_plot(mean_act(:,3) == "2",2),"o", ...
    mean_plot(mean_act(:,3) == "3",1),mean_plot(mean_act(:,3) == "3",2),"o", ...
    mean_plot(mean_act(:,3) == "Unoptimised",1),mean_plot(mean_act(:,3) == "Unoptimised",2),"o");
grid on 
legend("Optimised From Partially Optimised Parameter Set", ...
    "From Original Parameter Set","From Noisy Partially Optimised Set", ...
    "Before Complete Optimisation",'FontSize',12,'AutoUpdate','off')
plot2(1).MarkerFaceColor = [0 0.4470 0.7410];
plot2(1).Color = [0 0.4470 0.7410];
plot2(2).MarkerFaceColor = [0.9290 0.6940 0.1250];
plot2(2).Color = [0.9290 0.6940 0.1250];
plot2(3).MarkerFaceColor = [0.3010 0.7450 0.9330];
plot2(3).Color = [0.3010 0.7450 0.9330];
plot2(4).MarkerFaceColor = [0.6350 0.0780 0.1840];
plot2(4).Color = [0.6350 0.0780 0.1840];
ylim([0,7])
xlim([0,2.5])
xlabel("Effective LHY Activity (Average)")
ylabel("Effective Evening Complex Activity (Average)")
title("LHY and EC Activity with Obtained Parameter Sets")
text(0.31,2.35,"Partially Optimised Parameters",'FontName','times')
text(0.32,3.58,"Original Parameters",'FontName','times')
hold on
fitted_coeff = polyfit(mean_plot([1:16,18:22],1),mean_plot([1:16,18:22],2),1);
fitted_line = polyval(fitted_coeff,[0:0.1:4]);
plot3 = plot([0:0.1:4],fitted_line,'--','Color',"black");
plot3(1).LineWidth = 2;
annotation('textbox',[0.72,0.5,0.3,0.3],'String', ...
    'Gradient = 0.52, Intercept = 3.0','FitBoxToText','on','BackgroundColor','white', ...
    'FontName','times','FontSize',12);
set(gca,'fontname','times')
set(gca,"FontSize",14)

plot2 = plot(max_plot(mean_act(:,3) == "1",1),max_plot(max_act(:,3) == "1",2),"o", ...
    max_plot(max_act(:,3) == "2",1),max_plot(max_act(:,3) == "2",2),"o", ...
    max_plot(max_act(:,3) == "3",1),max_plot(max_act(:,3) == "3",2),"o", ...
    max_plot(max_act(:,3) == "Unoptimised",1),max_plot(max_act(:,3) == "Unoptimised",2),"o");
grid on 
legend("Optimised From Partially Optimised Parameter Set", ...
    "From Original Parameter Set","From Noisy Partially Optimised Set", ...
    "Before Complete Optimisation",'FontSize',12,'AutoUpdate','off')
plot2(1).MarkerFaceColor = [0 0.4470 0.7410];
plot2(1).Color = [0 0.4470 0.7410];
plot2(2).MarkerFaceColor = [0.9290 0.6940 0.1250];
plot2(2).Color = [0.9290 0.6940 0.1250];
plot2(3).MarkerFaceColor = [0.3010 0.7450 0.9330];
plot2(3).Color = [0.3010 0.7450 0.9330];
plot2(4).MarkerFaceColor = [0.6350 0.0780 0.1840];
plot2(4).Color = [0.6350 0.0780 0.1840];
%ylim([0,7])
%xlim([0,2.5])
xlabel("Effective LHY Activity (Max.)")
ylabel("Effective Evening Complex Activity (Max.)")
title("LHY and EC Activity with Obtained Parameter Sets")
text(0.79,5.23,"Partially Optimised Parameters",'FontName','times')
text(0.87,8.6,"Original Parameters",'FontName','times')
hold on
fitted_coeff = polyfit(max_plot([1:16,18:22],1),max_plot([1:16,18:22],2),1);
fitted_line = polyval(fitted_coeff,[0:0.1:5]);
plot3 = plot([0:0.1:5],fitted_line,'--','Color',"black");
plot3(1).LineWidth = 2;
annotation('textbox',[0.72,0.5,0.3,0.3],'String', ...
    'Gradient = -0.06, Intercept = 6.7','FitBoxToText','on','BackgroundColor','white', ...
    'FontName','times','FontSize',12);
set(gca,'fontname','times')
set(gca,"FontSize",14)

optim_parm1(:,6) = 1;
optim_parm2(:,6) = 2;
optim_parm3(:,6) = 3;

parm_plots = [optim_parm1(:,[1,3,5,6]);optim_parm2(:,[1,3,5,6]);optim_parm3(:,[1,3,5,6])];
parm_plots = [parm_plots;[parms_to_fit_s([62,64,67]),4];[parm_og([62,64,67]),4]];


s_fit = fit([parm_plots(:,1),parm_plots(:,2)],parm_plots(:,3),'poly23');
plot(s_fit)
xlim([0,3])
ylim([0.3,1])
zlim([1,3])
alpha 0.5
hold on 
scatter3(parm_plots(:,1),parm_plots(:,2),parm_plots(:,3),'filled','MarkerFaceColor','red')
xlabel("LHY Activity")
ylabel("ELF3 Involvement in EC")
zlabel("EC Activity")

 %% Large Model

mat = zeros(length(1:3),length(3:8));
i = 1;
for v = 3:8
    for r = 1:3
        [~,tt] = findpeaks(webb_smooth_wt(webb_smooth_wt(:,1) == r,v));
        num_peak = length(tt);
        mat(i) = num_peak;
        i = i + 1;
    end
end 
      
peaks_wt = [];

for v = 3:8
    
    period_diffs = [];
    
    for r = 1:3
        
        clear mat_add
        
        sub_data = webb_smooth_wt(webb_smooth_wt(:,1) == r,[2,v]);
        [~,p_t] = findpeaks(sub_data(:,2));
        peak_timings = sub_data(p_t,1);

        if(v == 3)

            peak_timings = [0;peak_timings];
            
        end

            mat_add = zeros(length(peak_timings),3);
            mat_add(:,1) = r;
            mat_add(:,2) = v;
            mat_add(:,3) = peak_timings;

            peaks_wt = [peaks_wt;mat_add];
    end 

   
end

clear sub_data
 
parms(1) = 1.022;
parms(2) = 9.866;
parms(3) = 5.353;
parms(4) = 2.278;
parms(5) = 5.917;
parms(6) = 4.365;

parms(7) = 0.409;
parms(8) = 2.021;
parms(9) = 0.03313;
parms(10) = 0.1;
parms(11) = 0.3853;
parms(12) = 0.2525;

parms(13) = 0.996;
parms(14) = 0.5889;
parms(15) = 0.3761;
parms(16) = 2.3;
parms(17) = 0.0133;
parms(18) = 0.64787;
parms(19) = 5.437;
parms(20) = 0.1225;
parms(21) = 0.01001;
parms(22) = 0.6771;
parms(23) = 1.998;
parms(24) = 0.276;
parms(25) = 4.916;
parms(26) = 0.0903;
parms(27) = 0.5383;
parms(28) = 0.04744;
parms(29) = 2.426;
parms(30) = 0.2;
parms(31) = 0.2;
parms(32) = 0.1;
parms(33) = 0.3012;
parms(34) = 0.1764;
parms(35) = 2.848;
parms(36) = 0.4176;
parms(37) = 1.57;
parms(38) = 0.1;
parms(39) = 0.02757; 
parms(40) = 0.01;
parms(41) = 5.491;
parms(42) = 0.3;
parms(43) = 5.681;
parms(44) = 13;
parms(45) = 0.1115;
parms(46) = 0.9188;
parms(47) = 0.5711;
parms(48) = 0.9391;
parms(49) = 7.975;
parms(50) = 0.216;
parms(51) = 0.3759;
parms(52) =  0.5214;
parms(53) = 0.3577;
parms(54) = 0.7944;
parms(55) = 0.7541;
parms(56) = 0.1293;

parms(57) = 0.23;
parms(58) = 20;
parms(59) = 0.1;

parms(60) = 0.6;
parms(61) = 0.3;
parms(62) = 0.2;
parms(63) = 1.78;
parms(64) = 8;
parms(65) = 0.7;
parms(66) = 0.3;
parms(67) = 3;
parms(68) = 0.4024;
parms(69) = 1.461;
parms(70) = 1.111;
parms(71) = 2.13;
parms(72) = 25.2;

parms(73) = 0.1217;
parms(74) = 0.2873;

parms(75) = 3.747;
parms(76) = 2.384;
parms(77) = 4.747; 
parms(78) = 16.3;
parms(79) = 0.1;
parms(80) = 0.4728;
parms(81) = 35.94;
parms(82) = 2.225;
parms(83) = 0.5885;
parms(84) = 21.086;
parms(85) = 2.086;
parms(86) = 6.033;
parms(87) = 1.053;
parms(88) = 12.66;
parms(89) = 6.743;
parms(90) = 0.1519;
parms(91) = 5.199;
parms(92) = 1.205;
parms(93) = 16.24;
parms(94) = 0.1465;
parms(95) = 5.127;
parms(96) = 1.971;
parms(97) = 7.1;
parms(98) = 16.33;
parms(99) = 1.027;
parms(100) = 5.466;
parms(101) = 6.864;
parms(102) = 8.392;
parms(103) = 0.1423;
parms(104) = 2.714;
parms(105) = 0.01041;
parms(106) = 4.775;
parms(107) = 0.9026;
parms(108) = 0.05704;
parms(109) = 0.02929;
parms(110) = 0.49;
parms(111) = 0.554;
parms(112) = 0.05062;
parms(113) = 1.051;

parms(114) = 1.103;
parms(115) = 0.5891;
parms(116) = 0.2317;
parms(117) = 0.1472;
parms(118) = 0.8543;

parms(119) = 1.6; %1 1.6
parms(120) = 1; %1
parms(121) = 0.1; %1 0.1

%parms_og_l = parms;
parms_pp_l = parms;
clear parms

LHYm_init = 0.6;
LHYp_init = 0.6;
CCA1m_init = 0.6;
CCA1p_init = 0.6;
Pp_init2 = 4;
P9m_init = 0.05;
P9p_init = 0.05;
P7m_init = 0.05;
P7p_init = 0.05;
P5m_init = 0.05;
P5pc_init = 0.05;
P5pn_init = 0.05;
TOC1m_init = 0.3;
TOC1pn_init = 0.3;
TOC1pc_init = 0.3;
E4m_init = 0.05;
E4p_init = 0.05;
E4D_init = 0.05;
E3m_init = 0.1;
E3p_init = 0.1;
E34_init = 0.05;
LUXm_init = 0.2;
LUXp_init = 0.2;
COP1pc_init = 0.4;
COP1pn_init = 0.4;
COP1D_init = 0.2;
ZTLp_init = 0.3;
ZGp_init = 0.2;
GIm_init = 0.3; 
GIpc_init = 0.2;
GIpn_init = 0.1;
NOXm_init = 0.2;
NOXp_init = 0.2;
RVE8m_init = 0.6;
RVE8p_init = 0.6;

init_cond_wt = [LHYm_init,LHYp_init,CCA1m_init,CCA1p_init,Pp_init2,P9m_init,P9p_init,P7m_init,P7p_init,P5m_init,P5pc_init,P5pn_init,TOC1m_init,TOC1pn_init,TOC1pc_init,E4m_init,E4p_init,E4D_init,E3m_init,E3p_init,E34_init,LUXm_init,LUXp_init,COP1pc_init,COP1pn_init,COP1D_init,ZTLp_init,ZGp_init,GIm_init,GIpc_init,GIpn_init,NOXm_init,NOXp_init,RVE8m_init,RVE8p_init];

var_correspond_wt = [3:8;1,19,29,22,8,13];

data_in = peaks_wt;

%% Genetic Algorithm 

options5 = optimoptions('gamultiobj','InitialPopulationMatrix',parms_pp_l([119:121]), ...
    'MaxGenerations',3000,'MaxStallGenerations',70,...
     'FunctionTolerance',1e-1,'ConstraintTolerance',1e-12);
[a05,fval5,exitflag5,output5] = gamultiobj(@(parameters)parms_test_ga(parameters,@wheat_wt_large, ...
    [119:121],parms_pp_l,data_in,var_correspond_wt,init_cond_wt),3,[],[],[],[], ...
    [0,0,0],[3,3,3],[],options5);

options6 = optimoptions('gamultiobj','InitialPopulationMatrix',parms_og_l([119:121]), ...
    'MaxGenerations',3000,'MaxStallGenerations',70,...
     'FunctionTolerance',1e-1,'ConstraintTolerance',1e-12);
[a06,fval6,exitflag6,output6] = gamultiobj(@(parameters)parms_test_ga(parameters,@wheat_wt_large, ...
    [119:121],parms_og_l,data_in,var_correspond_wt,init_cond_wt),3,[],[],[],[], ...
    [0,0,0],[3,3,3],[],options6);

%parms = parms_pp_l;
%parms(119:121) = a05(4,:); % 1,2 maybe,3,5,6,7,8,9,10,11,12,13,16,17,18 (4 is the only one I'm happy with).
parms = parms_og_l;
parms(119:121) = a06(18,:); %1,2,4,5,6,7,9,10,11,12,14,15,16,17
optim_parms_l1 = a05;
optim_parms_l1([1,2,5,6,7,8,9,10,11,12,13,16,17,18],:) = [];
optim_parms_l2 = a06;
optim_parms_l2([1,2,4,5,6,7,9,10,11,12,14,15,16,17],:) = [];
optim_parms_l = [optim_parms_l1;optim_parms_l2];
optim_parms_l = [optim_parms_l;parms_pp_l(119:121)];
writematrix(optim_parms_l,"large_model_fit.csv")

parms = parms_pp_l;
parms(119:121) = optim_parms_l(8,:);


LD_cyc_typ = [30,0.75]; % LD cycle ratio
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD
t_end = 480;

% Run LDLD to get initial conditions
[t_wheatwt_ldl,v_wheatwt_ldl] = ode15s(@(t,vars)wheat_wt_large(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldl(end,:);

% Model Testing 
LDLD_or_LDLL = "LDLL";
[t_wheatwtl,v_wheatwtl] = ode15s(@(t,vars)wheat_wt_large(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_upd);

plot(t_wheatwtl,v_wheatwtl(:,1),t_wheatwtl,v_wheatwtl(:,19),t_wheatwtl,v_wheatwtl(:,13))
legend("LHY","ELF3","TOC1","EC")
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])

load matlab_ws.mat
writematrix(parm_plots(1:(end-1),:),"small_model_fit.csv")

