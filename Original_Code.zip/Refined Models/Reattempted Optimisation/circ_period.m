function c_p_mat = circ_period(data,var_label)

c_p_mat = [];

for v = var_label

    peak_ts = data(data(:,1) == v,2);
    peak_ts = str2double(peak_ts);
 
    peaks_interest = peak_ts([peak_ts > 3 & peak_ts < 28.5]);
   
    [~,abs_p_pos] = min(abs(peaks_interest-24));
    abs_phase = peaks_interest(abs_p_pos);
        
    period = mean(diff(peak_ts));

    circ_period = (abs_phase*24)/period;
    
    c_p_mat = [c_p_mat;[v,circ_period]];

end 


