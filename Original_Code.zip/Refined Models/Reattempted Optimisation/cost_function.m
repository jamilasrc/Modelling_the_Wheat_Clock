function cost = cost_function(data_in,times_i,sol_i,var_correspond)

objective_pk = [];
%objective_pd = [];

%data_in = peaks_wt;
%data_period = av_period_wt;
%var_correspond = var_correspond_wt;


for  var = var_correspond(2,:)                

    %var = var_correspond(2,5);

    obj_pk = [];

    corr_v_ind = var_correspond(1,var_correspond(2,:) == var);
    sub_data = data_in(data_in(:,2) == corr_v_ind,:); 
    sim_data = sol_i(:,var); 

    %% get peaks 

    [~,peaks_wheat] = findpeaks(sim_data);
    peak_times_sim = times_i(peaks_wheat);
    %disp(peak_times_sim)

    %% get period differences
    %if(var == 1)
        
    %    p_t_s_inlinewithdata = peak_times_sim(peak_times_sim <= 96);
    %    period_sim = mean(diff(p_t_s_inlinewithdata));
    %    objective_pd = sqrt((data_period - period_sim)^2);
        %disp(objective_pd)

    %end 

    peak_diffs = [];
    
    for rep = unique(data_in(:,1))'
        
        data_rep = sub_data(sub_data(:,1) == rep,:);
        %disp(data_rep)
        
        for p = 1:height(data_rep)
            
            [~,c_p_ind] = min(abs(peak_times_sim - data_rep(p,3)));
            closest_peak = peak_times_sim(c_p_ind);
            %disp(c_p_ind)
            closest_peak = closest_peak(1);

            p_diff = sqrt((closest_peak-data_rep(p,3))^2);
            %disp(p_diff)
            
            peak_diffs = [peak_diffs,p_diff];

        end 

    end 

   %disp(peak_diffs)
   obj_pk = mean(peak_diffs);
   objective_pk = [objective_pk,obj_pk];

end 

%cost(1:length(objective_pk)+1) = [objective_pk,objective_pd];
cost = sum(objective_pk);