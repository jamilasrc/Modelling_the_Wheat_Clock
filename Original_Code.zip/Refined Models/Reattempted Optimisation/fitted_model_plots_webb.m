
webb_data_wt = readtable("webb_data_wt.csv"); 
webb_mat_wt = table2array(webb_data_wt);
webb_data_mut = readtable("webb_data_mut.csv"); 
webb_mat_mut = table2array(webb_data_mut);

webb_smooth_wt = smooth_data(webb_mat_wt,[3:8],[1,2,3]);
webb_smooth_mut = smooth_data(webb_mat_mut,[3:8],[1,2,3]);

%% Small Model Data Generation
w_wt_small = webb_smooth_wt;
w_wt_small(:,5) = [];

w_mut_small = webb_smooth_mut;
w_mut_small(:,[4,5]) = [];


mat = zeros(length(1:3),length(3:7));
i = 1;
for v = 3:7
    for r = 1:3
        [~,tt] = findpeaks(w_wt_small(w_wt_small(:,1) == r,v));
        num_peak = length(tt);
        mat(i) = num_peak;
        i = i + 1;
    end
end 
      
peaks_wt = [];

for v = 3:7
    
    period_diffs = [];
    
    for r = 1:3
        
        clear mat_add
        
        sub_data = w_wt_small(w_wt_small(:,1) == r,[2,v]);
        [~,p_t] = findpeaks(sub_data(:,2));
        peak_timings = sub_data(p_t,1);

        if(v == 3)

            peak_timings = [0;peak_timings];
            
        end

            mat_add = zeros(length(peak_timings),3);
            mat_add(:,1) = r;
            mat_add(:,2) = v;
            mat_add(:,3) = peak_timings;

            peaks_wt = [peaks_wt;mat_add];
    end 

   
end

clear sub_data
peaks_wt_s = peaks_wt;
clear peaks_wt

var_correspond_wt = [3:7;1,14,12,6,8];

%% Large Model Data Generation
mat = zeros(length(1:3),length(3:8));
i = 1;
for v = 3:8
    for r = 1:3
        [~,tt] = findpeaks(webb_smooth_wt(webb_smooth_wt(:,1) == r,v));
        num_peak = length(tt);
        mat(i) = num_peak;
        i = i + 1;
    end
end 
      
peaks_wt = [];

for v = 3:8
    
    period_diffs = [];
    
    for r = 1:3
        
        clear mat_add
        
        sub_data = webb_smooth_wt(webb_smooth_wt(:,1) == r,[2,v]);
        [~,p_t] = findpeaks(sub_data(:,2));
        peak_timings = sub_data(p_t,1);

        if(v == 3)

            peak_timings = [0;peak_timings];
            
        end

            mat_add = zeros(length(peak_timings),3);
            mat_add(:,1) = r;
            mat_add(:,2) = v;
            mat_add(:,3) = peak_timings;

            peaks_wt = [peaks_wt;mat_add];
    end 

   
end

clear sub_data

peaks_wt_l = peaks_wt;
clear peaks_wt


peaks_wt_l = string(peaks_wt_l);
var_names = ["LHY","ELF3","GI","LUX","PRR73","TOC1"];
var_no = string(3:8);
for v = 1:length(var_no)
    v_no = var_no(v);
    v_nam = var_names(v);
    peaks_wt_l(peaks_wt_l(:,2) == v_no,2) = v_nam;
end 

peaks_wt_l = [peaks_wt_l(1:45,:);["1","PRR73","6"];peaks_wt_l(46:end,:)];
peaks_wt_l = [peaks_wt_l(1:49,:);["2","PRR73","6"];peaks_wt_l(50:end,:)];


cps = [];
rAMPs = [];

for i = unique(peaks_wt_l(:,1))' 

    i = "1";
    sub_peaks = peaks_wt_l(peaks_wt_l(:,1) == i,2:3);
    sub_data = webb_smooth_wt(webb_smooth_wt(:,1) == str2double(i),:);

    d_c_p = circ_period(sub_peaks,var_names);
    d_rAMP = rAMP(sub_data(:,3:8),sub_data(:,2),sub_peaks,var_names,1:6);

    cps = [cps;d_c_p];
    rAMPs = [rAMPs,d_rAMP];

end 

data_cp = [];
for v2 = var_names 
    cp_vals = str2double(cps(cps(:,1) == v2,2));
    cp_add = mean(cp_vals);
    data_cp = [data_cp;[v2,cp_add]];
end 

data_rAMP = [];
for ind = 1:length(3:8)

    var = var_names(ind);
    rAMP_vals = rAMPs([ind,ind+length(3:8),ind+2*length(3:8)]);
    rAMP_add = mean(rAMP_vals); 
    data_rAMP = [data_rAMP;[var,rAMP_add]];
end 

data_cp(:,3) = ["1","21.3","12.5","15","6.3","16.4"];
data_cp(:,4) = data_rAMP(:,2);
data_cp(:,5) = ["#EDB120","#A2142F","red","#0072BD","#D95319","#77AC30"];

colour_vecd = data_cp(:,5);

rectangle("Position",[0,0,16,3],"FaceColor",[0.5,0.7450,0.9330], ...
    "EdgeColor",[0.5,0.7450,0.9330])
hold on 
rectangle("Position",[16,0,8,3],"FaceColor",[0.1,0.1,0.1], ...
    "EdgeColor",[0.1,0.1,0.1])
hold on 
rectangle("Position",[16,-0.5,8,0.3],"FaceColor",[0.5,0.5,0.5], ...
    "EdgeColor","black")
hold on 
rectangle("Position",[0,0-0.5,16,0.3],"FaceColor","white", ...
    "EdgeColor","black")
axis([0,24,-0.8,6])
axis off

for r = 1:height(data_cp)

    plot(str2double(data_cp(r,3)),str2double(data_cp(r,4)),"s", ...
        "MarkerFaceColor",colour_vecd(r),"MarkerEdgeColor",colour_vecd(r),"MarkerSize",30)
    hold on 

end 
hold on    
txt_x = str2double(data_cp(:,3)) - 1;
txt_x([2,4,6]) = txt_x([2,4,6]) - 0.1;
txt_x(5) = txt_x(5) - 0.3;
txt_x(3) = txt_x(3) + 0.3;
txt_y = str2double(data_cp(:,4));
text(txt_x,txt_y,var_names, ...
    "Color","white","FontSize",15,"FontName","times")
hold on 
text([0,6,11.85,17.85,23.75],[-0.72,-0.72,-0.72,-0.72,-0.72],["0","6","12","18","24"], ...
    "Color","black","FontSize",15,"FontName","times")
title("Experimental Data","FontSize",15,"FontName","times")





%% Small Model

parms(1) = 4.58;
parms(2) = 3.0; %3.0
parms(3) = 1.27;
parms(4) = 0.5;
parms(5) = 5.0;
parms(6) = 1.0;
parms(7) = 1.1;
%parms(7) = 2;
parms(8) = 1.1;
parms(9) = 1;
parms(10) = 2; % 1

parms(11) = 0.53;
parms(12) = 0.21;
parms(13) = 0.35;
parms(14) = 0.56;
parms(15) = 0.57;
parms(16) = 0.4;
parms(17) = 0.4;
parms(18) = 0.5;

parms(19) = 0.76;
parms(20) = 0.42;
parms(21) = 1.01;
parms(22) = 0.64;
parms(23) = 0.22; % 0.6
parms(24) = 0.6;
parms(25) = 0.6;
parms(26) = 0.8;
parms(27) = 0.68;
parms(28) = 0.5;
parms(29) = 0.29; % 0.29
parms(30) = 0.48; 
parms(31) = 0.38;
parms(32) = 1.2; % 1.21
parms(33) = 0.38; % 0.38
parms(34) = 0.5;
parms(35) = 0.8;
parms(36) = 0.5;
parms(37) = 0.8;
parms(38) = 0.7;
parms(39) = 0.7;
parms(40) = 0.6;

parms(41) = 2.80;
parms(42) = 0.16; %0.16
parms(43) = 1.18;
parms(44) = 0.5;
parms(45) = 0.2; % 0.24
parms(46) = 0.23; % 0.28
parms(47) = 0.63; % 0.57
parms(48) = 1.73; % 1.73
parms(49) = 0.46;
parms(50) = 0.5; 
parms(51) = 0.6;
parms(52) = 0.3;
parms(53) = 1.9;
parms(54) = 0.3;
parms(55) = 0.5;
parms(56) = 2.0;
parms(57) = 0.3;
parms(58) = 0.5;
parms(59) = 2.0;
parms(60) = 0.8; % 0.8
parms(61) = 1.9;

parms(62) = 2.3179; 
parms(63) = 0.7446;
parms(64) = 0.8441; 
parms(65) = 0.5210; 
parms(66) = 1;
parms(67) = 1.8965; 

LHYm_init = 4.5;
LHYp_init = 4.5;
Pp_init = 3;
P95m_init = 0.9;
P95p_init = 0.9;
P73m_init = 1.5;
P73p_init = 1.5;
P5T1m_init = 0.6;
P5T1p_init = 0.6;
E4m_init = 0.5;
E4p_init = 0.5;
LUXm_init = 0.5;
LUXp_init = 0.5;
E3m_init = 1.3;
E3p_init = 1.3;
EC_init = 0.5;

init_cond_wt = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init];

LD_cyc_typ = [30,0.75]; 
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD
t_end = 480;

% Run LDLD to get initial conditions
[t_wheatwt_ldld,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);

% Model Testing 
LDLD_or_LDLL = "LDLL";
[t_wheatwt,v_wheatwt] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_upd);


%% Large Model 
parms(1) = 1.022;
parms(2) = 9.866;
parms(3) = 5.353;
parms(4) = 2.278;
parms(5) = 5.917;
parms(6) = 4.365;

parms(7) = 0.409;
parms(8) = 2.021;
parms(9) = 0.03313;
parms(10) = 0.1;
parms(11) = 0.3853;
parms(12) = 0.2525;

parms(13) = 0.996;
parms(14) = 0.5889;
parms(15) = 0.3761;
parms(16) = 2.3;
parms(17) = 0.0133;
parms(18) = 0.64787;
parms(19) = 5.437;
parms(20) = 0.1225;
parms(21) = 0.01001;
parms(22) = 0.6771;
parms(23) = 1.998;
parms(24) = 0.276;
parms(25) = 4.916;
parms(26) = 0.0903;
parms(27) = 0.5383;
parms(28) = 0.04744;
parms(29) = 2.426;
parms(30) = 0.2;
parms(31) = 0.2;
parms(32) = 0.1;
parms(33) = 0.3012;
parms(34) = 0.1764;
parms(35) = 2.848;
parms(36) = 0.4176;
parms(37) = 1.57;
parms(38) = 0.1;
parms(39) = 0.02757; 
parms(40) = 0.01;
parms(41) = 5.491;
parms(42) = 0.3;
parms(43) = 5.681;
parms(44) = 13;
parms(45) = 0.1115;
parms(46) = 0.9188;
parms(47) = 0.5711;
parms(48) = 0.9391;
parms(49) = 7.975;
parms(50) = 0.216;
parms(51) = 0.3759;
parms(52) =  0.5214;
parms(53) = 0.3577;
parms(54) = 0.7944;
parms(55) = 0.7541;
parms(56) = 0.1293;

parms(57) = 0.23;
parms(58) = 20;
parms(59) = 0.1;

parms(60) = 0.6;
parms(61) = 0.3;
parms(62) = 0.2;
parms(63) = 1.78;
parms(64) = 8;
parms(65) = 0.7;
parms(66) = 0.3;
parms(67) = 3;
parms(68) = 0.4024;
parms(69) = 1.461;
parms(70) = 1.111;
parms(71) = 2.13;
parms(72) = 25.2;

parms(73) = 0.1217;
parms(74) = 0.2873;

parms(75) = 3.747;
parms(76) = 2.384;
parms(77) = 4.747; 
parms(78) = 16.3;
parms(79) = 0.1;
parms(80) = 0.4728;
parms(81) = 35.94;
parms(82) = 2.225;
parms(83) = 0.5885;
parms(84) = 21.086;
parms(85) = 2.086;
parms(86) = 6.033;
parms(87) = 1.053;
parms(88) = 12.66;
parms(89) = 6.743;
parms(90) = 0.1519;
parms(91) = 5.199;
parms(92) = 1.205;
parms(93) = 16.24;
parms(94) = 0.1465;
parms(95) = 5.127;
parms(96) = 1.971;
parms(97) = 7.1;
parms(98) = 16.33;
parms(99) = 1.027;
parms(100) = 5.466;
parms(101) = 6.864;
parms(102) = 8.392;
parms(103) = 0.1423;
parms(104) = 2.714;
parms(105) = 0.01041;
parms(106) = 4.775;
parms(107) = 0.9026;
parms(108) = 0.05704;
parms(109) = 0.02929;
parms(110) = 0.49;
parms(111) = 0.554;
parms(112) = 0.05062;
parms(113) = 1.051;

parms(114) = 1.103;
parms(115) = 0.5891;
parms(116) = 0.2317;
parms(117) = 0.1472;
parms(118) = 0.8543;

parms(119) = 0.5884; 
parms(120) = 0.6327; 
parms(121) = 0.1335;

parms(122) = 5.127;

LHYm_init = 0.6;
LHYp_init = 0.6;
CCA1m_init = 0.6;
CCA1p_init = 0.6;
Pp_init2 = 4;
P9m_init = 0.05;
P9p_init = 0.05;
P7m_init = 0.05;
P7p_init = 0.05;
P5m_init = 0.05;
P5pc_init = 0.05;
P5pn_init = 0.05;
TOC1m_init = 0.3;
TOC1pn_init = 0.3;
TOC1pc_init = 0.3;
E4m_init = 0.05;
E4p_init = 0.05;
E4D_init = 0.05;
E3m_init = 0.1;
E3p_init = 0.1;
E34_init = 0.05;
LUXm_init = 0.2;
LUXp_init = 0.2;
COP1pc_init = 0.4;
COP1pn_init = 0.4;
COP1D_init = 0.2;
ZTLp_init = 0.3;
ZGp_init = 0.2;
GIm_init = 0.3; 
GIpc_init = 0.2;
GIpn_init = 0.1;
NOXm_init = 0.2;
NOXp_init = 0.2;
RVE8m_init = 0.6;
RVE8p_init = 0.6;

init_cond_wtl = [LHYm_init,LHYp_init,CCA1m_init,CCA1p_init,Pp_init2,P9m_init,P9p_init,P7m_init,P7p_init,P5m_init,P5pc_init,P5pn_init,TOC1m_init,TOC1pn_init,TOC1pc_init,E4m_init,E4p_init,E4D_init,E3m_init,E3p_init,E34_init,LUXm_init,LUXp_init,COP1pc_init,COP1pn_init,COP1D_init,ZTLp_init,ZGp_init,GIm_init,GIpc_init,GIpn_init,NOXm_init,NOXp_init,RVE8m_init,RVE8p_init];

LD_cyc_typ = [30,0.75]; 
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD
t_end = 480;

% Run LDLD to get initial conditions
[t_wheatwt_ldldl,v_wheatwt_ldldl] = ode15s(@(t,vars)wheat_wt_large_correct(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond_wtl);
init_conditions_updl = v_wheatwt_ldldl(end,:);

% Model Testing 
LDLD_or_LDLL = "LDLL";
[t_wheatwtl,v_wheatwtl] = ode15s(@(t,vars)wheat_wt_large_correct(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_updl);

%% Absolute Period

peaks_s = [];
small_names = ["LHY","ELF3","LUX","PRR73","PRR59/TOC1","ELF4","PRR95"];
v_s = [1,14,12,6,8,10,4];

for v_i = 1:length(v_s)
    
    v = v_s(v_i);
    [~,times_of_interest] = min(abs(t_wheatwt-68));
    
    [~,peak_ps] = findpeaks(v_wheatwt(1:times_of_interest,v));
    peak_ts = t_wheatwt(peak_ps);

    name_add = strings(length(peak_ts),1);
    name_add(1:end) = small_names(v_i);
    
    peaks_s = [peaks_s;[name_add,peak_ts]];

end 

peaks_s([8,12,14,16,18,22],:) = [];
rAMP_s = rAMP(v_wheatwt,t_wheatwt,peaks_s,unique(peaks_s(:,1),"stable")',[1,14,12,6,8,10,4]);

small_cp = circ_period(peaks_s,small_names);
small_cp(:,3) = ["22.3","19.1","12","10.2","10.6","11.8","9.8"];
small_cp(:,4) = rAMP_s;

peaks_l = [];
large_names = ["LHY","ELF3","GI","LUX","PRR73","TOC1","ELF4","PRR95","PRR59"];
v_l = [1,19,29,22,8,13,16,6,10];

for v_i = 1:length(v_l)
    
    v = v_l(v_i);
    [~,times_of_interest] = min(abs(t_wheatwtl-68));
    
    [~,peak_pl] = findpeaks(v_wheatwtl(1:times_of_interest,v));
    peak_tl = t_wheatwtl(peak_pl);

    name_add = strings(length(peak_tl),1);
    name_add(1:end) = large_names(v_i);
    
    peaks_l = [peaks_l;[name_add,peak_tl]];

end 

peaks_l([6,8,10,19],:) = [];
rAMP_l = rAMP(v_wheatwtl,t_wheatwtl,peaks_l,unique(peaks_l(:,1),"stable")', ...
    [1,19,29,22,8,13,16,6,10]);

large_cp = circ_period(peaks_l,large_names);

large_cp(:,3) = ["23.9","18.9","11","12.4","7.1","12.4","14.4","6.1","11"];
large_cp(:,4) = rAMP_l;
large_cp(:,5) = ["#EDB120","#A2142F","red","#0072BD","#D95319","#77AC30","#7E2F8E","yellow","blue"];
small_cp(:,5) = large_cp([1,2,4:8],5);

load pp.mat small_cp_pp large_cp_pp

%% Plotting
colour_vec = large_cp(:,5);

rectangle("Position",[0,0,16,3],"FaceColor",[0.5,0.7450,0.9330], ...
    "EdgeColor",[0.5,0.7450,0.9330])
hold on 
rectangle("Position",[16,0,8,3],"FaceColor",[0.1,0.1,0.1], ...
    "EdgeColor",[0.1,0.1,0.1])
hold on 
rectangle("Position",[16,-0.5,8,0.3],"FaceColor",[0.5,0.5,0.5], ...
    "EdgeColor","black")
hold on 
rectangle("Position",[0,0-0.5,16,0.3],"FaceColor","white", ...
    "EdgeColor","black")
axis([0,24,-0.8,6])
axis off

for r = 1:height(large_cp)

    plot(str2double(large_cp(r,3)),str2double(large_cp(r,4)),"s", ...
        "MarkerFaceColor",colour_vec(r),"MarkerEdgeColor",colour_vec(r),"MarkerSize",30)
    hold on 

end 
plot(str2double(large_cp_pp(:,3)),str2double(large_cp_pp(:,4)),"s", ...
        "MarkerFaceColor",large_cp_pp(:,5),"MarkerEdgeColor",large_cp_pp(:,5),"MarkerSize",30)
hold on    
txt_x = str2double([large_cp(:,3);large_cp_pp(:,3)]) - 1;
txt_x([2,6,7,10]) = txt_x([2,6,7,10]) - 0.1;
txt_x([5,8,9]) = txt_x([5,8,9]) - 0.3;
txt_x(3) = txt_x(3) + 0.3;
txt_x(4) = txt_x(4) + 1.3;
txt_y = str2double([large_cp(:,4);large_cp_pp(:,4)]);
txt_y(10) = txt_y(10) - 0.23;
text(txt_x,txt_y,[large_names,large_cp_pp(:,1)], ...
    "Color","white","FontSize",15,"FontName","times")
hold on 
text([0,6,11.85,17.85,23.75],[-0.72,-0.72,-0.72,-0.72,-0.72],["0","6","12","18","24"], ...
    "Color","black","FontSize",15,"FontName","times")
title("Large Model","FontSize",15,"FontName","times")


colour_vec2 = large_cp([1,2,4:8],5);

rectangle("Position",[0,0,16,3],"FaceColor",[0.5,0.7450,0.9330], ...
    "EdgeColor",[0.5,0.7450,0.9330])
hold on 
rectangle("Position",[16,0,8,3],"FaceColor",[0.1,0.1,0.1], ...
    "EdgeColor",[0.1,0.1,0.1])
hold on 
rectangle("Position",[16,-0.5,8,0.3],"FaceColor",[0.5,0.5,0.5], ...
    "EdgeColor","black")
hold on 
rectangle("Position",[0,0-0.5,16,0.3],"FaceColor","white", ...
    "EdgeColor","black")
axis([0,24,-0.8,6])
axis off


for r = 1:height(small_cp)

    plot(str2double(small_cp(r,3)),str2double(small_cp(r,4)),"s", ...
        "MarkerFaceColor",colour_vec2(r),"MarkerEdgeColor",colour_vec2(r),"MarkerSize",30)
    hold on 

end 
 plot(str2double(small_cp_pp(:,3)),str2double(small_cp_pp(:,4)),"s", ...
        "MarkerFaceColor",small_cp_pp(:,5),"MarkerEdgeColor",small_cp_pp(:,5),"MarkerSize",30)
hold on    
txt_x = str2double([small_cp(:,3);small_cp_pp(:,3)]) - 1;
txt_x([2,4,8]) = txt_x([2,4,8]) - 0.1;
txt_x([4,7]) = txt_x([4,7]) - 0.3;
txt_x(5) = txt_x(5) + 1.3;
txt_x(3) = txt_x(5) + 1.3;
txt_y = str2double([small_cp(:,4);small_cp_pp(:,4)]);
txt_y(8) = txt_y(8) + 0.3;
text(txt_x,txt_y,[small_names,small_cp_pp(:,1)], ...
    "Color","white","FontSize",15,"FontName","times")
hold on 
text([0,6,11.85,17.85,23.75],[-0.72,-0.72,-0.72,-0.72,-0.72],["0","6","12","18","24"], ...
    "Color","black","FontSize",15,"FontName","times")
title("Compact Model","FontSize",15,"FontName","times")



%% Plotting Models
tiledlayout(3,3)

var_correspond_wt = [[3,4,5,7,9,10,11];1,8,10,12,6,4,14];
var_names_s = ["LHY","PRR59/TOC1","ELF4","LUX","PRR73","PRR95","ELF3"];



var_correspond_wtl = [3:11;1,13,16,29,22,10,8,6,19];
var_c_wtl_noGI = [[3,4,5,7,9,10,11];1,13,16,22,8,6,19];

var_names_l = ["LHY","TOC1","ELF4","GI","LUX","PRR59","PRR73","PRR95","ELF3"];

for var = 1:width(var_correspond_wt)
    
    var_sims = v_wheatwt(:,var_correspond_wt(2,var));
    var_siml = v_wheatwtl(:,var_c_wtl_noGI(2,var));
    
    min_vars = min(var_sims);
    max_vars = max(var_sims);
    minmax_varsims = (var_sims-min_vars)/(max_vars-min_vars);
    
    min_varl = min(var_siml);
    max_varl = max(var_siml);
    minmax_varsiml = (var_siml-min_varl)/(max_varl-min_varl);
  
    
    var_data = [];
    
    for rep = 1

        v_d_rep = rees_smooth_wt(rees_smooth_wt(:,1) == rep, ...
            [1,2,var_correspond_wt(1,var)]);
        
        min_vdrep = min(v_d_rep(:,3));
        max_vdrep = max(v_d_rep(:,3));

        minmax_vdrep = (v_d_rep(:,3)-min_vdrep)/(max_vdrep-min_vdrep);

        var_data = [var_data;[v_d_rep(:,1:2),minmax_vdrep]];

    end 

    nexttile
    plot1 = plot(t_wheatwt,minmax_varsims,"red", ...
        t_wheatwtl,minmax_varsiml,"blue",...
        var_data(var_data(:,1) == 1,2),var_data(var_data(:,1) == 1,3),"black");
    set(gca,"LineWidth",1.5)
    plot1(1).LineStyle = "-.";
    plot1(2).LineStyle = "-.";
    plot1(3).LineStyle = "-";
    plot1(1).LineWidth = 2.4;
    plot1(2).LineWidth = 2.4;
    plot1(3).LineWidth = 0.7;
    xlim([0,68])
    ylim([-0.02,1.02])
    set(gca,'fontname','times')
    set(gca,"FontSize",12)
    set(gca,'TickLength',[0,0])
    xline([0:24:240],':','HandleVisibility','off');
    set(gcf,'color','w');
    title(var_names_s(var))
    if(var == 3)
        lgd = legend("Compact Model","Large Model","Experimental Data");
        lgd.Location = "northeastoutside";
        lgd.FontSize = 15;
    end 

end 


for var = 3
    
    var_siml = v_wheatwtl(:,var_correspond_wtl(2,var));
        
    min_varl = min(var_siml);
    max_varl = max(var_siml);
    minmax_varsiml = (var_siml-min_varl)/(max_varl-min_varl);
  
    var_data = [];
    
    for rep = 1:3 

        v_d_rep = webb_mat_wt(webb_mat_wt(:,1) == rep, ...
            [1,2,var_correspond_wtl(1,var)]);
        
        min_vdrep = min(v_d_rep(:,3));
        max_vdrep = max(v_d_rep(:,3));

        minmax_vdrep = (v_d_rep(:,3)-min_vdrep)/(max_vdrep-min_vdrep);

        var_data = [var_data;[v_d_rep(:,1:2),minmax_vdrep]];

    end 

    nexttile
    plot1 = plot(t_wheatwtl,minmax_varsiml,"blue",...
        var_data(var_data(:,1) == 1,2),var_data(var_data(:,1) == 1,3),"black", ...
        var_data(var_data(:,1) == 2,2),var_data(var_data(:,1) == 2,3),"black", ...
        var_data(var_data(:,1) == 3,2),var_data(var_data(:,1) == 3,3),"black");
    set(gca,"LineWidth",1.5)
    plot1(1).LineStyle = "-.";
    plot1(2).LineStyle = "-";
    plot1(3).LineStyle = "-";
    plot1(4).LineStyle = "-";
    plot1(1).LineWidth = 2.4;
    plot1(2).LineWidth = 0.7;
    plot1(3).LineWidth = 0.7;
    plot1(4).LineWidth = 0.7;
    xlim([0,72])
    ylim([-0.02,1.02])
    set(gca,'fontname','times')
    set(gca,"FontSize",12)
    set(gca,'TickLength',[0,0])
    xline([0:24:240],':','HandleVisibility','off');
    set(gcf,'color','w');
    title("GI")

end 


% Plot for Infographic
rectangle("Position",[16,0,8,5],"FaceColor",[0.1,0.1,0.1], ...
    "EdgeColor",[0.1,0.1,0.1])
hold on 
plot1 = plot(t_wheatwt,v_wheatwt(:,1),"-.", ...
    t_wheatwt,v_wheatwt(:,14),"-.",  ...
    t_wheatwt,v_wheatwt(:,16),"-.",  ...
    t_wheatwt,v_wheatwt(:,8),"-.", ...
    t_wheatwt,v_wheatwt(:,4),"-.");
plot1(1).LineWidth = 2;
plot1(2).LineWidth = 2;
plot1(3).LineWidth = 2;
plot1(4).LineWidth = 2;
plot1(5).LineWidth = 2;
xlim([0,24])
set(gca,"LineWidth",2)
set(gca,'xtick',[],'ytick',[])