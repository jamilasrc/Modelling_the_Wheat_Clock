function output = rAMP(vdata,tdata,peak_data,var_nam,var_no)

rAMP_out = [];

for v = 1:length(var_nam)
    
    var = var_nam(v);
    var_ind = var_no(v);

    p_v = str2double(peak_data(peak_data(:,1) == var,2));
    p_v = p_v(p_v >= 24);
    p_v = round(p_v,4);

    d_v = vdata(tdata >= 24 & tdata <= 72,var_ind);

    baseline = mean(d_v);

    amp = mean(vdata(ismember(round(tdata,4),p_v),var_ind) - baseline);
    rAMP = amp/baseline;

    rAMP_out = [rAMP_out,rAMP];

end 

output = rAMP_out;
