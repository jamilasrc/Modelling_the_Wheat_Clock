parms(1) = 4.58;
parms(2) = 3.0; %3.0
parms(3) = 1.27;
parms(4) = 0.5;
parms(5) = 5.0;
parms(6) = 1.0;
parms(7) = 1.1;
%parms(7) = 2;
parms(8) = 1.1;
parms(9) = 1;
parms(10) = 2; % 1

parms(11) = 0.53;
parms(12) = 0.21;
parms(13) = 0.35;
parms(14) = 0.56;
parms(15) = 0.57;
parms(16) = 0.4;
parms(17) = 0.4;
parms(18) = 0.5;

parms(19) = 0.76;
parms(20) = 0.42;
parms(21) = 1.01;
parms(22) = 0.64;
parms(23) = 0.22; % 0.6
parms(24) = 0.6;
parms(25) = 0.6;
parms(26) = 0.8;
parms(27) = 0.68;
parms(28) = 0.5;
parms(29) = 0.29; % 0.29
parms(30) = 0.48; 
parms(31) = 0.38;
parms(32) = 1.2; % 1.21
parms(33) = 0.38; % 0.38
parms(34) = 0.5;
parms(35) = 0.8;
parms(36) = 0.5;
parms(37) = 0.8;
parms(38) = 0.7;
parms(39) = 0.7;
parms(40) = 0.6;

parms(41) = 2.80;
parms(42) = 0.16; %0.16
parms(43) = 1.18;
parms(44) = 0.5;
parms(45) = 0.2; % 0.24
parms(46) = 0.23; % 0.28
parms(47) = 0.63; % 0.57
parms(48) = 1.73; % 1.73
parms(49) = 0.46;
parms(50) = 0.5; 
parms(51) = 0.6;
parms(52) = 0.3;
parms(53) = 1.9;
parms(54) = 0.3;
parms(55) = 0.5;
parms(56) = 2.0;
parms(57) = 0.3;
parms(58) = 0.5;
parms(59) = 2.0;
parms(60) = 0.8; % 0.8
parms(61) = 1.9;

parms(62) = 2.3179; 
parms(63) = 0.7446;
parms(64) = 0.8441; 
parms(65) = 0.5210; 
parms(66) = 1;
parms(67) = 1.8965; 

LHYm_init = 4.5;
LHYp_init = 4.5;
Pp_init = 3;
P95m_init = 0.9;
P95p_init = 0.9;
P73m_init = 1.5;
P73p_init = 1.5;
P5T1m_init = 0.6;
P5T1p_init = 0.6;
E4m_init = 0.5;
E4p_init = 0.5;
LUXm_init = 0.5;
LUXp_init = 0.5;
E3m_init = 1.3;
E3p_init = 1.3;
EC_init = 0.5;

init_cond_wt = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init];

%LD_cyc_typ = [30,0.75]; 
LD_cyc_typ = [0,0.5];
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD
t_end = 480;

% Run LDLD to get initial conditions
[t_wheatwt_ldld,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);

% Model Testing 
LDLD_or_LDLL = "LDLL";
[t_wheatwt,v_wheatwt] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_upd);

plot(t_wheatwt,v_wheatwt(:,1),t_wheatwt,v_wheatwt(:,14),t_wheatwt,v_wheatwt(:,8))
legend("LHY","ELF3","TOC1")

init_conditions_upd2 = v_wheatwt(end,:);
[t_static_s,v_static_s] = ode15s(@(t,vars)static_small_w(t,vars,parms),[0,t_end],init_conditions_upd2);

plot(t_static_s,v_static_s(:,1),t_static_s,v_static_s(:,14),t_static_s,v_static_s(:,8))
legend("LHY","ELF3","TOC1")

[~,p_wt_s] = findpeaks(v_wheatwt(:,1));
[~,t_wt_s] = findpeaks(-v_wheatwt(:,1));
peaks = v_wheatwt(p_wt_s);
troughs = v_wheatwt(t_wt_s);
stable_peak = peaks(end);
stable_trough = troughs(end);
amplitude = stable_peak - ((stable_peak+stable_trough)/2);
rAMP = amplitude/v_static_s(end,1);


