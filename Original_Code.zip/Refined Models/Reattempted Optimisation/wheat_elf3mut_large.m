function solutions = wheat_elf3mut_large(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ)

% Parameters 
% a = activation, r = repression, m = degradation, q = light-activated
% transcription, f and p are non-specific

% Parameters
par_a3 = parms(1);
par_a4 = parms(2);
par_a5 = parms(3);
par_a6 = parms(4);
par_a7 = parms(5);
par_a8 = parms(6);

par_f1 = parms(7);
par_f2 = parms(8);
par_f3 = parms(9);
par_f4 = parms(10);
par_f5 = parms(11);
par_f6 = parms(12);

par_m1 = parms(13);
par_m3 = parms(14);
par_m4 = parms(15);
par_m5 = parms(16);
par_m6 = parms(17);
par_m7 = parms(18);
par_m8 = parms(19);
par_m9 = parms(20);
par_m10 = parms(21);
par_m11 = parms(22);
par_m12 = parms(23);
par_m13 = parms(24);
par_m14 = parms(25);
par_m15 = parms(26);
par_m16 = parms(27);
par_m17 = parms(28);
par_m18 = parms(29);
par_m19 = parms(30);
par_m20 = parms(31);
par_m21 = parms(32);
par_m22 = parms(33);
par_m23 = parms(34);
par_m24 = parms(35);
par_m25 = parms(36);
par_m26 = parms(37);
par_m27 = parms(38);
par_m28 = parms(39); 
par_m29 = parms(40);
par_m30 = parms(41);
par_m31 = parms(42);
par_m32 = parms(43);
par_m33 = parms(44);
par_m34 = parms(45);
par_m35 = parms(46);
par_m36 = parms(47);
par_m37 = parms(48);
par_m38 = parms(49);
par_m39 = parms(50);
par_m42 = parms(51);
par_m43 = parms(52);
par_m44 = parms(53);
par_m45 = parms(54);
par_m46 = parms(55);
par_m47 = parms(56);

par_n5 = parms(57);
par_n6 = parms(58);
par_n14 = parms(59);

par_p6 = parms(60);
par_p7 = parms(61);
par_p10 = parms(62);
par_p11 = parms(63);
par_p12 = parms(64);
par_p13 = parms(65);
par_p14 = parms(66);
par_p15 = parms(67);
par_p16 = parms(68);
par_p23 = parms(69);
par_p25 = parms(70);
par_p28 = parms(71);
par_p29 = parms(72);

par_q1 = parms(73);
par_q3 = parms(74);

par_r1 = parms(75);
par_r2 = parms(76);
par_r3 = parms(77); 
par_r4 = parms(78);
par_r5 = parms(79);
par_r6 = parms(80);
par_r7 = parms(81);
par_r8 = parms(82);
par_r9 = parms(83);
par_r10 = parms(84);
par_r11 = parms(85);
par_r12 = parms(86);
par_r13 = parms(87);
par_r14 = parms(88);
par_r15 = parms(89);
par_r16 = parms(90);
par_r17 = parms(91);
par_r18 = parms(92);
par_r19 = parms(93);
par_r20 = parms(94);
par_r21 = parms(95);
par_r22 = parms(96);
par_r23 = parms(97);
par_r24 = parms(98);
par_r25 = parms(99);
par_r26 = parms(100);
par_r27 = parms(101);
par_r28 = parms(102);
par_r29 = parms(103);
par_r30 = parms(104);
par_r31 = parms(105);
par_r32 = parms(106);
par_r33 = parms(107);
par_r34 = parms(108);
par_r35 = parms(109);
par_r36 = parms(110);
par_r37 = parms(111);
par_r38 = parms(112);
par_r40 = parms(113);

par_t5 = parms(114);
par_t6 = parms(115);
par_t7 = parms(116);
par_t8 = parms(117);
par_t9 = parms(118);

% New weighted parameters
par_w1 = parms(119); % term for altering LC activity (without changing LHY and CCA1 abundance)
par_w2 = parms(120); % term for altering ELF3-4 and ELF3 association with LUX in the EC
par_w3 = parms(121); % term for altering LC_c activation of ELF3 (proxy for activation of the ELF3 morning elements)

% Modified parameters test for matching wheat data
%%% 
%%% par_r8 = 1; % reduced repression by LC on PRR7
%%% par_m23 = 0.005; % reduced PRR7 protein dark degradation
%%% par_r40 = 0.3; % reduce repression by PRR5
%%% par_r9 = 0; % remove repression by EC on PRR7
%%% par_r21 = 3; % get EC to peak earlier
%%% par_r22 = 1; % get EC to peak earlier
%%% par_r28 = 5; % get EC to peak ealier
%%% par_r23 = 3;% get LUX to peak earlier
%%% par_r24 = 8; % get LUX to peak earlier
%%% par_r12 = 1; % Reduce PRR expression to alter RVE8 to alter EC
%%% par_r5 = 0.05; % Reduce PRR expression to alter RVE8 to alter EC
%%% par_q3 = 0.1; % Reduce PRR expression to alter RVE8 to alter EC

% Variables - only the variables for differential equations (see line ...
% for explanataion). 

% From the Fogelmark model (F2014), generally I have removed most dimer
% activity and have removed nuclear and cytosolic localisation. This is
% because, from inspection of the data, these factors have little impact on
% regulating other variables (particularly the dimers). 

LHY_m = vars(1);
LHY_p = vars(2);
CCA1_m = vars(3);
CCA1_p = vars(4);
P_p = vars(5); % dark accumulator - i think the same as P in the last model
P9_m = vars(6);
P9_p = vars(7); 
P7_m = vars(8);
P7_p = vars(9);
P5_m = vars(10);
P5_pc = vars(11);
P5_pn = vars(12);
TOC1_m = vars(13);
TOC1_pn = vars(14);
TOC1_pc = vars(15);
E4_m = vars(16);
E4_p = vars(17);
E4D = vars(18);
LUX_m = vars(19);
LUX_p = vars(20);
COP1_pc = vars(21);
COP1_pn = vars(22);
COP1D = vars(23);
ZTL_p = vars(24);
ZG_p = vars(25);
GI_m = vars(26);
GI_pc = vars(27);
GI_pn = vars(28);
NOX_m = vars(29);
NOX_p = vars(30);
RVE8_m = vars(31);
RVE8_p = vars(32);



%E3_m = vars(19);
%E3_p = vars(20);
%E34 = vars(21);
%LUX_m = vars(22);
%LUX_p = vars(23);
%COP1_pc = vars(24);
%COP1_pn = vars(25);
%COP1D = vars(26);
%ZTL_p = vars(27);
%ZG_p = vars(28);
%GI_m = vars(29);
%GI_pc = vars(30);
%GI_pn = vars(31);
%NOX_m = vars(32);
%NOX_p = vars(33);
%RVE8_m = vars(34);
%RVE8_p = vars(35);

if(LDLD_or_LDLL == "LDLD")
    
    L = round(0.5*sind(15*t-LD_cyc_typ(1))+LD_cyc_typ(2)); % this means L starts as 1, so a standard LDLD cycle occurs 
    D = 1 - L; % So D is always the opposite of L 

elseif(LDLD_or_LDLL == "LDLL")
    
    if(t > 24)
    L = 1;
    D = 0;
    else 
    L = round(0.5*sind(15*t-LD_cyc_typ(1))+LD_cyc_typ(2));
    D = 1 - L;
    end 

end 

% Non-differential equations will not be returned in solutions. 
% Make a note of the ODEs associated with the EC and LC instead - these
% will be good to plot (can be plot by summing components of each complex
% together, taking into account weightings in the model)

% From the simplification of ODEs, I have generally cut down the equations
% rather than doing too much rearranging to find the correct parameter
% combination, since these will be changed for the wheat clock model
% anyway. Hopefully my changes are appropriate. 

% elf3 lof phenotype
E3_m = 0;
E3_p = 0;
E34 = 0;


% Non-ODEs and Other Expressions
LC = par_w1*(LHY_p + par_f5*CCA1_p); 
% Common expression found in lots of ODEs involving morning complex
% components. Done for ease alone.
LC_c = ((par_q1*L*P_p)+1)/(1+(par_r1*P9_p)^2+(par_r2*P7_p)^2+(par_r3*P5_pn)^2+ ...
    (par_r4*TOC1_pn)^2);
% Evening Complex (Use same weightings and equation for plotting)
EC = par_w2*((LUX_p+par_f6*NOX_p)*par_w3*(E34+par_f1*E3_p))/(1+par_f3*(LUX_p+par_f2*NOX_p)+ ...
   par_f4*par_w3*(E34+par_f1*E3_p));
% PRR5 translocation to cytosol
P5_trans = par_t5*P5_pc - par_t6*P5_pn;
% TOC1 translocation
TOC1_trans = par_t7*TOC1_pc - (par_t8/(1+par_m37*P5_pn))*TOC1_pn;
%ELF3-4 dimerisation
E34_prod = par_p25*E3_p*E4D;
% ELF3 degradation common expression
E3_deg = par_m30*COP1D + par_m29*COP1_pn + par_m9 + par_m10*GI_pn; 
% ZTL-GI dimer formation - included because it was mentioned as important
% in my essays
ZG_prod = par_p12*ZTL_p*GI_pc - (par_p13*D+par_p10*L)*ZG_p;
% GI translocation 
GI_trans = par_p28*GI_pc - (par_p29/(1+par_t9*(E3_p+E34)))*GI_pn;

% ODEs
% Change in LHY mRNA
dLHY_m = (LC_c/(1+(par_r11*LC)^2)) - par_m1*LHY_m;
% Change in LHY protein 
dLHY_p = ((L+par_m4*D)*LHY_m) - par_m3*LHY_p; 
% Change in CCA1 mRNA
dCCA1_m = (LC_c) - par_m1*CCA1_m;
% Change in CCA1 protein 
dCCA1_p = (L+par_m4*D)*CCA1_m - par_m3*CCA1_p; 
% Change in P protein (dark accumulator)
dP_p = par_p7*D*(1-P_p) - par_m11*L*P_p;
% Change in PRR9 mRNA
dP9_m = (par_q3*L*0.1 - par_m12*P9_m) + ((1+par_a3*par_r33*RVE8_p)/( ...
    (1+par_r33*RVE8_p)*(1+(par_r5*LC)^2)*(1+(par_r6*EC)^2)* ...
    (1+(par_r7*TOC1_pn)^2)*(1+(par_r40*P5_pn)^2)));
% Change in PRR9 protein
dP9_p = P9_m - par_m13*P9_p; 
% Change in PRR7 mRNA
dP7_m = (1/((1+(par_r8*LC)^2)*(1+(par_r9*EC)^2)*(1+(par_r10*TOC1_pn)^2)* ...
    (1+(par_r40*P5_pn)^2))) - (par_m14*P7_m); 
% Change in PRR7 protein 
dP7_p = P7_m - (par_m15+par_m23*D)*P7_p; 
% Change in PRR5 mRNA
dP5_m = ((1+(par_a4*par_r34*RVE8_p))/((1+par_r34*RVE8_p)*(1+(par_r12*LC)^2)* ...
    (1+(par_r13*EC)^2)*(1+(par_r14*TOC1_pn)^2))) - (par_m16*P5_m);
% Change in PRR5 protein (cytosolic)
dP5_pc = P5_m - (par_m17+par_m24*ZTL_p)*P5_pc - P5_trans; % change par_m17+par_m42 into 1 parameter
% Change in PRR5 protein (nuclear)
dP5_pn = P5_trans - par_m42*P5_pn;
% Change in TOC1 mRNA
dTOC1_m = ((1+par_a5*par_r35*RVE8_p)/((1+par_r35*RVE8_p)*(1+(par_r15*LC)^2)* ...
    (1+(par_r16*EC)^2)*(1+(par_r17*TOC1_pn)^2))) - (par_m5*TOC1_m);
% Change in TOC1 protein (nuclear)
dTOC1_pn = TOC1_trans - (par_m43/(1+par_m38*P5_pn))*TOC1_pn;
% Change in TOC1 protein (cytosolic)
dTOC1_pc = TOC1_m - (par_m8+par_m6*ZTL_p)*TOC1_pc - TOC1_trans;
% Change in ELF4 mRNA
dE4_m = ((1+par_a6*par_r36*RVE8_p)/((1+par_r36*RVE8_p)*(1+(par_r18*EC)^2)* ...
    (1+(par_r19*LC)^2)*(1+(par_r20*TOC1_pn)^2))) - (par_m7*E4_m); 
% Change in ELF4 protein 
dE4_p = par_p23*E4_m - par_m35*E4_p - E4_p^2; % Change the values a bit to include dimerisation
% Change in ELF4 dimer
dE4D = E4_p^2 - par_m36*E4D - E34_prod;
% Change in ELF3 mRNA 
%dE3_m = (1/(1+(par_r21*LC)^2)*(1+(par_r21*TOC1_pn)^2)) - par_m26*E3_m; 
% Change in ELF3 protein 
%dE3_p = par_p16*E3_m - E34_prod - E3_deg*E3_p; 
% Change in ELF3-4 dimer
%dE34 = E34_prod - par_m22*E34*E3_deg;
% Change in LUX mRNA
dLUX_m = ((1+(par_a7*par_r37*RVE8_p))/((1+par_r37*RVE8_p)*(1+(par_r22*EC)^2)* ...
    (1+(par_r23*LC)^2)*(1+(par_r24*TOC1_pn)^2))) - (par_m34*LUX_m); 
% Change in LUX protein 
dLUX_p = LUX_m - par_m39*LUX_p; 
% Change in COP1 protein (cytosolic)
dCOP1_pc = par_n5 - par_p6*COP1_pc - (1+par_p15*L)*par_m27*COP1_pc;
% Change in COP1 protein (nuclear)
dCOP1_pn = par_p6*COP1_pc - (par_n14+par_n6*L*P_p)*COP1_pn - (1+par_p15*L)*par_m27*COP1_pn;
% Change in COP1 dimer
dCOP1D = (par_n14+par_n6*L*P_p)*COP1_pn - par_m31*(1+par_m33*D)*COP1D;
% Change in ZTL protein 
dZTL_p = par_p14 - ZG_prod - par_m20*ZTL_p; 
% Change in ZTL-GI 
dZG_p = ZG_prod - par_m21*ZG_p; 
% Change in GI mRNA
dGI_m = ((1+(par_a8*par_r38*RVE8_p))/((1+par_r38*RVE8_p)*(1+(par_r25*EC)^2)* ...
    (1+(par_r26*LC)^2)*(1+(par_r27*TOC1_pn)^2))) - (par_m18*GI_m); 
% Change in GI protein (cytosolic)
dGI_pc = par_p11*GI_m - ZG_prod - GI_trans - par_m19*GI_pc;
% Change in GI protein (nuclear)
dGI_pn = GI_trans - par_m19*GI_pn - par_m25*(E3_p+E34)*( ...
    1+par_m28*COP1D+par_m32*COP1_pn)*GI_pn;
% Change in NOX mRNA
dNOX_m = (1/(1+(par_r28*LC)^2)*(1+(par_r29*P7_p)^2)) - (par_m44*NOX_m);
% Change in NOX protein 
dNOX_p = NOX_m - par_m45*NOX_p; 
% Change in RVE8 mRNA
dRVE8_m = (1/(1+(par_r30*P9_p)^2+(par_r31*P7_p)^2+(par_r32*P5_pn)^2)) - par_m46*RVE8_m;
% Change in RVE8 protein 
dRVE8_p = RVE8_m - par_m47*RVE8_p; 

% Compile differential equations ONLY
%solutions = [dLHY_m;dLHY_p;dCCA1_m;dCCA1_p;dP_p;dP9_m;dP9_p;dP7_m;dP7_p;dP5_m;
%    dP5_pc;dP5_pn;dTOC1_m;dTOC1_pn;dTOC1_pc;dE4_m;dE4_p;dE4D;dE3_m;dE3_p;dE34;
%    dLUX_m;dLUX_p;dCOP1_pc;dCOP1_pn;dCOP1D;dZTL_p;dZG_p;dGI_m;dGI_pc;dGI_pn;
%    dNOX_m;dNOX_p;dRVE8_m;dRVE8_p];

solutions = [dLHY_m;dLHY_p;dCCA1_m;dCCA1_p;dP_p;dP9_m;dP9_p;dP7_m;dP7_p;dP5_m;
    dP5_pc;dP5_pn;dTOC1_m;dTOC1_pn;dTOC1_pc;dE4_m;dE4_p;dE4D;
    dLUX_m;dLUX_p;dCOP1_pc;dCOP1_pn;dCOP1D;dZTL_p;dZG_p;dGI_m;dGI_pc;dGI_pn;
    dNOX_m;dNOX_p;dRVE8_m;dRVE8_p];

