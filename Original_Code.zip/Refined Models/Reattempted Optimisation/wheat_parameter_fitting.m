%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Parameter Fitting %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function optim_params = wheat_parameter_fitting(parms_changed,params_init,model,iterations,learn_rate, ...
    data_in,var_correspond_wt,init_cond_wt)

%% initialise parameter fitting array
param_change = zeros(iterations+1,length(parms_changed)+1); % intiate vector for plotting parameter value change over time
param_change(:,1) = 0:iterations; % add iteration no. for plotting 
param_change(1,2:end) = params_init(parms_changed); % add initial parameter values 

%% Initialise Cost Function Array
cost = zeros(iterations+1,length(parms_changed)+1); 
cost(:,1) = 0:iterations; 

%% Calculate Initial Cost

% run initial simulations  with initial parameters
parms = params_init;

%osc_typ = [0,0.5];
%LD_cyc_typ = osc_typ;
%LD_typ = "LDLL";

%model = @wheat_simple; 

LD_cyc_typ = [30,0.75];
LDLD_or_LDLL = "LDLD";
t_end = 480;

[~,sol_init_LD] = ode15s(@(t,vars)model(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond_wt);
init_cond_upd_init = sol_init_LD(end,:);

LDLD_or_LDLL = "LDLL";
[times_init,sol_init] = ode15s(@(t,vars)model(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond_upd_init);

cost_init = cost_function(data_in,times_init,sol_init,var_correspond_wt);

%% initialise cost 

cost(1,2:end) = cost_init;

%% Parameter Fitting

% set delta (change in parameter)
delta_p = 0.1;

for i = 1:iterations 
    
    %i = 1;

    disp(i)
    cost_i = [];
    param_i = [];
    
    param_i = param_change(i,2:end);

    for parm = 1:(width(param_change)-1)
        
        %parm = 1;
        %clear parms
        %parms = param_i;
        parm_i = [];
        
        clear parms
        parms = params_init;
        parms(parms_changed) = param_change(i,2:end);
        
        parm_plus_dp = parms(parm) + delta_p;
        parms(parm) = parm_plus_dp;
        
        LDLD_or_LDLL = "LDLD";
        [~,sol_i_ld] = ode15s(@(t,vars)model(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond_wt);
        init_cond_upd = sol_i_ld(end,:);
        
        LDLD_or_LDLL = "LDLL";
        [times_i,sol_i] = ode15s(@(t,vars)model(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond_upd);
 
        cost_i_p = cost_function(data_in,times_i,sol_i,var_correspond_wt); 

        dcostdp = (cost_i_p - cost(i,parm+1))/delta_p;

        %parm_i = param_change(i,parm+1) - learn_rate*(1/length(parms))*dcostdp; 
        parm_i = param_change(i,parm+1) - learn_rate*dcostdp; 
       
        param_i(parm) = parm_i;
        cost_i(parm) = cost_i_p;

    end 
    
    param_change(i+1,2:end) = param_i;
    cost(i+1,2:end) = cost_i; 
    
end

optim_params{1} = param_change(end,2:end);
optim_params{2} = param_change;
optim_params{3} = cost;
