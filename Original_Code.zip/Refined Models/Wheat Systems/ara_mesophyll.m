function solutions = ara_mesophyll(t,vars,LDLD_or_LDLL,LD_cyc)

%% L/D activation
if(LD_cyc == "Normal Day")

    LD_cyc_typ = [0,0.5];
    Photosynthesis_term = sind(15*t);

elseif(LD_cyc == "Long Day")

    LD_cyc_typ = [30,0.75];
    Photosynthesis_term = sind(15*t-30) + 0.5;

end

if(LDLD_or_LDLL == "LDLD")
    
    L = round(0.5*sind(15*t-LD_cyc_typ(1))+LD_cyc_typ(2)); 
    D = 1 - L;  

elseif(LDLD_or_LDLL == "LDLL")
    
    if(t > 24)
    L = 1;
    D = 0;
    else 
    L = round(0.5*sind(15*t-LD_cyc_typ(1))+LD_cyc_typ(2));
    D = 1 - L;
    end 

end 


%% Clock Parameters

par_v1 = 4.58;
par_v1L = 3.0;
par_v2A = 1.27;
par_v2L = 5.0;
par_v3 = 1.0;
par_v4 = 1.47;
par_k1L = 0.53;
par_k1D = 0.21;
par_k2 = 0.35;
par_k3 = 0.56;
par_k4 = 0.57;
par_p1 = 0.76;
par_p1L = 0.42;
par_p2 = 1.01;
par_p3 = 0.64;
par_p4 = 1.01;
par_d1 = 0.68;
par_d2D = 0.5;
par_d2L = 0.29;
par_d3D = 0.48;
par_d3L = 0.38;
par_d4D = 1.21;
par_d4L = 0.38;
par_K0 = 2.80;
par_K1 = 0.16;
par_K2 = 1.18;
par_K4 = 0.28;
par_K5 = 0.57;
par_K5b = 1.73;
par_K6 = 0.46;
par_K7 = 2.0;
par_K8 = 0.36;
par_K9 = 1.9;
par_K10 = 1.9;

%% Clock Variables 
CL_m = vars(1); % CL (CAA1/LHY) mrna
CL_p = vars(2); % CL protein 
P97_m = vars(3); % P97 (PRR9/7) mrna 
P97_p = vars(4); % P97 protein
P51_m = vars(5); % P51 (PRR5/TOC1) mrna
P51_p = vars(6); % P51 (PRR5/TOC1) protein 
EL_m = vars(7); % EL (ELF4/LUX) mrna 
EL_p = vars(8); % EL protein 
P_p = vars(9); % P (unknown protein involved in light activation of the clock) protein 

%% Non-ODEs
EC = 3*EL_p;

%% Differential Equation System (to go in solutions)
% Change in CL mRNA
dCL_m = (par_v1+par_v1L*L*P_p)/(1+(CL_p/par_K0)^2+(P97_p/par_K1)^2+(P51_p/par_K2)^2) - ( ...
    par_k1L*L+par_k1D*D)*CL_m;
% Change in CL protein 
dCL_p = (par_p1+par_p1L*L)*CL_m - par_d1*CL_p;
% Change in P97 mRNA
dP97_m = (par_v2L*L*P_p+par_v2A)/(1+(P51_p/par_K4)^2+(EC/par_K5)^2+(CL_p/par_K5b)^2) - ( ...
    par_k2*P97_m);
% Change in P97 protein 
dP97_p = par_p2*P97_m - (par_d2D*D+par_d2L*L)*P97_p;
% Change in P51 mRNA
dP51_m = par_v3/(1+(CL_p/par_K6)^2+(P51_p/par_K7)^2) - par_k3*P51_m;
% Change in P51 protein
dP51_p = par_p3*P51_m - (par_d3D*D+par_d3L*L)*P51_p;
% Change in EL mRNA 
dEL_m = (L*par_v4)/(1+(CL_p/par_K8)^2+(P51_p/par_K9)^2+(EC/par_K10)^2) - ( ...
    par_k4*EL_m);
% Change in EL protein
dEL_p = par_p4*EL_m - (par_d4D*D+par_d4L*L)*EL_p;
% Change in P protein 
dP_p = 0.3*(1-P_p)*D - P_p*L;

%% Photosynthesis and Starch Usage (P+SC) Parameters
par_ppsu1 = 5;
par_ppsu2 = 0.2;
par_ppsu3 = 0.6;
par_ppsu4 = 0.0023;
par_ppsu5 = 0.02;
par_ppsu6 = 0.06;
par_ppsu7 = 0.012;
par_ppsu8 = 0.02;
par_ppsu9 = 0.5;
par_ppsu10 = 0.03;

par_Kpsu1 = 1;
par_Kpsu2 = 1;
par_Kpsu3 = 0.2;
par_Kpsu4 = 0.4;
par_Kpsu4act = 0.2;
par_Kpsu5 = 0.2;
par_Kpsu6 = 0.07;

par_dpsu3 = 0.2;
par_dpsu4 = 1;
par_dpsu5 = 0.5;
par_dpsu6 = 0;

par_gpsu1 = 3;
par_gpsu2 =  0.05;
par_gpsu3 = 0.3;

%% P+SC Variables
Sucrose = vars(10);
Starch = vars(11);
Suc_sensor = vars(12);
S_deg_regulator = vars(13);
Beta = vars(14);
Alpha = vars(15);

%% P+SC Non-ODEs
Photosynthesis = par_ppsu1*L*Photosynthesis_term; 
F_Alpha_plus = (par_ppsu7+par_ppsu8+par_ppsu9*L*P_p)/(1+(CL_p/par_Kpsu5)^2);
F_Alpha_minus = (par_ppsu10+D)/(1+(P97_p/par_Kpsu6)^2);

%% P+SC ODEs
% Sucrose Availibity 
dSucrose = par_ppsu9*Starch*(par_dpsu6+S_deg_regulator*D) + (1-par_ppsu2)*Photosynthesis - par_gpsu1*Sucrose*(par_gpsu2+par_gpsu3*D);
% Starch Production
dStarch = par_ppsu2*Photosynthesis - par_ppsu9*Starch*(par_dpsu6+S_deg_regulator*D);
% Carbon Availibility/Sucrose Sensor
dSuc_sensor = par_ppsu3*Beta*(1-(Sucrose^3/(Sucrose^3+par_Kpsu1^3))) - par_dpsu3*Suc_sensor;
% Starch Degradation
dS_deg_regulator = par_ppsu4*Alpha*Starch*L*(1+par_Kpsu2/(1+(Suc_sensor/par_Kpsu3)^2) ...
    ) - par_dpsu4*L*S_deg_regulator;
% Beta
dBeta = par_ppsu5/(1+(P51_p/par_Kpsu4)^2) + par_ppsu6*((CL_p^2)/(CL_p^2+par_Kpsu4act^2)) - par_dpsu5*L*Beta;
% Alpha
dAlpha = F_Alpha_plus - F_Alpha_minus*Alpha;

solutions = [dCL_m;dCL_p;dP97_m;dP97_p;dP51_m;dP51_p;dEL_m;dEL_p;dP_p;
    dSucrose;dStarch;dSuc_sensor;dS_deg_regulator;dBeta;dAlpha];

