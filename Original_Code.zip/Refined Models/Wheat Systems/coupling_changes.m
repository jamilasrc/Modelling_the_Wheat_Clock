function output_list = coupling_changes(t_reference,v_reference,couplevals1,couplevals2)

clock = [];
stomatal_activity = [];
starch_activity = zeros(100,length(couplevals1));
growth_activity = [];

for ind = 1:length(couplevals1)

    parms_list = {};

    % Guard Cell Model

    parms(1) = 6.65;
    parms(2) = 3.0; %3.0
    parms(3) = 1.27;
    parms(4) = 0.5;
    parms(5) = 5.0;
    parms(6) = 1.0;
    parms(7) = 1.03;
    parms(8) = 9.45;
    parms(9) = 0.220;
    parms(10) = 2.24;

    parms(11) = 0.53;
    parms(12) = 0.21;
    parms(13) = 0.35;
    parms(14) = 0.56;
    parms(15) = 0.57;
    parms(16) = 0.4;
    parms(17) = 0.4;
    parms(18) = 0.5;

    parms(19) = 0.76;
    parms(20) = 0.42;
    parms(21) = 1.01;
    parms(22) = 0.64;
    parms(23) = 0.22; % 0.6
    parms(24) = 0.6;
    parms(25) = 0.6;
    parms(26) = 0.8;
    parms(27) = 0.68;
    parms(28) = 0.5;
    parms(29) = 0.29; % 0.29
    parms(30) = 0.48;
    parms(31) = 0.38;
    parms(32) = 1.2; % 1.21
    parms(33) = 0.38; % 0.38
    parms(34) = 0.5;
    parms(35) = 0.8;
    parms(36) = 0.5;
    parms(37) = 0.8;
    parms(38) = 0.7;
    parms(39) = 0.7;
    parms(40) = 0.6;

    parms(41) = 2.80;
    parms(42) = 0.16; %0.16
    parms(43) = 1.18;
    parms(44) = 0.5;
    parms(45) = 0.2; % 0.24
    parms(46) = 0.23; % 0.28
    parms(47) = 0.63; % 0.57
    parms(48) = 1.73; % 1.73
    parms(49) = 0.46;
    parms(50) = 0.5;
    parms(51) = 0.6;
    parms(52) = 0.3;
    parms(53) = 1.9;
    parms(54) = 0.3;
    parms(55) = 0.5;
    parms(56) = 2.0;
    parms(57) = 0.3;
    parms(58) = 0.5;
    parms(59) = 2.0;
    parms(60) = 0.8; % 0.8
    parms(61) = 1.9;

    parms(62) = 2.3179;
    parms(63) = 0.7446;
    parms(64) = 0.8441;
    parms(65) = 0.5210;
    parms(66) = 1;
    parms(67) = 1.8965;

    parms(68) = couplevals1(ind); % mesophyll second model
    parms(69) = couplevals2(ind); % epidermis thrird

    % sc
    parms(70) = 0.5; % 0.5
    parms(71) = 0.7; % 0.2
    parms(72) = 0.3; % 0.5

    parms(73) = 0.2; % 0.2
    parms(74) = 0.1; % 0.1
    parms(75) = 0.1; % 0.1
    parms(76) = 0.5; % 0.1

    parms(77) = 0.1; % 0.1
    parms(78) = 0.3; % 0.3
    parms(79) = 0.2; % 0.2
    parms(80) = 0.3; % 0.3

    parms(81) = 0.4; % 0.4

    parms(82) = 0.2; % 0.2
    parms(83) = 1; % 1
    parms(84) = 0.3; % 0.3
    parms(85) = 0.3;
    parms(86) = 0.3;

    parms_to_fit_sc = parms;
    parms_list{1} = parms_to_fit_sc;
    clear parms

    % Mesophyll Model

    parms(1) = 0.233;
    parms(2) = 3.0; %3.0
    parms(3) = 1.27;
    parms(4) = 0.5;
    parms(5) = 5.0;
    parms(6) = 1.0;
    parms(7) = 7.72;
    parms(8) = 8.06;
    parms(9) = 7.93;
    parms(10) = 8.31; % 1

    parms(11) = 0.53;
    parms(12) = 0.21;
    parms(13) = 0.35;
    parms(14) = 0.56;
    parms(15) = 0.57;
    parms(16) = 0.4;
    parms(17) = 0.4;
    parms(18) = 0.5;

    parms(19) = 0.76;
    parms(20) = 0.42;
    parms(21) = 1.01;
    parms(22) = 0.64;
    parms(23) = 0.22; % 0.6
    parms(24) = 0.6;
    parms(25) = 0.6;
    parms(26) = 0.8;
    parms(27) = 0.68;
    parms(28) = 0.5;
    parms(29) = 0.29; % 0.29
    parms(30) = 0.48;
    parms(31) = 0.38;
    parms(32) = 1.2; % 1.21
    parms(33) = 0.38; % 0.38
    parms(34) = 0.5;
    parms(35) = 0.8;
    parms(36) = 0.5;
    parms(37) = 0.8;
    parms(38) = 0.7;
    parms(39) = 0.7;
    parms(40) = 0.6;

    parms(41) = 2.80;
    parms(42) = 0.16; %0.16
    parms(43) = 1.18;
    parms(44) = 0.5;
    parms(45) = 0.2; % 0.24
    parms(46) = 0.23; % 0.28
    parms(47) = 0.63; % 0.57
    parms(48) = 1.73; % 1.73
    parms(49) = 0.46;
    parms(50) = 0.5;
    parms(51) = 0.6;
    parms(52) = 0.3;
    parms(53) = 1.9;
    parms(54) = 0.3;
    parms(55) = 0.5;
    parms(56) = 2.0;
    parms(57) = 0.3;
    parms(58) = 0.5;
    parms(59) = 2.0;
    parms(60) = 0.8; % 0.8
    parms(61) = 1.9;

    parms(62) = 2.3179;
    parms(63) = 0.7446;
    parms(64) = 0.8441;
    parms(65) = 0.5210;
    parms(66) = 1;
    parms(67) = 1.8965;

    parms(68) = couplevals1(ind); % mesophyll to guard cell
    parms(69) = couplevals1(ind); % to epidermis

    % Starch-Sucrose Metabolism
    parms(70) = 5;
    parms(71) = 0.2; % 0.2
    parms(72) = 0.6;
    parms(73) = 0.0023;
    parms(74) = 0.02;
    parms(75) = 0.06;
    parms(76) = 0.012;
    parms(77) = 0.02;
    parms(78) = 0.5; % 0.23
    parms(79) = 0.03;

    parms(80) = 1;
    parms(81) = 1;
    parms(82) = 0.2;
    parms(83) = 0.4;
    parms(84) = 0.2;
    parms(85) = 0.2;
    parms(86) = 0.07;

    parms(87) = 0.2;
    parms(88) = 1;
    parms(89) = 0.5;
    parms(90) = 0;

    parms(91) = 3;
    parms(92) = 0.05;
    parms(93) = 0.3;

    parms_fit_ss = parms;
    parms_list{2} = parms_fit_ss;
    clear parms

    % Epidermis Model

    parms(1) = 7.1751;
    parms(2) = 3.0; %3.0
    parms(3) = 1.27;
    parms(4) = 0.5;
    parms(5) = 5.0;
    parms(6) = 1.0;
    parms(7) = 0.0124;
    parms(8) = 9.93;
    parms(9) = 0.125;
    parms(10) = 0.736; % 1

    parms(11) = 0.53;
    parms(12) = 0.21;
    parms(13) = 0.35;
    parms(14) = 0.56;
    parms(15) = 0.57;
    parms(16) = 0.4;
    parms(17) = 0.4;
    parms(18) = 0.5;

    parms(19) = 0.76;
    parms(20) = 0.42;
    parms(21) = 1.01;
    parms(22) = 0.64;
    parms(23) = 0.22; % 0.6
    parms(24) = 0.6;
    parms(25) = 0.6;
    parms(26) = 0.8;
    parms(27) = 0.68;
    parms(28) = 0.5;
    parms(29) = 0.29; % 0.29
    parms(30) = 0.48;
    parms(31) = 0.38;
    parms(32) = 1.2; % 1.21
    parms(33) = 0.38; % 0.38
    parms(34) = 0.5;
    parms(35) = 0.8;
    parms(36) = 0.5;
    parms(37) = 0.8;
    parms(38) = 0.7;
    parms(39) = 0.7;
    parms(40) = 0.6;

    parms(41) = 2.80;
    parms(42) = 0.16; %0.16
    parms(43) = 1.18;
    parms(44) = 0.5;
    parms(45) = 0.2; % 0.24
    parms(46) = 0.23; % 0.28
    parms(47) = 0.63; % 0.57
    parms(48) = 1.73; % 1.73
    parms(49) = 0.46;
    parms(50) = 0.5;
    parms(51) = 0.6;
    parms(52) = 0.3;
    parms(53) = 1.9;
    parms(54) = 0.3;
    parms(55) = 0.5;
    parms(56) = 2.0;
    parms(57) = 0.3;
    parms(58) = 0.5;
    parms(59) = 2.0;
    parms(60) = 0.8; % 0.8
    parms(61) = 1.9;

    parms(62) = 2.3179;
    parms(63) = 0.7446;
    parms(64) = 0.8441;
    parms(65) = 0.5210;
    parms(66) = 1;
    parms(67) = 1.8965;

    parms(68) = couplevals2(ind); % epidermis to gc
    parms(69) = couplevals1(ind); % epidermis to mesophyll

    % growth
    parms(70) = 0.1129;

    parms(71) = 0.3322;
    parms(72) = 0.86;

    parms(73) = 0.5293; % 0.5293

    parms(74) = 0.1591;

    parms(75) = 0.4404;
    parms(76) = 5.0712;

    parms(77) = 0.0005;
    parms(78) = 0.18;

    parms_fit_growth = parms;
    parms_list{3} = parms_fit_growth;
    clear parms

    % Initial Conditions
    init_cond = [];

    LHYm_init = 4.5;
    LHYp_init = 4.5;
    Pp_init = 3;
    P95m_init = 0.9;
    P95p_init = 0.9;
    P73m_init = 1.5;
    P73p_init = 1.5;
    P5T1m_init = 0.6;
    P5T1p_init = 0.6;
    E4m_init = 0.5;
    E4p_init = 0.5;
    LUXm_init = 0.5;
    LUXp_init = 0.5;
    E3m_init = 1.3;
    E3p_init = 1.3;
    EC_init = 0.5;

    init_cond_clock = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init];
    init_cond = [init_cond,init_cond_clock,init_cond_clock,init_cond_clock];

    ABARm_init = 0.3;
    ABARp_init = 0.3;
    AR_init = 0.2;
    PP2C_init = 0.3;
    SNRK2_init = 0.3;
    SC_init = 0.1;

    init_cond_sc = [ABARm_init,ABARp_init,AR_init,PP2C_init,SNRK2_init,SC_init];

    Suc_init = 5;
    S_prod_init = 0.1;
    Suc_sen_init = 1;
    Sdr_init = 0.5;
    Beta_init = 0.05;
    Alpha_init = 0.05;

    init_cond_ss = [Suc_init,S_prod_init,Suc_sen_init,Sdr_init,Beta_init,Alpha_init];

    PIFm_init = 0.1;
    PIFp_init = 0.1;
    HYP_init = 0.1;

    init_cond_g = [PIFm_init,PIFp_init,HYP_init];

    init_cond = [init_cond,init_cond_sc,init_cond_ss,init_cond_g];

    LD_cyc = "Long Day";
    LDLD_or_LDLL = "LDLD";
    t_end = 480;

    [~,v_ldld] = ode15s(@(t,vars_comp)unconnected_spatial_system(t,vars_comp,parms_list, ...
        LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond);
    init_cond_upd = v_ldld(end,:);
    [t_ld_ss,v_ld_ss] = ode15s(@(t,vars_comp)unconnected_spatial_system(t,vars_comp,parms_list, ...
        LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_upd);

    %% Measure Changes in the Clock through the LHYs
    t_range = 24:48;

    gc_clock_change_i = phase_shift(v_ld_ss(:,1),t_ld_ss,v_reference(:,1),t_reference);
    m_clock_change_i = phase_shift(v_ld_ss(:,17),t_ld_ss,v_reference(:,17),t_reference);
    ep_clock_change_i = phase_shift(v_ld_ss(:,33),t_ld_ss,v_reference(:,33),t_reference);

    clock = [clock;[gc_clock_change_i,m_clock_change_i,ep_clock_change_i]];

    %% Establish Timing of Night and Day
    [~,wds] = min(abs(t_ld_ss-24));
    [~,wns] = min(abs(t_ld_ss-40));
    [~,wne] = min(abs(t_ld_ss-48));

    %% Measure Changes in Stomatal Conductance
    norm_sc = normalize(v_ld_ss(:,54),"range");
    wue_i = mean(norm_sc(wns:wne));
    photo_i = mean(norm_sc(wds:wns));

    stomatal_activity = [stomatal_activity;[wue_i,photo_i]];

    %% Get Starch Phase for Plotting
    norm_starch = normalize(v_ld_ss(:,56),"range");
    starch_deg_i = norm_starch(wns:wne);

    starch_activity(1:length(starch_deg_i),[(2*ind-1),2*ind]) = [t_ld_ss(wns:wne),starch_deg_i];

    %% Measure Changes in Final Growth and Return Growth
    final_growth_i = v_ld_ss(end,63);

    growth_activity = [growth_activity,final_growth_i];

end

%% Outputs

output_list{1} = [couplevals1;couplevals2];
output_list{2} = clock;
output_list{3} = stomatal_activity;
output_list{4} = starch_activity;
output_list{5} = growth_activity;

    

