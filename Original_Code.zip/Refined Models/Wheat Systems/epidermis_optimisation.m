%% Initialising the Optimisation

parms(1) = 4.58;
parms(2) = 3.0; %3.0
parms(3) = 1.27;
parms(4) = 0.5;
parms(5) = 5.0;
parms(6) = 1.0;
parms(7) = 1.1;
parms(8) = 1.1;
parms(9) = 1;
parms(10) = 2; % 1

parms(11) = 0.53;
parms(12) = 0.21;
parms(13) = 0.35;
parms(14) = 0.56;
parms(15) = 0.57;
parms(16) = 0.4;
parms(17) = 0.4;
parms(18) = 0.5;

parms(19) = 0.76;
parms(20) = 0.42;
parms(21) = 1.01;
parms(22) = 0.64;
parms(23) = 0.22; % 0.6
parms(24) = 0.6;
parms(25) = 0.6;
parms(26) = 0.8;
parms(27) = 0.68;
parms(28) = 0.5;
parms(29) = 0.29; % 0.29
parms(30) = 0.48; 
parms(31) = 0.38;
parms(32) = 1.2; % 1.21
parms(33) = 0.38; % 0.38
parms(34) = 0.5;
parms(35) = 0.8;
parms(36) = 0.5;
parms(37) = 0.8;
parms(38) = 0.7;
parms(39) = 0.7;
parms(40) = 0.6;

parms(41) = 2.80;
parms(42) = 0.16; %0.16
parms(43) = 1.18;
parms(44) = 0.5;
parms(45) = 0.2; % 0.24
parms(46) = 0.23; % 0.28
parms(47) = 0.63; % 0.57
parms(48) = 1.73; % 1.73
parms(49) = 0.46;
parms(50) = 0.5; 
parms(51) = 0.6;
parms(52) = 0.3;
parms(53) = 1.9;
parms(54) = 0.3;
parms(55) = 0.5;
parms(56) = 2.0;
parms(57) = 0.3;
parms(58) = 0.5;
parms(59) = 2.0;
parms(60) = 0.8; % 0.8
parms(61) = 1.9;

parms(62) = 2.3179; 
parms(63) = 0.7446;
parms(64) = 0.8441; 
parms(65) = 0.5210; 
parms(66) = 1;
parms(67) = 1.8965; 

% growth
parms(68) = 0.1129;

parms(69) = 0.3322;
parms(70) = 0.86;

parms(71) = 0.5293; % 0.5293

parms(72) = 0.1591;

parms(73) = 0.4404; 
parms(74) = 5.0712;

parms(75) = 0.0005;
parms(76) = 0.18;

parms_fit_growth = parms;
clear parms

LHYm_init = 4.5;
LHYp_init = 4.5;
Pp_init = 3;
P95m_init = 0.9;
P95p_init = 0.9;
P73m_init = 1.5;
P73p_init = 1.5;
P5T1m_init = 0.6;
P5T1p_init = 0.6;
E4m_init = 0.5;
E4p_init = 0.5;
LUXm_init = 0.5;
LUXp_init = 0.5;
E3m_init = 1.3;
E3p_init = 1.3;
EC_init = 0.5;

% Growth
PIFm_init = 0.1;
PIFp_init = 0.1;
HYP_init = 0.1;

init_cond_ep = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init,PIFm_init,PIFp_init,HYP_init];

%% Genetic Algorithm
options3 = optimoptions('ga','InitialPopulationMatrix',parms_fit_growth([1,7:10]), ...
    'MaxGenerations',5000,'MaxStallGenerations',70,...
     'FunctionTolerance',1e-1,'ConstraintTolerance',1e-12);

% Iterate over algorithm several times and find a good phenotype
optim_parms_growth = [];

for i = 1:4
    
    disp(i)
    [a0i,fvali,exitflagi,outputi] = ga(@(parameters)growth_optimise(parameters,[1,7:10],parms_fit_growth,init_cond_ep), ...
    5,[],[],[],[],[0,0,0,0,0],[10,10,10,10,10],[],options3);

    optim_parms_growth = [optim_parms_growth;a0i];

end 

%0.303010874203814	0.0130829298477675	8.24613834032405	0.627899345079020	0.994469910539413
% Enhanced TOC1 expression, high and low LHY, low EC
% clock breaking phenotype at least partially observed (in LHY and ELF3),
% TOC1 has large wacky oscillations (like LUX in standard)
writematrix(optim_parms_growth,"Optimal_Growth_Parms_Alone.csv")

%% Simulation - testing the results 
parms = parms_fit_growth; 

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480;

[t_ep_ldld_og,v_ep_ldld_og] = ode15s(@(t,vars)epidermis(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_ep);
init_cond_upd_ep_og = v_ep_ldld_og(end,:);
[t_ep_og,v_ep_og] = ode15s(@(t,vars)epidermis(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_upd_ep_og);

clear parms

parms = parms_fit_growth; 
parms([1,7:10]) = optim_parms_growth(4,:);

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480;

[t_ep_ldld,v_ep_ldld] = ode15s(@(t,vars)epidermis(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_ep);
init_cond_upd_ep = v_ep_ldld(end,:);
[t_ep,v_ep] = ode15s(@(t,vars)epidermis(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_upd_ep);

plot(t_ep,v_ep(:,19),t_ep_og,v_ep_og(:,19))
legend("Optimised","Original")
xline([0:24:480],':','HandleVisibility','off');

plot(t_ep,v_ep(:,19))
xline([0:24:480],':','HandleVisibility','off');

plot(t_ep,v_ep(:,1),t_ep,v_ep(:,14),t_ep,v_ep(:,8))
legend("LHY","ELF3","TOC1")
xline([0:24:480],':','HandleVisibility','off');
