function mse = meansquareerror(times,tdata1,vdata1,tdata2,vdata2)

v1_extract = [];
v2_extract = [];

for t = times

    [~,d_add1] = min(abs(tdata1-t));
    [~,d_add2] = min(abs(tdata2-t));

    data_add1 = vdata1(d_add1);
    data_add1 = data_add1(1);
    data_add2 = vdata2(d_add2);
    data_add2 = data_add2(1);

    v1_extract = [v1_extract,data_add1];
    v2_extract = [v2_extract,data_add2];

end 

mse = mean((v1_extract-v2_extract).^2);