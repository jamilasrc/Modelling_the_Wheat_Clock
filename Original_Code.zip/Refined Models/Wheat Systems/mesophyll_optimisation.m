%% Initialising the Optimisation

parms(1) = 4.58;
parms(2) = 3.0; %3.0
parms(3) = 1.27;
parms(4) = 0.5;
parms(5) = 5.0;
parms(6) = 1.0;
parms(7) = 1.1;
parms(8) = 1.1;
parms(9) = 1;
parms(10) = 2; % 1

parms(11) = 0.53;
parms(12) = 0.21;
parms(13) = 0.35;
parms(14) = 0.56;
parms(15) = 0.57;
parms(16) = 0.4;
parms(17) = 0.4;
parms(18) = 0.5;

parms(19) = 0.76;
parms(20) = 0.42;
parms(21) = 1.01;
parms(22) = 0.64;
parms(23) = 0.22; % 0.6
parms(24) = 0.6;
parms(25) = 0.6;
parms(26) = 0.8;
parms(27) = 0.68;
parms(28) = 0.5;
parms(29) = 0.29; % 0.29
parms(30) = 0.48; 
parms(31) = 0.38;
parms(32) = 1.2; % 1.21
parms(33) = 0.38; % 0.38
parms(34) = 0.5;
parms(35) = 0.8;
parms(36) = 0.5;
parms(37) = 0.8;
parms(38) = 0.7;
parms(39) = 0.7;
parms(40) = 0.6;

parms(41) = 2.80;
parms(42) = 0.16; %0.16
parms(43) = 1.18;
parms(44) = 0.5;
parms(45) = 0.2; % 0.24
parms(46) = 0.23; % 0.28
parms(47) = 0.63; % 0.57
parms(48) = 1.73; % 1.73
parms(49) = 0.46;
parms(50) = 0.5; 
parms(51) = 0.6;
parms(52) = 0.3;
parms(53) = 1.9;
parms(54) = 0.3;
parms(55) = 0.5;
parms(56) = 2.0;
parms(57) = 0.3;
parms(58) = 0.5;
parms(59) = 2.0;
parms(60) = 0.8; % 0.8
parms(61) = 1.9;

parms(62) = 2.3179; 
parms(63) = 0.7446;
parms(64) = 0.8441; 
parms(65) = 0.5210; 
parms(66) = 1;
parms(67) = 1.8965; 

% Starch-Sucrose Metabolism
parms(68) = 5;
parms(69) = 0.2; % 0.2
parms(70) = 0.6;
parms(71) = 0.0023;
parms(72) = 0.02;
parms(73) = 0.06;
parms(74) = 0.012;
parms(75) = 0.02;
parms(76) = 0.5; % 0.23
parms(77) = 0.03;

parms(78) = 1;
parms(79) = 1;
parms(80) = 0.2;
parms(81) = 0.4;
parms(82) = 0.2;
parms(83) = 0.2;
parms(84) = 0.07;

parms(85) = 0.2;
parms(86) = 1;
parms(87) = 0.5;
parms(88) = 0;

parms(89) = 3;
parms(90) = 0.05;
parms(91) = 0.3;

parms_fit_ss = parms;
clear parms

LHYm_init = 4.5;
LHYp_init = 4.5;
Pp_init = 3;
P95m_init = 0.9;
P95p_init = 0.9;
P73m_init = 1.5;
P73p_init = 1.5;
P5T1m_init = 0.6;
P5T1p_init = 0.6;
E4m_init = 0.5;
E4p_init = 0.5;
LUXm_init = 0.5;
LUXp_init = 0.5;
E3m_init = 1.3;
E3p_init = 1.3;
EC_init = 0.5;

Suc_init = 5;
S_prod_init = 0.1;
Suc_sen_init = 1;
Sdr_init = 0.5;
Beta_init = 0.05;
Alpha_init = 0.05;

init_cond_ss = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init,Suc_init,S_prod_init,Suc_sen_init,Sdr_init,Beta_init,Alpha_init];

%% Optimisation
options_mga = optimoptions('gamultiobj','InitialPopulationMatrix',parms_fit_ss([1,7:10]), ...
    'MaxGenerations',5000,'MaxStallGenerations',70,...
     'FunctionTolerance',1e-1,'ConstraintTolerance',1e-12);

[a0mga,fval,exitflag,output] = gamultiobj(@(parameters)starchsugar_optimise(parameters,[1,7:10],parms_fit_ss,init_cond_ss), ...
    5,[],[],[],[],[0,0,0,0,0],[10,10,10,10,10],[],options_mga);
% 0.233152440832660	7.71661325228848	8.06001434306766	7.92952029214971	8.30841199215112
% only 1 solution in the parento front 

%% Plotting
parms = parms_fit_ss; 

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480;

[t_m_ldld_og,v_m_ldld_og] = ode15s(@(t,vars)mesophyll(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_ss);
init_cond_upd_m_og = v_m_ldld_og(end,:);
[t_m_og,v_m_og] = ode15s(@(t,vars)mesophyll(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_upd_m_og);

clear parms

parms = parms_fit_ss; 
parms([1,7:10]) = a0mga;

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480;

[t_m_ldld,v_m_ldld] = ode15s(@(t,vars)mesophyll(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_ss);
init_cond_upd_m = v_m_ldld(end,:);
[t_m,v_m] = ode15s(@(t,vars)mesophyll(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_upd_m);

plot(t_m_og,v_m_og(:,18),t_m,v_m(:,18))
xline([0:24:480],':','HandleVisibility','off');
xline([16:24:480],':','HandleVisibility','off');
legend("Unfitted","Fitted")

