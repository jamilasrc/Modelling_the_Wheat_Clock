function phase_dif = phase_shift(v_d,t_d,v_d_ref,t_d_ref)

[~,peaks1] = findpeaks(v_d(:,1),t_d);
phase1 = peaks1(peaks1 > 24 & peaks1 < 48);

[~,peaks2] = findpeaks(v_d_ref(:,1),t_d_ref);
phase2 = peaks2(peaks2 > 24 & peaks2 < 48);

phase_dif = phase1 - phase2;
