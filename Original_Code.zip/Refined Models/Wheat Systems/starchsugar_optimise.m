function cost = starchsugar_optimise(parameters,parm_ind,parms_init,init_cond)
% Multi-Objective GA Optimisation

%%
parms = parms_init;
parms(parm_ind) = parameters;

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480;

[t_ep,v_ep] = ode15s(@(t,vars)mesophyll(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond);

%% Minimise C Starvation at Night (Through Sucrose)
t_to_sample = 256:0.2:264;
starve_thresh = 3*10^-1;

[~,night_start] = min(abs(t_ep-256));
[~,night_end] = min(abs(t_ep-264));

t_vals = t_ep(night_start:night_end); 
final_t = [];
f_t_ind = [];

for t = t_to_sample 

    [~,t_add_ind] = min(abs(t_vals-t));
    t_add = t_vals(t_add_ind);
    final_t = [final_t,t_add(1)];
    f_t_ind = [f_t_ind,find(t_ep == t_add(1))];

end 

final_t = unique(final_t);
f_t_ind = unique(f_t_ind);

final_v = v_ep(f_t_ind,18);

derivative_list = [];

for ind = 2:length(final_t)

    delta_t = final_t(ind) - final_t(ind-1);

    dsucdt = derivative(final_v(ind-1),final_v(ind),delta_t);
    derivative_list = [derivative_list,abs(dsucdt)];

end 

starve_dev = final_t(derivative_list <= starve_thresh);

if(isempty(starve_dev) == false)

    [~,t_locate] = min(abs(final_t-starve_dev(end)));
    c_starve_time = range([starve_dev,final_t(t_locate+1)]);

elseif(isempty(starve_dev) == true)

    c_starve_time = 0;

end 

%% Maximise Sucrose Production
[~,t_start] = min(abs(t_ep-240)); % get time where steady state conditions should be reached

% get sucrose peaks and find the average
[~,suc_peaks_t] = findpeaks(v_ep(t_start:end,17),t_ep(t_start:end));
suc_peaks = v_ep(ismember(t_ep,suc_peaks_t),17);
av_suc_peaks = mean(suc_peaks); 

cost(1) = c_starve_time; % minimse time spent in c starvation
cost(2) = 1/av_suc_peaks; % maximise sucrose production, so minimise the inverse
