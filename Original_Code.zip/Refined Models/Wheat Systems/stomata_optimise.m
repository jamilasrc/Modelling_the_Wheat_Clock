function cost = stomata_optimise(parameters,parm_ind,parms_init,init_cond)
% Multi-Objective GA Optimisation

%%
parms = parms_init;
parms(parm_ind) = parameters;

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480;

[t_ep,v_ep] = ode15s(@(t,vars)guard_cells(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond);

%% Find Average Stomatal Opening at Night
% Select night time period when steady state has been reached
% night_start = 256h, night_end = 264

[~,night_start] = min(abs(t_ep-256));
[~,night_end] = min(abs(t_ep-264));

SC_night = v_ep(night_start:night_end,22);
av_open_night = mean(SC_night);

%% Find Average Stomatal Opening during the Day
[~,day_start] = min(abs(t_ep-240));
[~,day_end] = min(abs(t_ep-256));

SC_day = v_ep(day_start:day_end,22);
av_open_day = mean(SC_day);

%%
cost = 1/(av_open_day-av_open_night); % aim is to maximise stomatal opening during the day relative to night and minimise night opening relative to day to increase photosynthesis, so minimise the inverse