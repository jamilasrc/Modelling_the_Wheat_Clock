function cost = stomata_optimise_mga(parameters,parm_ind,parms_init,init_cond)
% Multi-Objective GA Optimisation
cost = zeros(1,3);

%%
parms = parms_init;
parms(parm_ind) = parameters;

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480;

[t_ep,v_ep] = ode15s(@(t,vars)guard_cells(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond);

[~,steady_state] = min(abs(t_ep-72)); % assume steady state is reached after 72h
t_ss = t_ep(steady_state:end);
v_ss = v_ep(steady_state:end,22); % Stomatal Conductance Only
v_ss = normalize(v_ss,"range"); % do minmax normalisation

day_start = (72:24:(t_end-24));
night_end = (72+24:24:t_end);
night_start = (72+16):24:(t_end-8);

%% WUE and Photosynthetic Capacity
day_sc = [];
night_sc = [];

for t = 1:length(night_end)
    
    d_s = day_start(t);
    n_s = night_start(t);
    n_e = night_end(t);

    close_times = [];

    for i = [d_s,n_s,n_e]

        [~,c_t] = min(abs(t_ss - i));
        close_times = [close_times,c_t];

    end 

    d_sc_av = mean(v_ss(close_times(1):close_times(2)));
    n_sc_av = mean(v_ss(close_times(2):close_times(3)));
    
    day_sc = [day_sc,d_sc_av];
    night_sc = [night_sc;n_sc_av];

end 

day_sc_av = mean(day_sc);
night_sc_av = mean(night_sc);

%% Get Priming for Dawn and Peak SC
[~,sc_minima] = findpeaks(-v_ss,t_ss);
[~,priming] = min(abs(sc_minima - 240)); 
dist_from_prime = sc_minima(priming) - (240-2); % should start priming for dawn 2.5h before dawn (optimial minima at 21.5h for comparison)

%% Costs
cost(1) = night_sc_av;
cost(2) = 1/(day_sc_av);
%cost(3) = dist_from_prime;