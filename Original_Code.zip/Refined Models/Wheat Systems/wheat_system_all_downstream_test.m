

%% 
parms(1) = 4.58;
parms(2) = 3.0; %3.0
parms(3) = 1.27;
parms(4) = 0.5;
parms(5) = 5.0;
parms(6) = 1.0;
parms(7) = 1.1;
%parms(7) = 2;
parms(8) = 1.1;
parms(9) = 1;
parms(10) = 2; % 1

parms(11) = 0.53;
parms(12) = 0.21;
parms(13) = 0.35;
parms(14) = 0.56;
parms(15) = 0.57;
parms(16) = 0.4;
parms(17) = 0.4;
parms(18) = 0.5;

parms(19) = 0.76;
parms(20) = 0.42;
parms(21) = 1.01;
parms(22) = 0.64;
parms(23) = 0.22; % 0.6
parms(24) = 0.6;
parms(25) = 0.6;
parms(26) = 0.8;
parms(27) = 0.68;
parms(28) = 0.5;
parms(29) = 0.29; % 0.29
parms(30) = 0.48; 
parms(31) = 0.38;
parms(32) = 1.2; % 1.21
parms(33) = 0.38; % 0.38
parms(34) = 0.5;
parms(35) = 0.8;
parms(36) = 0.5;
parms(37) = 0.8;
parms(38) = 0.7;
parms(39) = 0.7;
parms(40) = 0.6;

parms(41) = 2.80;
parms(42) = 0.16; %0.16
parms(43) = 1.18;
parms(44) = 0.5;
parms(45) = 0.2; % 0.24
parms(46) = 0.23; % 0.28
parms(47) = 0.63; % 0.57
parms(48) = 1.73; % 1.73
parms(49) = 0.46;
parms(50) = 0.5; 
parms(51) = 0.6;
parms(52) = 0.3;
parms(53) = 1.9;
parms(54) = 0.3;
parms(55) = 0.5;
parms(56) = 2.0;
parms(57) = 0.3;
parms(58) = 0.5;
parms(59) = 2.0;
parms(60) = 0.8; % 0.8
parms(61) = 1.9;

parms(62) = 2.3179; 
parms(63) = 0.7446;
parms(64) = 0.8441; 
parms(65) = 0.5210; 
parms(66) = 1;
parms(67) = 1.8965; 

% sc
parms(68) = 0.5; % 0.5
parms(69) = 0.05; % 0.2
parms(70) = 0.5; % 0.5

parms(71) = 0.2; % 0.2
parms(72) = 0.1; % 0.1
parms(73) = 0.1; % 0.1
parms(74) = 0.1;

parms(75) = 0.1; % 0.1
parms(76) = 0.3; % 0.3
parms(77) = 0.2; % 0.2
parms(78) = 0.2; % 0.3

parms(79) = 0.4; % 0.4

parms(80) = 0.2; % 0.2
parms(81) = 1; % 1
parms(82) = 0.3; % 0.3
parms(83) = 0.3;
parms(84) = 0.3; 

% starch usage
parms(85) = 5;
parms(86) = 0.55;
parms(87) = 0.6;
parms(88) = 0.0023;
parms(89) = 0.02;
parms(90) = 0.06;
parms(91) = 0.012;
parms(92) = 0.02;
parms(93) = 2; % 0.23
parms(94) = 0.03;

parms(95) = 1;
parms(96) = 1;
parms(97) = 0.2;
parms(98) = 0.4;
parms(99) = 0.2;
parms(100) = 0.2;
parms(101) = 0.07;

parms(102) = 0.2;
parms(103) = 1;
parms(104) = 0.5;

% growth
parms(105) = 0.1129;

parms(106) = 0.3322;
parms(107) = 0.86;

parms(108) = 0.5293; % 0.5293

parms(109) = 0.1591;

parms(110) = 0.4404; 
parms(111) = 5.0712;

parms(112) = 0.001;
parms(113) = 0.18;


LHYm_init = 4.5;
LHYp_init = 4.5;
Pp_init = 3;
P95m_init = 0.9;
P95p_init = 0.9;
P73m_init = 1.5;
P73p_init = 1.5;
P5T1m_init = 0.6;
P5T1p_init = 0.6;
E4m_init = 0.5;
E4p_init = 0.5;
LUXm_init = 0.5;
LUXp_init = 0.5;
E3m_init = 1.3;
E3p_init = 1.3;
EC_init = 0.5;

% SC
ABARm_init = 0.3;
ABARp_init = 0.3;
AR_init = 0.2;
PP2C_init = 0.3;
SNRK2_init = 0.3;
SC_init = 0.1;

% starch usage
Suc_init = 5;
S_prod_init = 0.1;
Suc_sen_init = 1;
Sdr_init = 0.5;
Beta_init = 0.05;
Alpha_init = 0.05;

% Growth
PIFm_init = 0.1;
PIFp_init = 0.1;
HYP_init = 0.1;

init_cond_wt = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init,ABARm_init,ABARp_init,AR_init,PP2C_init,SNRK2_init,SC_init,Suc_init,S_prod_init,Suc_sen_init,Sdr_init,Beta_init,Alpha_init,PIFm_init,PIFp_init,HYP_init];

LD_cyc_typ = [30,0.75]; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480;

% Run LDLD to get initial conditions
[t_wheatwt_ldld,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_s(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);

% Model Testing 
LDLD_or_LDLL = "LDLL";
[t_wheatwt,v_wheatwt] = ode15s(@(t,vars)wheat_s(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_upd);

plot(t_wheatwt_ldld,v_wheatwt_ldld(:,23))
xline([0:24:240],':','HandleVisibility','off');

plot(t_wheatwt_ldld,v_wheatwt_ldld(:,31))
xline([0:24:480],':','HandleVisibility','off');

LD_cyc_typ = [30,0.75]; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480;

[t_wheatwt_ldld2,v_wheatwt_ldld2] = ode15s(@(t,vars)wheat_s(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond_wt(1:31));

plot(t_wheatwt_ldld,v_wheatwt_ldld(:,31),t_wheatwt_ldld2,v_wheatwt_ldld2(:,31))
legend("Clock Gated","Not Clock Gated")
xline([0:24:480],':','HandleVisibility','off');

plot(t_wheatwt_ldld2,v_wheatwt_ldld2(:,23))
legend("Clock Gated","Not Clock Gated")
xline([0:24:480],':','HandleVisibility','off');

