function cost = cost_function(data_in,times_i,sol_i,sol_for_norm,barrier,times_cond,sol_cond,var_correspond)
% barrier = define if and which barrier functions should be used 
%  Set to [] as default. "1" = use oscillating condition, "2" = use peak
%   condition, "both" = use both conditions.
%times_i = times_init;
%sol_i = sol_init; 
%barrier = "both";
%data_times = wtdata_times;

%data_in = data;
%times_i = times_init;
%sol_i = sol_init;
%sol_for_norm = [];
%barrier = "1";
%times_cond =[];
%sol_cond = [];
%var_correspond = var_correspond_wt;

objective = []; % initialise cost for the objective function
cost_obj = []; % final cost from var data fitting

%% min-max normalise simulated data, as with experimental data
%if(isempty(sol_for_norm) == false)
    
%    min_data = min([reshape(sol_i,1,[]),reshape(sol_for_norm,1,[])]);
%    max_data = max([reshape(sol_i,1,[]),reshape(sol_for_norm,1,[])]);

%else 
    
%    min_data = min(reshape(sol_i,1,[]));
%    max_data = max(reshape(sol_i,1,[]));

%end

%sol_i = (sol_i-min_data)/(max_data-min_data);

%disp(size(sol_i))

%% Calcualte cost for each repeat
for rep = unique(data_in(:,1))' 

    cost_var = [];
    obj_v = [];

    data_rep = data_in(data_in(:,1) == rep,:);
    data_times = data_rep(:,2);

    %% get simulated data at corresponding times points to experimental data 
    sim_data = [];
    s_data_ind = [];

    %data_sampled = datasample(data_times',3,'Replace',false);
    %disp(data_sampled)

    for exp_time = data_times' %data_sampled data_times'

        [~,ix] = min(abs(times_i-exp_time)); % find closest value to experimental times in simulation times
        s_data_ind = [s_data_ind,ix];

    end 

    %s_data_ind = sort(s_data_ind,'ascend');
    sim_data = sol_i(s_data_ind,:);
    %disp(size(sim_data))
    %disp(s_data_ind)


    %% get objective function, least squares method
    for var = var_correspond(2,:) % each full biological repeat of the experiment, will be given in the 1st column of data

        corr_v_ind = var_correspond(1,var_correspond(2,:) == var);
        %disp(ismember(data_rep(:,2),data_sampled))
        %sub_data = data_rep(ismember(data_rep(:,2),data_sampled),corr_v_ind);
        sub_data = data_rep(:,corr_v_ind); % get time course data for variable var, reps and times come in cols 1 and 2 so that's why theres a +2 term
        sub_sim_data = sim_data(:,var); 

        if(isempty(sol_for_norm) == false)
            min_data = min([sol_i(:,var);sol_for_norm(:,var)]);
            max_data = max([sol_i(:,var);sol_for_norm(:,var)]);
        else 
            min_data = min(sol_i(:,var));
            max_data = max(sol_i(:,var));
        end

        sub_sim_data = (sub_sim_data-min_data)/(max_data-min_data);
        
        %obj = (1/length(sub_data))*sum(((sub_data-sub_sim_data)./sub_error).^2);
        obj = (1/length(sub_data))*sum((sub_data-sub_sim_data).^2);
        
        obj_v = [obj_v,obj];
    
    end 

    cost_var = sum(obj_v);
    objective = [objective,cost_var];

end

cost_obj = sum(objective);

    %% get barrier functions
cost_cond = 0; % initialise conditional cost, set to 0 if no barrier functions are implemented

if(isempty(barrier) == false)
        
    if(barrier == "1") % condition - clock should still be oscillating in LDLL after a long time

        % pick important component that should still be oscillating e.g.
        % LHY
           [~,end_12_from] = min(abs(times_i - (times_i(end)-12)));
           dycond_dt = (sol_i(end,1)-sol_i(end_12_from,1))/12; % get dy/dt between end time point and 12h before - gradient should not be 0 if oscillating
           dycond_dt_term = sqrt(dycond_dt^2) + 10^-70; % if it is 0, means it can still be plugged into the cost function without causing a math error 
           cost_cond1 = sqrt(((1/1000)*(-log(dycond_dt_term)))^2); % goes exponteital only when gradient is VERY close to 0 aka the clock has stopped oscillating. 
           
           cost_cond = cost_cond + cost_cond1;

    elseif(barrier == "2") % condition - LHY peaks strictly around dawn
           
            % LHY, peak roughly = 0h 
           
            [~,ix2] = min(abs(times_cond-(24+0.1))); % 24h - dawn, before longer period takes hold
            [~,ix3] = min(abs(times_cond-(24-0.1)));
            dy2cond_dt = (sol_cond(ix3) - sol_cond(ix2))/0.2; % dy/dt around 24h
            dy2cond_dt_term = dy2cond_dt^2;
            cost_cond2 = dy2cond_dt_term/5;
            
            cost_cond = cost_cond + cost_cond2;

    elseif(barrier == "both")

           [~,end_12_from] = min(abs(times_i - (times_i(end)-12)));
           dycond_dt = (sol_i(end,1)-sol_i(end_12_from,1))/12; 
           dycond_dt_term = sqrt(dycond_dt^2) + 10^-70; 
           cost_cond1 = sqrt(((1/1000)*(-log(dycond_dt_term)))^2);     

           [~,ix2] = min(abs(times_cond-(24+0.1))); % 24h - dawn, before longer period takes hold
           [~,ix3] = min(abs(times_cond-(24-0.1)));
           dy2cond_dt = (sol_cond(ix3) - sol_cond(ix2))/0.2; % dy/dt around 24h
           dy2cond_dt_term = dy2cond_dt^2;
           cost_cond2 = dy2cond_dt_term/5;
          
           cost_cond = cost_cond + cost_cond1 + cost_cond2;
  
    end

 end
    
 %% get final cost for the variable
 cost = cost_obj + cost_cond;