webb_data_wt = readtable("webb_data_wt.csv"); 
webb_mat_wt = table2array(webb_data_wt);
webb_data_mut = readtable("webb_data_mut.csv"); 
webb_mat_mut = table2array(webb_data_mut);

%% Normalising All Data

%min_small = min([reshape(webb_mat_wt(:,3:8),1,[]), ...
%    reshape(webb_mat_mut(:,3:8),1,[])]);
%max_small = max([reshape(webb_mat_wt(:,3:8),1,[]), ...
%    reshape(webb_mat_mut(:,3:8),1,[])]);

%webb_norm_wt = webb_mat_wt;
%webb_norm_mut = webb_mat_mut;

%webb_norm_wt(:,3:8) = (webb_norm_wt(:,3:8)-min_small)/( ...
%    max_small-min_small);
%webb_norm_mut(:,3:8) = (webb_norm_mut(:,3:8)-min_small)/( ...
%    max_small-min_small);

%webb_smooth_wt = smooth_data(webb_norm_wt,[3:8],[1,2,3]);
%webb_smooth_mut = smooth_data(webb_norm_mut,[3:8],[1,2,3]);

%plot(webb_smooth_wt(webb_smooth_wt(:,1) == 1,2), ...
%    webb_smooth_wt(webb_smooth_wt(:,1) == 1,3:8))
%xline([0:24:240],':','HandleVisibility','off');
%set(gcf,'color','w');
%set(gca,'TickLength',[0,0]) 

%plot(webb_smooth_mut(webb_smooth_mut(:,1) == 1,2), ...
%    webb_smooth_mut(webb_smooth_mut(:,1) == 1,[3,5:8]))
%xline([0:24:240],':','HandleVisibility','off');
%set(gcf,'color','w');
%set(gca,'TickLength',[0,0]) 

%% Reduced DF for smaller model

%w_wt_small = webb_smooth_wt;
%w_wt_small(:,5) = [];
%w_wt_small(:,3:7) = w_wt_small(:,3:7)*10;

%w_mut_small = webb_smooth_mut;
%w_mut_small(:,[4,5]) = [];
%w_mut_small(:,3:6) = w_mut_small(:,3:6)/10;

%plot(webb_mat_wt(webb_mat_wt(:,1) == 1,2), ...
%    webb_mat_wt(webb_mat_wt(:,1) == 1,[3,5:8]))
%xline([0:24:240],':','HandleVisibility','off');
%set(gcf,'color','w');
%set(gca,'TickLength',[0,0]) 

new_norm_webb_wt = smooth_data(webb_mat_wt,[3:8],[1,2,3]);
new_norm_webb_mut = smooth_data(webb_mat_mut,[3:8],[1,2,3]);


for var = 3:8
    
    min_var = min([new_norm_webb_wt(:,var);new_norm_webb_mut(:,var)]);
    max_var = max([new_norm_webb_wt(:,var);new_norm_webb_mut(:,var)]);

    normal_wt = (new_norm_webb_wt(:,var)-min_var)/(max_var-min_var);
    normal_mut = (new_norm_webb_mut(:,var)-min_var)/(max_var-min_var);

    new_norm_webb_wt(:,var) = normal_wt;
    new_norm_webb_mut(:,var) = normal_mut;

end

plot(new_norm_webb_wt(new_norm_webb_wt(:,1) == 1,2), ...
    new_norm_webb_wt (new_norm_webb_wt (:,1) == 1,[3,5:8]))
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0]) 

%% Reduced DF for smaller model

w_wt_small_nn = new_norm_webb_wt;
w_wt_small_nn(:,5) = [];
w_wt_small_nn = w_wt_small_nn(w_wt_small_nn(:,2) <= 72,:);

w_mut_small_nn = new_norm_webb_mut;
w_mut_small_nn(:,[4,5]) = [];
w_mut_small_nn = w_mut_small_nn(w_mut_small_nn(:,2) <= 72,:);


%% get index from data and simulations for a given variable
v_crspnd_wt = [3:7;1,14,12,6,8];
v_crspnd_mut = [3:6;1,12,6,8];

%% Initialising function inputs for fitting

parms(1) = 4.58;
parms(2) = 3.0; %3.0
parms(3) = 1.27;
parms(4) = 0.5;
parms(5) = 5.0;
parms(6) = 1.0;
parms(7) = 1.1;
%parms(7) = 2;
parms(8) = 1.1;
parms(9) = 1;
parms(10) = 2; % 1

parms(11) = 0.53;
parms(12) = 0.21;
parms(13) = 0.35;
parms(14) = 0.56;
parms(15) = 0.57;
parms(16) = 0.4;
parms(17) = 0.4;
parms(18) = 0.5;

parms(19) = 0.76;
parms(20) = 0.42;
parms(21) = 1.01;
parms(22) = 0.64;
parms(23) = 0.22; % 0.6
parms(24) = 0.6;
parms(25) = 0.6;
parms(26) = 0.8;
parms(27) = 0.68;
parms(28) = 0.5;
parms(29) = 0.29; % 0.29
parms(30) = 0.48; 
parms(31) = 0.38;
parms(32) = 1.2; % 1.21
parms(33) = 0.38; % 0.38
parms(34) = 0.5;
parms(35) = 0.8;
parms(36) = 0.5;
parms(37) = 0.8;
parms(38) = 0.7;
parms(39) = 0.7;
parms(40) = 0.6;

parms(41) = 2.80;
parms(42) = 0.16; %0.16
parms(43) = 1.18;
parms(44) = 0.5;
parms(45) = 0.2; % 0.24
parms(46) = 0.23; % 0.28
parms(47) = 0.63; % 0.57
parms(48) = 1.73; % 1.73
parms(49) = 0.46;
parms(50) = 0.5; 
parms(51) = 0.6;
parms(52) = 0.3;
parms(53) = 1.9;
parms(54) = 0.3;
parms(55) = 0.5;
parms(56) = 2.0;
parms(57) = 0.3;
parms(58) = 0.5;
parms(59) = 2.0;
parms(60) = 0.8; % 0.8
parms(61) = 1.9;

parms(62) = 1; % 1 2.5
parms(63) = 0.7;
parms(64) = 0.35; % 0.35 0.34
parms(65) = 0.2; % 0.2
parms(66) = 1;
parms(67) = 3; % 3 1

%parms_to_fit_s = parms;
parm_og = parms;
clear parms 

LHYm_init = 4.5;
LHYp_init = 4.5;
Pp_init = 3;
P95m_init = 0.9;
P95p_init = 0.9;
P73m_init = 1.5;
P73p_init = 1.5;
P5T1m_init = 0.6;
P5T1p_init = 0.6;
E4m_init = 0.5;
E4p_init = 0.5;
LUXm_init = 0.5;
LUXp_init = 0.5;
E3m_init = 1.3;
E3p_init = 1.3;
EC_init = 0.5;

init_conditions_wheatwt = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init];
init_conditions_wheatmut = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,EC_init];

%% parameter fitting
parm_fit_s_fromara_nn = wheat_parameter_fitting(parm_og,@wheat_wt,30,0.01,"1",w_wt_small_nn,w_mut_small_nn, ...
    @wheat_elf3mut,init_conditions_wheatwt,init_conditions_wheatmut,[30,0.75],"LDLL","LDLD", ...
    480,v_crspnd_wt,v_crspnd_mut);

plot(sum(parm_fit_s_fromara_nn{3}(:,2:end),2))
legend("Increased learning rate and delta parameter, data from 0-72h")
set(gca,'LineWidth',1.5)
xlabel("iterations")
ylabel("total cost")


parm_fit_s_partialoptim_nn = wheat_parameter_fitting(parms_to_fit_s,@wheat_wt,20,0.003,"1",w_wt_small_nn,w_mut_small_nn, ...
    @wheat_elf3mut,init_conditions_wheatwt,init_conditions_wheatmut,[30,0.75],"LDLL","LDLD", ...
    480,v_crspnd_wt,v_crspnd_mut);

parms = parm_og;
parms(60) = 50;
parm_noe3mod = parms;
clear parms
parm_fit_noe3mod_nn = wheat_parameter_fitting(parm_noe3mod,@wheat_wt,20,0.003,"1",w_wt_small_nn,w_mut_small_nn, ...
    @wheat_elf3mut,init_conditions_wheatwt,init_conditions_wheatmut,[30,0.75],"LDLL","LDLD", ...
    480,v_crspnd_wt,v_crspnd_mut);

plot(0:20,sum(parm_fit_s_partialoptim_nn{3}(:,2:end),2), ...
    0:20,sum(parm_fit_s_fromara_nn{3}(:,2:end),2), ...
    0:20,sum(parm_fit_noe3mod_nn{3}(:,2:end),2))
legend("Original Parameters","Partially Optimised Parameters","No ELF3 morning element (effectively)")
set(gca,'LineWidth',1.5)
xlabel("iterations")
ylabel("total cost")



%% Batch Gradient Descent
% Partially Optimised Wheat Parameters
parm_fit_s_partialoptim = wheat_parameter_fitting(parms_to_fit_s,@wheat_wt,30,0.01,"1",w_wt_small,w_mut_small, ...
    @wheat_elf3mut,init_conditions_wheatwt,init_conditions_wheatmut,[30,0.75],"LDLL","LDLD", ...
    480,v_crspnd_wt,v_crspnd_mut);
plot(sum(parm_fit_s_partialoptim{3}(:,2:end),2))


save parm_partoptim_tt_s.mat parm_fit_s_partialoptim
% Arabidopsis Parameters + ELF3 morning element 
parm_fit_s_fromara = wheat_parameter_fitting(parm_og,@wheat_wt,10,0.01,"1",w_wt_small,w_mut_small, ...
    @wheat_elf3mut,init_conditions_wheatwt,init_conditions_wheatmut,[30,0.75],"LDLL","LDLD", ...
    480,v_crspnd_wt,v_crspnd_mut);
plot(0:5,sum(parm_fit_s_fromara{3}(:,2:end),2))
save parm_unoptim_tt_s.mat parm_fit_s_fromara

plot(0:30,sum(parm_fit_s_partialoptim{3}(:,2:end),2), ...
    0:30,sum(parm_fit_s_fromara{3}(:,2:end),2))
legend("Partially Optimised Wheat Model","Arabidopsis Parameter Values")

s_pp_rel = parm_fit_s_partialoptim{1}./parm_og;
s_unoptim_rel = parm_fit_s_fromara{1}./parm_og;
table_firstparms = array2table([parm_fit_s_partialoptim{1}',parm_fit_s_fromara{1}',s_pp_rel',s_unoptim_rel']);
table_firstparms.Properties.VariableNames = ["parm_pp_w","parm_f_ara","rel_change_parmppw","rel_change_parmfara"];
writetable(table_firstparms,"optimised_parms_standard.csv")

%% Stochastic Gradient Descent (mini-batch, batch size = 3 per variable per repeat)
% Partially Optimised Wheat Parameters
parm_fit_s_partialoptim_sgd = wheat_parameter_fitting(parms_to_fit_s,@wheat_wt,100,0.2,"1",w_wt_small,w_mut_small, ...
    @wheat_elf3mut,init_conditions_wheatwt,init_conditions_wheatmut,[30,0.75],"LDLL","LDLD", ...
    480,v_crspnd_wt,v_crspnd_mut);
save parm_partoptim_tt_s_sgd.mat parm_fit_s_partialoptim_sgd
% Partially Optimised Wheat Parameters
parm_fit_s_fromara_sgd = wheat_parameter_fitting(parm_og,@wheat_wt,100,0.2,"1",w_wt_small,w_mut_small, ...
    @wheat_elf3mut,init_conditions_wheatwt,init_conditions_wheatmut,[30,0.75],"LDLL","LDLD", ...
    480,v_crspnd_wt,v_crspnd_mut);
save parm_unoptim_tt_s_sgd.mat parm_fit_s_fromara_sgd

plot(0:100,sum(parm_fit_s_partialoptim_sgd{3}(:,2:end),2), ...
    0:100,sum(parm_fit_s_fromara_sgd{3}(:,2:end),2), ...
    0:30,sum(parm_fit_s_partialoptim{3}(:,2:end),2), ...
    0:30,sum(parm_fit_s_fromara{3}(:,2:end),2))
legend("Partially Optimised Wheat Model SGD","Arabidopsis Parameter Values SGD", ...
    "Partially Optimised Wheat Model Batch","Arabidopsis Parameter Values Batch")
xlim([0,30])

%% Noisy Parameter Fitting (Batch Gradient Descent)
parms_fs_smallnoise = parms_to_fit_s + normrnd(0,0.15,[1,67]);

parm_fit_s_pp_smlnoise = wheat_parameter_fitting(parms_fs_smallnoise,@wheat_wt,100,0.2,"1",w_wt_small,w_mut_small, ...
    @wheat_elf3mut,init_conditions_wheatwt,init_conditions_wheatmut,[30,0.75],"LDLL","LDLD", ...
    480,v_crspnd_wt,v_crspnd_mut);
save parm_partoptim_tt_s_noise.mat parm_fit_s_pp_smlnoise

plot(0:100,sum(parm_fit_s_pp_smlnoise{3}(:,2:end),2), ...
    0:30,sum(parm_fit_s_partialoptim{3}(:,2:end),2))
legend("Noise","No Noise")
xlim([0,30])
ylim([0,50])

%% Testing Importance on Morning Element in ELF3
parm_mod_mm = parm_og;
parm_mod_mm(60) = 50;
parm_fit_s_smod = wheat_parameter_fitting(parm_mod_mm,@wheat_wt,100,0.2,"1",w_wt_small,w_mut_small, ...
    @wheat_elf3mut,init_conditions_wheatwt,init_conditions_wheatmut,[30,0.75],"LDLL","LDLD", ...
    480,v_crspnd_wt,v_crspnd_mut);
plot(0:100,sum(parm_fit_s_smod{3}(:,2:end),2))

%parms = parm_fit_s_partialoptim_nn{1};
%parms = parms_to_fit_s;

%% Simulating Optimal Parameter Sets
parms = parm_fit_s_fromara_nn{1};
LD_cyc_typ = [30,0.75]; % LD cycle ratio
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD
t_end = 480;

% Run LDLD to get initial conditions
[t_wheatwt_ldld,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_wheatwt);
init_conditions_upd = v_wheatwt_ldld(end,:);

% Model Testing 
LDLD_or_LDLL = "LDLL";
[t_wheatwt,v_wheatwt] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_upd);
plot(t_wheatwt,v_wheatwt(:,1),t_wheatwt,v_wheatwt(:,14),t_wheatwt,v_wheatwt(:,8))
legend("LHY","ELF3","TOC1")
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])
xlim([0,96])
ylabel("Raw Model values")
xlabel("t (hours)")
set(gca,'LineWidth',1.5)

LDLD_or_LDLL = "LDLD"; % LDLL or LDLD

% Run LDLD to get initial conditions
[t_wheatmut_ldld,v_wheatmut_ldld] = ode15s(@(t,vars)wheat_elf3mut(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_wheatmut);
init_conditions_wheatmut = v_wheatmut_ldld(end,:);

% Model Testing 
LDLD_or_LDLL = "LDLL";
[t_wheatmut,v_wheatmut] = ode15s(@(t,vars)wheat_elf3mut(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_wheatmut);



parms = parm_og;
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD

% Run LDLD to get initial conditions
[t_wheatwt_ldld2,v_wheatwt_ldld2] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_wheatwt);
init_conditions_upd2 = v_wheatwt_ldld2(end,:);
LDLD_or_LDLL = "LDLL";
[t_wheatwt2,v_wheatwt2] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_upd2);

[t_wheatmut_ldld2,v_wheatmut_ldld2] = ode15s(@(t,vars)wheat_elf3mut(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_wheatmut);
init_conditions_wheatmut2 = v_wheatmut_ldld2(end,:);

% Model Testing 
LDLD_or_LDLL = "LDLL";
[t_wheatmut2,v_wheatmut2] = ode15s(@(t,vars)wheat_elf3mut(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_wheatmut2);

tiledlayout(3,2)
nexttile
min_data1 = min([v_wheatwt(:,14);v_wheatmut(:,14)]);
max_data1 = max([v_wheatwt(:,14);v_wheatmut(:,14)]);
min_data2 = min([v_wheatwt2(:,14);v_wheatmut2(:,14)]);
max_data2 = max([v_wheatwt2(:,14);v_wheatmut2(:,14)]);

plot1 = plot(w_wt_small_nn(w_wt_small_nn(:,1) == 1,2),w_wt_small_nn(w_wt_small_nn(:,1) == 1,4),'black', ...
    w_wt_small_nn(w_wt_small_nn(:,1) == 2,2),w_wt_small_nn(w_wt_small_nn(:,1) == 2,4),'black', ...
    w_wt_small_nn(w_wt_small_nn(:,1) == 3,2),w_wt_small_nn(w_wt_small_nn(:,1) == 3,4),'black', ...
    t_wheatwt,(v_wheatwt(:,14)-min_data1)/(max_data1-min_data1),'-.', ...
    t_wheatwt2,(v_wheatwt2(:,14)-min_data2)/(max_data2-min_data2),'-.');
xline([0:24:240],':','HandleVisibility','off');
legend("data 1","data 2","data 3","original parameters","fitted parameters")
set(gcf,'color','w');
set(gca,'TickLength',[0,0])
xlim([0,72])
plot1(1).LineStyle = "-";
plot1(2).LineStyle = "-";
plot1(3).LineStyle = "-";
plot1(4).LineWidth = 2;
plot1(5).LineWidth = 2;
title("ELF3")

nexttile
min_data1 = min([v_wheatwt(:,1);v_wheatmut(:,1)]);
max_data1 = max([v_wheatwt(:,1);v_wheatmut(:,1)]);
min_data2 = min([v_wheatwt2(:,1);v_wheatmut2(:,1)]);
max_data2 = max([v_wheatwt2(:,1);v_wheatmut2(:,1)]);

plot1 = plot(w_wt_small_nn(w_wt_small_nn(:,1) == 1,2),w_wt_small_nn(w_wt_small_nn(:,1) == 1,3),'black', ...
    w_wt_small_nn(w_wt_small_nn(:,1) == 2,2),w_wt_small_nn(w_wt_small_nn(:,1) == 2,3),'black', ...
    w_wt_small_nn(w_wt_small_nn(:,1) == 3,2),w_wt_small_nn(w_wt_small_nn(:,1) == 3,3),'black', ...
    t_wheatwt,(v_wheatwt(:,1)-min_data1)/(max_data1-min_data1),'-.', ...
    t_wheatwt2,(v_wheatwt2(:,1)-min_data2)/(max_data2-min_data2),'-.');
xline([0:24:240],':','HandleVisibility','off');
legend("data 1","data 2","data 3","original parameters","fitted parameters")
set(gcf,'color','w');
set(gca,'TickLength',[0,0])
xlim([0,72])
plot1(1).LineStyle = "-";
plot1(2).LineStyle = "-";
plot1(3).LineStyle = "-";
plot1(4).LineWidth = 2;
plot1(5).LineWidth = 2;
title("LHY")

nexttile
min_data1 = min([v_wheatwt(:,8);v_wheatmut(:,8)]);
max_data1 = max([v_wheatwt(:,8);v_wheatmut(:,8)]);
min_data2 = min([v_wheatwt2(:,8);v_wheatmut2(:,8)]);
max_data2 = max([v_wheatwt2(:,8);v_wheatmut2(:,8)]);

plot1 = plot(w_wt_small_nn(w_wt_small_nn(:,1) == 1,2),w_wt_small_nn(w_wt_small_nn(:,1) == 1,7),'black', ...
    w_wt_small_nn(w_wt_small_nn(:,1) == 2,2),w_wt_small_nn(w_wt_small_nn(:,1) == 2,7),'black', ...
    w_wt_small_nn(w_wt_small_nn(:,1) == 3,2),w_wt_small_nn(w_wt_small_nn(:,1) == 3,7),'black', ...
    t_wheatwt,(v_wheatwt(:,8)-min_data1)/(max_data1-min_data1),'-.', ...
    t_wheatwt2,(v_wheatwt2(:,8)-min_data2)/(max_data2-min_data2),'-.');
xline([0:24:240],':','HandleVisibility','off');
legend("data 1","data 2","data 3","original parameters","fitted parameters")
set(gcf,'color','w');
set(gca,'TickLength',[0,0])
xlim([0,72])
plot1(1).LineStyle = "-";
plot1(2).LineStyle = "-";
plot1(3).LineStyle = "-";
plot1(4).LineWidth = 2;
plot1(5).LineWidth = 2;
title("PRR59/TOC1")

nexttile
min_data1 = min([v_wheatwt(:,12);v_wheatmut(:,12)]);
max_data1 = max([v_wheatwt(:,12);v_wheatmut(:,12)]);
min_data2 = min([v_wheatwt2(:,12);v_wheatmut2(:,12)]);
max_data2 = max([v_wheatwt2(:,12);v_wheatmut2(:,12)]);

plot1 = plot(w_wt_small_nn(w_wt_small_nn(:,1) == 1,2),w_wt_small_nn(w_wt_small_nn(:,1) == 1,5),'black', ...
    w_wt_small_nn(w_wt_small_nn(:,1) == 2,2),w_wt_small_nn(w_wt_small_nn(:,1) == 2,5),'black', ...
    w_wt_small_nn(w_wt_small_nn(:,1) == 3,2),w_wt_small_nn(w_wt_small_nn(:,1) == 3,5),'black', ...
    t_wheatwt,(v_wheatwt(:,12)-min_data1)/(max_data1-min_data1),'-.', ...
    t_wheatwt2,(v_wheatwt2(:,12)-min_data2)/(max_data2-min_data2),'-.');
xline([0:24:240],':','HandleVisibility','off');
legend("data 1","data 2","data 3","original parameters","fitted parameters")
set(gcf,'color','w');
set(gca,'TickLength',[0,0])
xlim([0,72])
plot1(1).LineStyle = "-";
plot1(2).LineStyle = "-";
plot1(3).LineStyle = "-";
plot1(4).LineWidth = 2;
plot1(5).LineWidth = 2;
title("LUX")

nexttile
min_data1 = min([v_wheatwt(:,6);v_wheatmut(:,6)]);
max_data1 = max([v_wheatwt(:,6);v_wheatmut(:,6)]);
min_data2 = min([v_wheatwt2(:,6);v_wheatmut2(:,6)]);
max_data2 = max([v_wheatwt2(:,6);v_wheatmut2(:,6)]);

plot1 = plot(w_wt_small_nn(w_wt_small_nn(:,1) == 1,2),w_wt_small_nn(w_wt_small_nn(:,1) == 1,6),'black', ...
    w_wt_small_nn(w_wt_small_nn(:,1) == 2,2),w_wt_small_nn(w_wt_small_nn(:,1) == 2,6),'black', ...
    w_wt_small_nn(w_wt_small_nn(:,1) == 3,2),w_wt_small_nn(w_wt_small_nn(:,1) == 3,6),'black', ...
    t_wheatwt,(v_wheatwt(:,6)-min_data1)/(max_data1-min_data1),'-.', ...
    t_wheatwt2,(v_wheatwt2(:,6)-min_data2)/(max_data2-min_data2),'-.');
xline([0:24:240],':','HandleVisibility','off');
legend("data 1","data 2","data 3","original parameters","fitted parameters")
set(gcf,'color','w');
set(gca,'TickLength',[0,0])
xlim([0,72])
plot1(1).LineStyle = "-";
plot1(2).LineStyle = "-";
plot1(3).LineStyle = "-";
plot1(4).LineWidth = 2;
plot1(5).LineWidth = 2;
title("PRR73")




init_conditions_wheatmut = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,EC_init];
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD

% Run LDLD to get initial conditions
[t_wheatmut_ldld,v_wheatmut_ldld] = ode15s(@(t,vars)wheat_elf3mut(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_wheatmut);
init_conditions_wheatmut = v_wheatmut_ldld(end,:);

% Model Testing 
LDLD_or_LDLL = "LDLL";
[t_wheatmut,v_wheatmut] = ode15s(@(t,vars)wheat_elf3mut(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_wheatmut);

plot(t_wheatmut,v_wheatmut(:,1),t_wheatmut,v_wheatmut(:,14),t_wheatmut,v_wheatmut(:,8))
legend("LHY","ELF3","TOC1")
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])


min_sol = min([reshape(v_wheatwt,1,[]),reshape(v_wheatmut,1,[])]);
max_sol = max([reshape(v_wheatwt,1,[]),reshape(v_wheatmut,1,[])]);

plot_test = plot(w_wt_small(w_wt_small(:,1) == 1,2),w_wt_small(w_wt_small(:,1) == 1,3),"black", ...
    w_wt_small(w_wt_small(:,1) == 2,2),w_wt_small(w_wt_small(:,1) == 2,3),"black", ...
    w_wt_small(w_wt_small(:,1) == 3,2),w_wt_small(w_wt_small(:,1) == 3,3),"black", ...
    t_wheatwt,((v_wheatwt(:,1)-min_sol)/(max_sol-min_sol)),"green");
plot_test(1).LineWidth = 0.7;
plot_test(2).LineWidth = 0.7;
plot_test(3).LineWidth = 0.7;
plot_test(4).LineWidth = 1.7;
plot_test(1).LineStyle = '-';
plot_test(2).LineStyle = '-';
plot_test(3).LineStyle = '-';
plot_test(4).LineStyle = '-.';
xlim([0,96])
%ylim([0,1])
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])


plot(t_wheatwt,v_wheatwt(:,1),t_wheatwt,v_wheatwt(:,4),t_wheatwt,v_wheatwt(:,8),t_wheatwt,v_wheatwt(:,14),t_wheatwt,v_wheatwt(:,16))
legend("LHY","PRR95","PRR59/TOC1","ELF3","EC")
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])

[~,peaks_wheatwtfit] = findpeaks(v_wheatwt(:,1));
period_wwtfit = mean(diff(t_wheatwt(peaks_wheatwtfit)));
% 23.45h - quite short


%% Larger Model

parms(1) = 1.022;
parms(2) = 9.866;
parms(3) = 5.353;
parms(4) = 2.278;
parms(5) = 5.917;
parms(6) = 4.365;

parms(7) = 0.409;
parms(8) = 2.021;
parms(9) = 0.03313;
parms(10) = 0.1;
parms(11) = 0.3853;
parms(12) = 0.2525;

parms(13) = 0.996;
parms(14) = 0.5889;
parms(15) = 0.3761;
parms(16) = 2.3;
parms(17) = 0.0133;
parms(18) = 0.64787;
parms(19) = 5.437;
parms(20) = 0.1225;
parms(21) = 0.01001;
parms(22) = 0.6771;
parms(23) = 1.998;
parms(24) = 0.276;
parms(25) = 4.916;
parms(26) = 0.0903;
parms(27) = 0.5383;
parms(28) = 0.04744;
parms(29) = 2.426;
parms(30) = 0.2;
parms(31) = 0.2;
parms(32) = 0.1;
parms(33) = 0.3012;
parms(34) = 0.1764;
parms(35) = 2.848;
parms(36) = 0.4176;
parms(37) = 1.57;
parms(38) = 0.1;
parms(39) = 0.02757; 
parms(40) = 0.01;
parms(41) = 5.491;
parms(42) = 0.3;
parms(43) = 5.681;
parms(44) = 13;
parms(45) = 0.1115;
parms(46) = 0.9188;
parms(47) = 0.5711;
parms(48) = 0.9391;
parms(49) = 7.975;
parms(50) = 0.216;
parms(51) = 0.3759;
parms(52) =  0.5214;
parms(53) = 0.3577;
parms(54) = 0.7944;
parms(55) = 0.7541;
parms(56) = 0.1293;

parms(57) = 0.23;
parms(58) = 20;
parms(59) = 0.1;

parms(60) = 0.6;
parms(61) = 0.3;
parms(62) = 0.2;
parms(63) = 1.78;
parms(64) = 8;
parms(65) = 0.7;
parms(66) = 0.3;
parms(67) = 3;
parms(68) = 0.4024;
parms(69) = 1.461;
parms(70) = 1.111;
parms(71) = 2.13;
parms(72) = 25.2;

parms(73) = 0.1217;
parms(74) = 0.2873;

parms(75) = 3.747;
parms(76) = 2.384;
parms(77) = 4.747; 
parms(78) = 16.3;
parms(79) = 0.1;
parms(80) = 0.4728;
parms(81) = 35.94;
parms(82) = 2.225;
parms(83) = 0.5885;
parms(84) = 21.086;
parms(85) = 2.086;
parms(86) = 6.033;
parms(87) = 1.053;
parms(88) = 12.66;
parms(89) = 6.743;
parms(90) = 0.1519;
parms(91) = 5.199;
parms(92) = 1.205;
parms(93) = 16.24;
parms(94) = 0.1465;
parms(95) = 5.127;
parms(96) = 1.971;
parms(97) = 7.1;
parms(98) = 16.33;
parms(99) = 1.027;
parms(100) = 5.466;
parms(101) = 6.864;
parms(102) = 8.392;
parms(103) = 0.1423;
parms(104) = 2.714;
parms(105) = 0.01041;
parms(106) = 4.775;
parms(107) = 0.9026;
parms(108) = 0.05704;
parms(109) = 0.02929;
parms(110) = 0.49;
parms(111) = 0.554;
parms(112) = 0.05062;
parms(113) = 1.051;

parms(114) = 1.103;
parms(115) = 0.5891;
parms(116) = 0.2317;
parms(117) = 0.1472;
parms(118) = 0.8543;

parms(119) = 2.8; %1 2.8
parms(120) = 1; %1
parms(121) = 0.1; %1 0.1

parms_to_fit_l = parms;
clear parms

t_end = 480;
clear t_end

LHYm_init = 0.6;
LHYp_init = 0.6;
CCA1m_init = 0.6;
CCA1p_init = 0.6;
Pp_init2 = 4;
P9m_init = 0.05;
P9p_init = 0.05;
P7m_init = 0.05;
P7p_init = 0.05;
P5m_init = 0.05;
P5pc_init = 0.05;
P5pn_init = 0.05;
TOC1m_init = 0.3;
TOC1pn_init = 0.3;
TOC1pc_init = 0.3;
E4m_init = 0.05;
E4p_init = 0.05;
E4D_init = 0.05;
E3m_init = 0.1;
E3p_init = 0.1;
E34_init = 0.05;
LUXm_init = 0.2;
LUXp_init = 0.2;
COP1pc_init = 0.4;
COP1pn_init = 0.4;
COP1D_init = 0.2;
ZTLp_init = 0.3;
ZGp_init = 0.2;
GIm_init = 0.3; 
GIpc_init = 0.2;
GIpn_init = 0.1;
NOXm_init = 0.2;
NOXp_init = 0.2;
RVE8m_init = 0.6;
RVE8p_init = 0.6;

init_conditions_l = [LHYm_init,LHYp_init,CCA1m_init,CCA1p_init,Pp_init2,P9m_init,P9p_init,P7m_init,P7p_init,P5m_init,P5pc_init,P5pn_init,TOC1m_init,TOC1pn_init,TOC1pc_init,E4m_init,E4p_init,E4D_init,E3m_init,E3p_init,E34_init,LUXm_init,LUXp_init,COP1pc_init,COP1pn_init,COP1D_init,ZTLp_init,ZGp_init,GIm_init,GIpc_init,GIpn_init,NOXm_init,NOXp_init,RVE8m_init,RVE8p_init];
init_conditions_l_m = [LHYm_init,LHYp_init,CCA1m_init,CCA1p_init,Pp_init2,P9m_init,P9p_init,P7m_init,P7p_init,P5m_init,P5pc_init,P5pn_init,TOC1m_init,TOC1pn_init,TOC1pc_init,E4m_init,E4p_init,E4D_init,LUXm_init,LUXp_init,COP1pc_init,COP1pn_init,COP1D_init,ZTLp_init,ZGp_init,GIm_init,GIpc_init,GIpn_init,NOXm_init,NOXp_init,RVE8m_init,RVE8p_init];

v_crspnd_wt_l = [3:8;1,19,29,22,8,13];
v_crspnd_mut_l = [3:7;1,26,19,8,13];

clear LDLD_or_LDLL
clear LD_cyc_typ

webb_smooth_mut(:,4) = [];

parm_fit_t1l = wheat_parameter_fitting(parms_to_fit_l, ...
    @wheat_wt_large,100,0.2,"both",webb_smooth_wt,webb_smooth_mut, ...
    @wheat_elf3mut_large,init_conditions_l,init_conditions_l_m,[30,0.75],"LDLL","LDLD", ...
    480,v_crspnd_wt_l,v_crspnd_mut_l);

save parm_optim_tt_l.mat parm_fit_t1l


plot(sum(parm_fit_t1l{3}(:,2:end),2))
