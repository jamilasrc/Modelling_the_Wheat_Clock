function new_parms = param_fitting_24(parms_init,iterations,init_conditions)

parms_init = parms_goin;
iterations = 100;
init_conditions = init_conditions_arawt;


parm_update = zeros(iterations+1,length(parms_init));
parm_update(1,:) = parms_init;

cost = zeros(iterations+1,length(parms_init));

parms = parms_init;

LD_cyc_typ = [0,0.5];
LDLD_or_LDLL = "LDLL";
t_end = 120;

[times_init,sol_init] = ode15s(@(t,vars)arabidopsis_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions);

[d1init,closest_time1init] = min(abs(times_init(:,1)-48));
[d2init,closest_time2init] = min(abs(times_init(:,1)-72));

cost_init = 100*(((sol_init(closest_time2init,1)-sol_init(closest_time1init,1))/24)^2);
cost(1,:) = cost_init;

cost(1) = cost_init; 

for i = 1:iterations
    parms = parm_update(i,:);
    
    for p = 1:length(parms_init)
        
   
        p_dp = parm_update(i,p) + 0.01;
        parms(p) = p_dp;
        
        [times,sol] = ode15s(@(t,vars)arabidopsis_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions);
        
        [d1,closest_time1] = min(abs(times(:,1)-48));
        [d2,closest_time2] = min(abs(times(:,1)-72));
        
        cost_ip = 100*(((sol(closest_time2,1)-sol(closest_time1,1))/24)^2);
        cost(i+1,p) = cost_ip;

        update = parm_update(i,p) - 0.05*((cost_ip-cost(i,p))/0.01);
        parm_update(i+1,p) = update;

    end

end


parms = parm_update(end,:);
[t_arawt,v_arawt] = ode15s(@(t,vars)arabidopsis_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_arawt);
plot(t_arawt,v_arawt(:,1),t_arawt,v_arawt(:,4),t_arawt,v_arawt(:,8),t_arawt,v_arawt(:,14))
legend("LHY","PRR9","TOC1","ELF3")
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])
