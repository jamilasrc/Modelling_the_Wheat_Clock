function time_until_dawn = parm_explore(model,parm_init,parms_ind,parmset1,parmset2,init_cond,t_end)


%parms_ind = [61,63];
%parmset1 = [1,1.5,0.5];
%parmset2 = [0.35,0.45,0.25];
%init_cond = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init];

%t_end = 120;

model_name = func2str(model);

time_until_dawn = [];


LD_cyc_typ = [30,0.75];

for p1 = parmset1

    %p1 = parmset1(1);



    for p2 = parmset2

        %p2 = parmset2(1);
        %p1 = 3;
        %p2 = 0.5;

        clear parms
        parms = parm_init;
        parms(parms_ind(1)) = p1;
        parms(parms_ind(2)) = p2;

        LDLD_or_LDLL = "LDLD";
        [~,v_m_ldld] = ode15s(@(t,vars)model(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond);
        init_cond_upd = v_m_ldld(end,:);

        LDLD_or_LDLL = "LDLL";
        [t_m_out,v_m_out] = ode15s(@(t,vars)model(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond_upd);

        data_needed_t = t_m_out(t_m_out <= 24);

        if(model_name == "wheat_wt")
            data_needed_v = v_m_out(:,14);
        elseif(model_name == "wheat_wt_large")
            data_needed_v = v_m_out(:,19);
        end

        data_needed_v = data_needed_v(t_m_out <= 24);

        [~,peaks_pos] = findpeaks(data_needed_v);
        peak_times = data_needed_t(peaks_pos)';

        [~,osc_check_t] = min(abs(t_m_out-(t_end-12)));
        still_oscillating = (v_m_out(end,1) - v_m_out(osc_check_t,1))/12;


        if(length(peak_times) == 1 && still_oscillating ~= 0)

            t_f_dawn = 24 - peak_times;


            LDLD_or_LDLL = "LDLD";
            [~,v_m_ld_rt] = ode15s(@(t,vars)model(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,120],init_cond);
            init_cond_upd2 = v_m_ld_rt(end,:);

            LDLD_or_LDLL = "LDLL";
            [t_m_rt,v_m_rt] = ode15s(@(t,vars)model(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,120],init_cond_upd2);

            data_needed_t2 = t_m_rt(t_m_rt <= 24);

            LDLD_or_LDLL = "LDLD";
            [~,v_m_ld_rt2] = ode15s(@(t,vars)model(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,240],init_cond);
            init_cond_upd3 = v_m_ld_rt2(end,:);

            LDLD_or_LDLL = "LDLL";
            [t_m_rt2,v_m_rt2] = ode15s(@(t,vars)model(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,120],init_cond_upd3);

            data_needed_t3 = t_m_rt2(t_m_rt2 <= 24);


            if(model_name == "wheat_wt")
                data_needed_v2 = v_m_rt(:,14);
                data_needed_v3 = v_m_rt2(:,14);
            elseif(model_name == "wheat_wt_large")
                data_needed_v2 = v_m_rt(:,19);
                data_needed_v3 = v_m_rt2(:,19);
            end

            data_needed_v2 = data_needed_v2(t_m_rt <= 24);
            data_needed_v3 = data_needed_v3(t_m_rt2 <= 24);

            [~,peaks_pos2] = findpeaks(data_needed_v2);
            peak_times2 = data_needed_t2(peaks_pos2)';
            t_f_dawnr = 24 - peak_times2;
            [~,peaks_pos3] = findpeaks(data_needed_v3);
            peak_times3 = data_needed_t3(peaks_pos3)';
            t_f_dawnr2 = 24 - peak_times3;
            range_test = range([t_f_dawn,t_f_dawnr,t_f_dawnr2]);
            time_until_dawn = [time_until_dawn;[p1,p2,t_f_dawn,range_test]];

        else

            time_until_dawn = [time_until_dawn;[p1,p2,NaN,NaN]];

        end

    end

end








