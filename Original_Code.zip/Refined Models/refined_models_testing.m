cd c:\Users\Jamila\Documents\'University Work'\'4th Year'\Project\'Refined Models'
currentFolder = pwd;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Arabidopsis %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% WT

t_end = 480; % total time the model runs for 

% parameters
clear parms

parms(1) = 4.58;
parms(2) = 3.0; %3.0
parms(3) = 1.27;
parms(4) = 0.5;
parms(5) = 5.0;
parms(6) = 1.0;
parms(7) = 1.1;
%parms(7) = 2;
parms(8) = 1.1;
parms(9) = 1;
parms(10) = 2; % 1

parms(11) = 0.53;
parms(12) = 0.21;
parms(13) = 0.35;
parms(14) = 0.56;
parms(15) = 0.57;
parms(16) = 0.4;
parms(17) = 0.4;
parms(18) = 0.5;

parms(19) = 0.76;
parms(20) = 0.42;
parms(21) = 1.01;
parms(22) = 0.64;
parms(23) = 0.22; % 0.6
parms(24) = 0.6;
parms(25) = 0.6;
parms(26) = 0.8;
parms(27) = 0.68;
parms(28) = 0.5;
parms(29) = 0.29; % 0.29
parms(30) = 0.48; 
parms(31) = 0.38;
parms(32) = 1.2; % 1.21
parms(33) = 0.38; % 0.38
parms(34) = 0.5;
parms(35) = 0.8;
parms(36) = 0.5;
parms(37) = 0.8;
parms(38) = 0.7;
parms(39) = 0.7;
parms(40) = 0.6;

parms(41) = 2.80;
parms(42) = 0.16; %0.16
parms(43) = 1.18;
parms(44) = 0.5;
parms(45) = 0.2; % 0.24
parms(46) = 0.23; % 0.28
parms(47) = 0.63; % 0.57
parms(48) = 1.73; % 1.73
parms(49) = 0.46;
parms(50) = 0.5; 
parms(51) = 0.6;
parms(52) = 0.3;
parms(53) = 1.9;
parms(54) = 0.3;
parms(55) = 0.5;
parms(56) = 2.0;
parms(57) = 0.3;
parms(58) = 0.5;
parms(59) = 2.0;
parms(60) = 0.8;
%parms(60) = 1.9;

parms(61) = 1;
parms(62) = 0.7;
parms(63) = 0.35; % 0.35
parms(64) = 0.2; % 0.2
parms(65) = 1;
parms(66) = 3;

% init. conditions
LHYm_init = 1;
LHYp_init = 1;
Pp_init = 1;
P95m_init = 0.1;
P95p_init = 0.4;
P73m_init = 0.3;
P73p_init = 0.3;
P5T1m_init = 0.1;
P5T1p_init = 0.1;
E4m_init = 0.1;
E4p_init = 0.1;
LUXm_init = 0.1;
LUXp_init = 0.1;
E3m_init = 0.3;
E3p_init = 0.3;
EC_init = 0.3;


% WT Testing
%init_conditions_arawt = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init,ZGm_init,ZGp_init];
init_conditions_arawt = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init];

LD_cyc_typ = [0,0.5]; % LD cycle ratio
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD

% Run LDLD to get initial conditions
[t_arawt_ldld,v_arawt_ldld] = ode15s(@(t,vars)arabidopsis_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_arawt);
init_conditions_arawt = v_arawt_ldld(end,:);

% Model Testing 
LDLD_or_LDLL = "LDLL";
[t_arawt,v_arawt] = ode15s(@(t,vars)arabidopsis_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_arawt);
plot(t_arawt,v_arawt(:,1),t_arawt,v_arawt(:,4),t_arawt,v_arawt(:,8),t_arawt,v_arawt(:,14))
legend("LHY","PRR9","TOC1","ELF3")
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0]) 


% Mutant Testing
init_conditions_aramut2 = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init];
LD_cyc_typ = [0,0.5]; % LD cycle ratio
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD

% Run LDLD to get initial conditions
[t_aramut2_ldld,v_aramut2_ldld] = ode15s(@(t,vars)arabidopsis_toc1_mut(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_aramut2);
init_conditions_aramut2 = v_aramut2_ldld(end,:);

% Model Testing 
LDLD_or_LDLL = "LDLL";
[t_aramut2,v_aramut2] = ode15s(@(t,vars)arabidopsis_toc1_mut(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_aramut2);
plot(t_aramut2,v_aramut2(:,1),t_aramut2,v_aramut2(:,4),t_aramut2,v_aramut2(:,8),t_aramut2,v_aramut2(:,14))

plot(t_aramut2,v_aramut2(:,1),t_arawt,v_arawt(:,1))
legend("toc1 mutant","WT")


init_conditions_aramut = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init];
LD_cyc_typ = [0,0.5]; % LD cycle ratio
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD

% Run LDLD to get initial conditions
[t_aramut_ldld,v_aramut_ldld] = ode15s(@(t,vars)arabidopsis_ec_mut(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_aramut);
init_conditions_aramut = v_aramut_ldld(end,:);

% Model Testing 
LDLD_or_LDLL = "LDLL";
[t_aramut,v_aramut] = ode15s(@(t,vars)arabidopsis_ec_mut(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_aramut);
plot(t_aramut,v_aramut(:,1),t_aramut,v_aramut(:,4),t_aramut,v_aramut(:,8),t_aramut,v_aramut(:,14))


%% Arabidopsis Plotting
% Plot for WT vs ec mutant
tiledlayout(1,3)

nexttile
minlhy = min([v_arawt(:,1);v_aramut(:,1)]);
maxlhy = max([v_arawt(:,1);v_aramut(:,1)]);
plot1 = plot(t_arawt,(v_arawt(:,1)-minlhy)/(maxlhy-minlhy),"black",t_aramut, ...
    (v_aramut(:,1)-minlhy)/(maxlhy-minlhy),"black");
xlim([72,144])
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])
set(gca,'XTick',[])
plot1(1).LineStyle = "-";
plot1(2).LineStyle = "--";
plot1(1).LineWidth = 1.75;
plot1(2).LineWidth = 1.75;
set(gca,'fontname','times')
set(gca,"FontSize",15)
title("LHY mRNA")
ylabel("Relative Expression")
ylab.FontSize = 25;

nexttile
minp9 = min([v_arawt(:,4);v_aramut(:,4)]);
maxp9 = max([v_arawt(:,4);v_aramut(:,4)]);
plot2 = plot(t_arawt,(v_arawt(:,4)-minp9)/(maxp9-minp9),"black",t_aramut, ...
    (v_aramut(:,4)-minp9)/(maxp9-minp9),"black");
xlim([72,144])
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])
set(gca,'XTick',[])
plot2(1).LineStyle = "-";
plot2(2).LineStyle = "--";
plot2(1).LineWidth = 1.75;
plot2(2).LineWidth = 1.75;
set(gca,'fontname','times')
set(gca,"FontSize",15)
title("PRR9 mRNA")

nexttile
mint1 = min([v_arawt(:,8);v_aramut(:,8)]);
maxt1 = max([v_arawt(:,8);v_aramut(:,8)]);
plot3 = plot(t_arawt,(v_arawt(:,8)-mint1)/(maxt1-mint1),"black",t_aramut, ...
    (v_aramut(:,8)-mint1)/(maxt1-mint1),"black");
xlim([72,144])
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])
set(gca,'XTick',[])
plot3(1).LineStyle = "-";
plot3(2).LineStyle = "--";
plot3(1).LineWidth = 1.75;
plot3(2).LineWidth = 1.75;
set(gca,'fontname','times')
set(gca,"FontSize",15)
title("PRR5/TOC1 mRNA")

% Plot of WT clock activity
rectangle('Position',[18 -0.01 6 1.02],'FaceColor',"black")
rectangle('Position',[36 -0.01 6 1.02],'FaceColor',"black")
rectangle('Position',[24 -0.01 12 1.02],'FaceColor',[0.3010 0.7450 0.9330],'EdgeColor',[0.3010 0.7450 0.9330])
axis([18 42 -0.01 1.01])
hold on 
minlhy2 = min(v_arawt(:,1));
maxlhy2 = max(v_arawt(:,1));
mint12 = min(v_arawt(:,8));
maxt12 = max(v_arawt(:,8));
mine32 = min(v_arawt(:,14));
maxe32 = max(v_arawt(:,14));
minec2 = min(v_arawt(:,16));
maxec2 = max(v_arawt(:,16));
plot_wt_act = plot(t_arawt,(v_arawt(:,1)-minlhy2)/(maxlhy2-minlhy2), ...
    t_arawt,(v_arawt(:,8)-mint12)/(maxt12-mint12), ...
    t_arawt,(v_arawt(:,14)-mine32)/(maxe32-mine32), ...
    t_arawt,(v_arawt(:,16)-minec2)/(maxec2-minec2));
plot_wt_act(1).Color = '#EDB120';
plot_wt_act(2).Color = '#77AC30';
plot_wt_act(3).Color = '#A2142F';
plot_wt_act(4).Color = 	'#7E2F8E';
plot_wt_act(1).LineWidth = 5;
plot_wt_act(2).LineWidth = 5;
plot_wt_act(3).LineWidth = 5;
plot_wt_act(4).LineWidth = 5;
plot_wt_act(1).LineStyle = "-.";
plot_wt_act(2).LineStyle = "-.";
plot_wt_act(3).LineStyle = "-.";
plot_wt_act(4).LineStyle = "-.";
set(gca,'fontname','times')
set(gca,"FontSize",20)
legend("LHY mRNA","PRR5/TOC1 mRNA","ELF3 mRNA","EC")
set(gca,'TickLength',[0,0])
set(gca,'XTick',[])
ylabel("Relative Expression")

% Plot for Infographic
rectangle("Position",[16,0,8,5],"FaceColor",[0.1,0.1,0.1], ...
    "EdgeColor",[0.1,0.1,0.1])
hold on 
plot1 = plot(t_arawt,v_arawt(:,1),"-.", ...
    t_arawt,v_arawt(:,14),"-.",  ...
    t_arawt,v_arawt(:,16),"-.",  ...
    t_arawt,v_arawt(:,8),"-.", ...
    t_arawt,v_arawt(:,4),"-.");
plot1(1).LineWidth = 2;
plot1(2).LineWidth = 2;
plot1(3).LineWidth = 2;
plot1(4).LineWidth = 2;
plot1(5).LineWidth = 2;
xlim([0,24])
set(gca,"LineWidth",2)
set(gca,'xtick',[],'ytick',[])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Wheat Model %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% WT test
t_end = 480; % total time the model runs for 

clear parms

% parameters
parms(1) = 4.58;
parms(2) = 3.0; %3.0
parms(3) = 1.27;
parms(4) = 0.5;
parms(5) = 5.0;
parms(6) = 1.0;
parms(7) = 1.1;
%parms(7) = 2;
parms(8) = 1.1;
parms(9) = 1;
parms(10) = 2; % 1

parms(11) = 0.53;
parms(12) = 0.21;
parms(13) = 0.35;
parms(14) = 0.56;
parms(15) = 0.57;
parms(16) = 0.4;
parms(17) = 0.4;
parms(18) = 0.5;

parms(19) = 0.76;
parms(20) = 0.42;
parms(21) = 1.01;
parms(22) = 0.64;
parms(23) = 0.22; % 0.6
parms(24) = 0.6;
parms(25) = 0.6;
parms(26) = 0.8;
parms(27) = 0.68;
parms(28) = 0.5;
parms(29) = 0.29; % 0.29
parms(30) = 0.48; 
parms(31) = 0.38;
parms(32) = 1.2; % 1.21
parms(33) = 0.38; % 0.38
parms(34) = 0.5;
parms(35) = 0.8;
parms(36) = 0.5;
parms(37) = 0.8;
parms(38) = 0.7;
parms(39) = 0.7;
parms(40) = 0.6;

parms(41) = 2.80;
parms(42) = 0.16; %0.16
parms(43) = 1.18;
parms(44) = 0.5;
parms(45) = 0.2; % 0.24
parms(46) = 0.23; % 0.28
parms(47) = 0.63; % 0.57
parms(48) = 1.73; % 1.73
parms(49) = 0.46;
parms(50) = 0.5; 
parms(51) = 0.6;
parms(52) = 0.3;
parms(53) = 1.9;
parms(54) = 0.3;
parms(55) = 0.5;
parms(56) = 2.0;
parms(57) = 0.3;
parms(58) = 0.5;
parms(59) = 2.0;
parms(60) = 0.8;
parms(61) = 1.9;

parms(62) = 1; % 1
parms(63) = 0.7;
parms(64) = 0.35; % 0.35
parms(65) = 0.2; % 0.2
parms(66) = 1;
parms(67) = 3; % 3

parms_to_model = parms;
%parms = parms_to_model;
%parms(62) = 3;
%parms(64) = 0.5;

% init. conditions
LHYm_init = 1;
LHYp_init = 1;
Pp_init = 1;
P95m_init = 0.1;
P95p_init = 0.4;
P73m_init = 0.3;
P73p_init = 0.3;
P5T1m_init = 0.1;
P5T1p_init = 0.1;
E4m_init = 0.1;
E4p_init = 0.1;
LUXm_init = 0.1;
LUXp_init = 0.1;
E3m_init = 0.3;
E3p_init = 0.3;
EC_init = 0.3;


init_conditions_wheatwt = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init];
LD_cyc_typ = [0,0.5]; % LD cycle ratio
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD

% Run LDLD to get initial conditions
[t_wheatwt_ldld,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_wheatwt);
init_conditions_upd = v_wheatwt_ldld(end,:);
plot(t_wheatwt_ldld,v_wheatwt_ldld(:,1),t_wheatwt_ldld,v_wheatwt_ldld(:,4), ...
    t_wheatwt_ldld,v_wheatwt_ldld(:,8),t_wheatwt_ldld,v_wheatwt_ldld(:,14), ...
    t_wheatwt_ldld,v_wheatwt_ldld(:,16))
legend("LHY","PRR95","PRR59/TOC1","ELF3","EC")
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])

% Model Testing 
LDLD_or_LDLL = "LDLL";
[t_wheatwt,v_wheatwt] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_upd);

plot(t_wheatwt,v_wheatwt(:,1),t_wheatwt,v_wheatwt(:,4),t_wheatwt,v_wheatwt(:,8),t_wheatwt,v_wheatwt(:,14),t_wheatwt,v_wheatwt(:,16))
legend("LHY","PRR95","PRR59/TOC1","ELF3","EC")
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])

[~,peaks_arabidopsis] = findpeaks(v_arawt(:,1));
period_ara = mean(diff(t_arawt(peaks_arabidopsis)));
[~,peaks_wheat] = findpeaks(v_wheatwt(:,1));
period_wheat = mean(diff(t_wheatwt(peaks_wheat)));
[~,peaks_wheatmod] = findpeaks(v_wheatwt(:,1));
period_wheatmod = mean(diff(t_wheatwt(peaks_wheatmod)));

plot(t_arawt,v_arawt(:,14),t_wheatwt,v_wheatwt(:,14))
legend("A","W")
[~,p_a] = findpeaks(v_arawt(:,14),t_arawt);
[~,p_w] = findpeaks(v_wheatwt(:,14),t_wheatwt);
disp([p_a,p_w])
p_w(2) - p_a(2) % 1.25h

%% Mutant testing
init_conditions_wheatmut = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,EC_init];
LD_cyc_typ = [0,0.5]; % LD cycle ratio
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD

% Run LDLD to get initial conditions
[t_wheatmut_ldld,v_wheatmut_ldld] = ode15s(@(t,vars)wheat_elf3mut(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_wheatmut);
init_conditions_wheatmut = v_wheatmut_ldld(end,:);

% Model Testing 
LDLD_or_LDLL = "LDLL";
[t_wheatmut,v_wheatmut] = ode15s(@(t,vars)wheat_elf3mut(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_wheatmut);
plot(t_wheatmut,v_wheatmut(:,1),t_wheatmut,v_wheatmut(:,4),t_wheatmut,v_wheatmut(:,8))
legend("LHY","PRR95","PRR59/TOC1")
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])

%%
tiledlayout(2,3)
 
nexttile
minlhy = min([v_wheatwt(:,1);v_wheatmut(:,1)]);
maxlhy = max([v_wheatwt(:,1);v_wheatmut(:,1)]);
plot1 = plot(t_wheatwt,(v_wheatwt(:,1)-minlhy)/(maxlhy-minlhy),"black", ...
    t_wheatmut,(v_wheatmut(:,1)-minlhy)/(maxlhy-minlhy),"black");
xlim([0,144])
ylim([-0.02,1.02])
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])
plot1(1).LineStyle = "-";
plot1(2).LineStyle = "-.";
plot1(1).LineWidth = 2;
plot1(2).LineWidth = 2;
set(gca,'fontname','times')
set(gca,"FontSize",10)
title("LHY mRNA")
ylab.FontSize = 25;
legend("WT","elf3 mutant")

nexttile
minlhy = min([v_wheatwt(:,4);v_wheatmut(:,4)]);
maxlhy = max([v_wheatwt(:,4);v_wheatmut(:,4)]);
plot2 = plot(t_wheatwt,(v_wheatwt(:,4)-minlhy)/(maxlhy-minlhy),"black", ...
    t_wheatmut,(v_wheatmut(:,4)-minlhy)/(maxlhy-minlhy),"black");
xlim([0,144])
ylim([-0.02,1.02])
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])
plot2(1).LineStyle = "-";
plot2(2).LineStyle = "-.";
plot2(1).LineWidth = 2;
plot2(2).LineWidth = 2;
set(gca,'fontname','times')
set(gca,"FontSize",10)
title("PRR95 mRNA")
ylab.FontSize = 25;
legend("WT","elf3 mutant")

nexttile
minlhy = min([v_wheatwt(:,8);v_wheatmut(:,8)]);
maxlhy = max([v_wheatwt(:,8);v_wheatmut(:,8)]);
plot3 = plot(t_wheatwt,(v_wheatwt(:,8)-minlhy)/(maxlhy-minlhy),"black", ...
    t_wheatmut,(v_wheatmut(:,8)-minlhy)/(maxlhy-minlhy),"black");
xlim([0,144])
ylim([-0.02,1.02])
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])
plot3(1).LineStyle = "-";
plot3(2).LineStyle = "-.";
plot3(1).LineWidth = 2;
plot3(2).LineWidth = 2;
set(gca,'fontname','times')
set(gca,"FontSize",10)
title("PRR59/TOC1 mRNA")
ylab.FontSize = 25;
legend("WT","elf3 mutant")

nexttile
minp9 = min([v_wheatwt(:,14);v_wheatmut(:,14)]);
maxp9 = max([v_wheatwt(:,14);v_wheatmut(:,14)]);
plot4 = plot(t_wheatwt,(v_wheatwt(:,14)-minp9)/(maxp9-minp9),"black", ...
    t_wheatmut,(v_wheatmut(:,14)-minp9)/(maxp9-minp9),"black");
xlim([0,144])
ylim([-0.02,1.02])
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])
plot4(1).LineStyle = "-";
plot4(2).LineStyle = "-.";
plot4(1).LineWidth = 2;
plot4(2).LineWidth = 2;
set(gca,'fontname','times')
set(gca,"FontSize",10)
title("ELF3 mRNA")
legend("WT","elf3 mutant")

nexttile
minp9 = min([v_wheatwt(:,10);v_wheatmut(:,10)]);
maxp9 = max([v_wheatwt(:,10);v_wheatmut(:,10)]);
plot4 = plot(t_wheatwt,(v_wheatwt(:,10)-minp9)/(maxp9-minp9),"black", ...
    t_wheatmut,(v_wheatmut(:,10)-minp9)/(maxp9-minp9),"black");
xlim([0,144])
ylim([-0.02,1.02])
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])
plot4(1).LineStyle = "-";
plot4(2).LineStyle = "-.";
plot4(1).LineWidth = 2;
plot4(2).LineWidth = 2;
set(gca,'fontname','times')
set(gca,"FontSize",10)
title("ELF4 mRNA")
legend("WT","elf3 mutant")

nexttile
mint1 = min(v_wheatwt(:,16));
maxt1 = max(v_wheatwt(:,16));
plot5 = plot(t_wheatwt,(v_wheatwt(:,16)-mint1)/(maxt1-mint1),"black");
xlim([0,144])
ylim([-0.02,1.02])
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])
plot5.LineStyle = "-";
plot5.LineWidth = 2;
set(gca,'fontname','times')
set(gca,"FontSize",10)
title("EC")
legend("WT")

lc_testing = 0.1:0.1:3;
elf_testing = 0.25:0.01:0.5;
init_conditions_input = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init];

different_peaks = parm_explore(@wheat_wt,parms_to_model,[62,64],lc_testing, ...
    elf_testing,init_conditions_input,480);

different_peaks(:,1) = different_peaks(:,1) - 1.0;
different_peaks(:,2) = different_peaks(:,2) - 0.35;

different_peaks_final = different_peaks;

for ri = 1:length(different_peaks(:,4))
    r = different_peaks(ri,4);
    if r < 0.5
        different_peaks(ri,4) = 0;
    else 
        different_peaks_final(ri,1:2) = NaN;
    end

end


different_peaks = array2table(different_peaks);
different_peaks.Properties.VariableNames{1} = 'LHY Activity';
different_peaks.Properties.VariableNames{2} = 'ELF3 Activity';
different_peaks.Properties.VariableNames{3} = 'Hours Until Dawn';
different_peaks.Properties.VariableNames{4} = 'Peak Time Range';

different_peaks_final = array2table(different_peaks_final);
different_peaks_final.Properties.VariableNames{1} = 'LHY Activity';
different_peaks_final.Properties.VariableNames{2} = 'ELF3 Activity';
different_peaks_final.Properties.VariableNames{3} = 'Hours Until Dawn';
different_peaks_final.Properties.VariableNames{4} = 'Peak Time Range';


tiledlayout(2,2)
nexttile
heatmap(different_peaks,'LHY Activity','ELF3 Activity','ColorVariable','Hours Until Dawn', ...
    'ColorLimits',[0 5],'Colormap',autumn)
set(gca,'fontname','times')
set(gca,"FontSize",12)
nexttile
heatmap(different_peaks,'LHY Activity','ELF3 Activity','ColorVariable','Peak Time Range', ...
    'ColorLimits',[0 5],'Colormap',parula)
set(gca,'fontname','times')
set(gca,"FontSize",12)
nexttile
heatmap(different_peaks_final,'LHY Activity','ELF3 Activity','ColorVariable','Hours Until Dawn', ...
    'ColorLimits',[0 5],'Colormap',hot)
set(gca,'fontname','times')
set(gca,"FontSize",12)
nexttile
diff_p_fin_matx = table2array(different_peaks_final);
plot(diff_p_fin_matx(diff_p_fin_matx(:,1) == 1,2), ...
    diff_p_fin_matx(diff_p_fin_matx(:,1) == 1,3),'-o', ...
    diff_p_fin_matx(diff_p_fin_matx(:,1) == 0.7,2), ...
    diff_p_fin_matx(diff_p_fin_matx(:,1) == 0.7,3),'-o', ...
    diff_p_fin_matx(339:364,2), ...
    diff_p_fin_matx(339:364,3),'-o', ...
    diff_p_fin_matx(diff_p_fin_matx(:,1) == 0,2), ...
    diff_p_fin_matx(diff_p_fin_matx(:,1) == 0,3),'-o')
lgd = legend("LHY Activity = +1 from \itArabidopsis\rm","+0.7","+0.4","+0");
lgd.Location = 'northwest';
ylim([0,6])
xlabel("ELF3 Involement in the EC compared to \itArabidopsis\rm")
ylabel("ELF3 Peak, Hours Until Dawn")
set(gca,'fontname','times')
set(gca,"FontSize",12)

heatmap(different_peaks_final,'LHY Activity','ELF3 Activity','ColorVariable','Hours Until Dawn', ...
    'ColorLimits',[0 5],'Colormap',hot)
set(gca,'fontname','times')
set(gca,"FontSize",12)


%%
clear parms

parms(1) = 1.022;
parms(2) = 9.866;
parms(3) = 5.353;
parms(4) = 2.278;
parms(5) = 5.917;
parms(6) = 4.365;

parms(7) = 0.409;
parms(8) = 2.021;
parms(9) = 0.03313;
parms(10) = 0.1;
parms(11) = 0.3853;
parms(12) = 0.2525;

parms(13) = 0.996;
parms(14) = 0.5889;
parms(15) = 0.3761;
parms(16) = 2.3;
parms(17) = 0.0133;
parms(18) = 0.64787;
parms(19) = 5.437;
parms(20) = 0.1225;
parms(21) = 0.01001;
parms(22) = 0.6771;
parms(23) = 1.998;
parms(24) = 0.276;
parms(25) = 4.916;
parms(26) = 0.0903;
parms(27) = 0.5383;
parms(28) = 0.04744;
parms(29) = 2.426;
parms(30) = 0.2;
parms(31) = 0.2;
parms(32) = 0.1;
parms(33) = 0.3012;
parms(34) = 0.1764;
parms(35) = 2.848;
parms(36) = 0.4176;
parms(37) = 1.57;
parms(38) = 0.1;
parms(39) = 0.02757; 
parms(40) = 0.01;
parms(41) = 5.491;
parms(42) = 0.3;
parms(43) = 5.681;
parms(44) = 13;
parms(45) = 0.1115;
parms(46) = 0.9188;
parms(47) = 0.5711;
parms(48) = 0.9391;
parms(49) = 7.975;
parms(50) = 0.216;
parms(51) = 0.3759;
parms(52) =  0.5214;
parms(53) = 0.3577;
parms(54) = 0.7944;
parms(55) = 0.7541;
parms(56) = 0.1293;

parms(57) = 0.23;
parms(58) = 20;
parms(59) = 0.1;

parms(60) = 0.6;
parms(61) = 0.3;
parms(62) = 0.2;
parms(63) = 1.78;
parms(64) = 8;
parms(65) = 0.7;
parms(66) = 0.3;
parms(67) = 3;
parms(68) = 0.4024;
parms(69) = 1.461;
parms(70) = 1.111;
parms(71) = 2.13;
parms(72) = 25.2;

parms(73) = 0.1217;
parms(74) = 0.2873;

parms(75) = 3.747;
parms(76) = 2.384;
parms(77) = 4.747; 
parms(78) = 16.3;
parms(79) = 0.1;
parms(80) = 0.4728;
parms(81) = 35.94;
parms(82) = 2.225;
parms(83) = 0.5885;
parms(84) = 21.086;
parms(85) = 2.086;
parms(86) = 6.033;
parms(87) = 1.053;
parms(88) = 12.66;
parms(89) = 6.743;
parms(90) = 0.1519;
parms(91) = 5.199;
parms(92) = 1.205;
parms(93) = 16.24;
parms(94) = 0.1465;
parms(95) = 5.127;
parms(96) = 1.971;
parms(97) = 7.1;
parms(98) = 16.33;
parms(99) = 1.027;
parms(100) = 5.466;
parms(101) = 6.864;
parms(102) = 8.392;
parms(103) = 0.1423;
parms(104) = 2.714;
parms(105) = 0.01041;
parms(106) = 4.775;
parms(107) = 0.9026;
parms(108) = 0.05704;
parms(109) = 0.02929;
parms(110) = 0.49;
parms(111) = 0.554;
parms(112) = 0.05062;
parms(113) = 1.051;

parms(114) = 1.103;
parms(115) = 0.5891;
parms(116) = 0.2317;
parms(117) = 0.1472;
parms(118) = 0.8543;

parms(119) = 1; %1
parms(120) = 1; %1
parms(121) = 1; %1

t_end = 480; 

LHYm_init = 0.6;
LHYp_init = 0.6;
CCA1m_init = 0.6;
CCA1p_init = 0.6;
Pp_init2 = 4;
P9m_init = 0.05;
P9p_init = 0.05;
P7m_init = 0.05;
P7p_init = 0.05;
P5m_init = 0.05;
P5pc_init = 0.05;
P5pn_init = 0.05;
TOC1m_init = 0.3;
TOC1pn_init = 0.3;
TOC1pc_init = 0.3;
E4m_init = 0.05;
E4p_init = 0.05;
E4D_init = 0.05;
E3m_init = 0.1;
E3p_init = 0.1;
E34_init = 0.05;
LUXm_init = 0.2;
LUXp_init = 0.2;
COP1pc_init = 0.4;
COP1pn_init = 0.4;
COP1D_init = 0.2;
ZTLp_init = 0.3;
ZGp_init = 0.2;
GIm_init = 0.3; 
GIpc_init = 0.2;
GIpn_init = 0.1;
NOXm_init = 0.2;
NOXp_init = 0.2;
RVE8m_init = 0.6;
RVE8p_init = 0.6;

init_conditions_fm = [LHYm_init,LHYp_init,CCA1m_init,CCA1p_init,Pp_init2,P9m_init,P9p_init,P7m_init,P7p_init,P5m_init,P5pc_init,P5pn_init,TOC1m_init,TOC1pn_init,TOC1pc_init,E4m_init,E4p_init,E4D_init,E3m_init,E3p_init,E34_init,LUXm_init,LUXp_init,COP1pc_init,COP1pn_init,COP1D_init,ZTLp_init,ZGp_init,GIm_init,GIpc_init,GIpn_init,NOXm_init,NOXp_init,RVE8m_init,RVE8p_init];

LD_cyc_typ = [0,0.5]; % LD cycle ratio
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD
[times_fm,vars_solved_fm] = ode15s(@(t,vars)wheat_wt_large(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_fm);
%plot(times_fm,vars_solved_fm(:,13),times_fm,vars_solved_fm(:,1),times_fm,vars_solved_fm(:,19))

LDLD_or_LDLL = "LDLL";
init_conditions_fm = vars_solved_fm(end,:);
[times_fm2,vars_solved_fm2] = ode15s(@(t,vars)wheat_wt_large(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_fm);
plot(times_fm2,vars_solved_fm2(:,13),times_fm2,vars_solved_fm2(:,1),times_fm2,vars_solved_fm2(:,19))
legend("TOC1","LHY","ELF3")
xlim([0,120])
%plot(times_w,vars_solved_w(:,6))
xline([0:24:120],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])

% quickly remove ME and compare
init_conditions_fm2 = [LHYm_init,LHYp_init,CCA1m_init,CCA1p_init,Pp_init2,P9m_init,P9p_init,P7m_init,P7p_init,P5m_init,P5pc_init,P5pn_init,TOC1m_init,TOC1pn_init,TOC1pc_init,E4m_init,E4p_init,E4D_init,E3m_init,E3p_init,E34_init,LUXm_init,LUXp_init,COP1pc_init,COP1pn_init,COP1D_init,ZTLp_init,ZGp_init,GIm_init,GIpc_init,GIpn_init,NOXm_init,NOXp_init,RVE8m_init,RVE8p_init];
LD_cyc_typ = [0,0.5]; % LD cycle ratio
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD
[t_fm,v_fm] = ode15s(@(t,vars)wheat_wt_large(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_fm2);
%plot(times_fm,vars_solved_fm(:,13),times_fm,vars_solved_fm(:,1),times_fm,vars_solved_fm(:,19))

LDLD_or_LDLL = "LDLL";
init_conditions_fm2 = v_fm(end,:);
[t_fm2,v_fm2] = ode15s(@(t,vars)wheat_wt_large(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_fm2);


[~,p_a2] = findpeaks(v_fm2(:,19),t_fm2);
[~,p_w2] = findpeaks(vars_solved_fm2(:,19),times_fm2);
p_w2(4) - p_a2(4) 


lc_testing = 0.1:0.1:3;
elf_testing = 0.1:0.1:3;

parms_to_model2 = parms;
clear parms 

different_peaks = parm_explore(@wheat_wt_large,parms_to_model2,[119,121],lc_testing, ...
    elf_testing,init_conditions_fm,480);

different_peaks(:,1) = different_peaks(:,1) - 1.0;
different_peaks(:,2) = different_peaks(:,2) - 1.0;

different_peaks_final = different_peaks;

for ri = 1:length(different_peaks(:,4))
    r = different_peaks(ri,4);
    if r < 0.5
        different_peaks(ri,4) = 0;
    else 
        different_peaks_final(ri,1:2) = NaN;
    end

end


different_peaks = array2table(different_peaks);
different_peaks.Properties.VariableNames{1} = 'LHY Activity';
different_peaks.Properties.VariableNames{2} = 'ELF3 Activity';
different_peaks.Properties.VariableNames{3} = 'Hours Until Dawn';
different_peaks.Properties.VariableNames{4} = 'Peak Time Range';

different_peaks_final = array2table(different_peaks_final);
different_peaks_final.Properties.VariableNames{1} = 'LHY Activity';
different_peaks_final.Properties.VariableNames{2} = 'ELF3 Activity';
different_peaks_final.Properties.VariableNames{3} = 'Hours Until Dawn';
different_peaks_final.Properties.VariableNames{4} = 'Peak Time Range';


tiledlayout(2,2)
nexttile
heatmap(different_peaks,'LHY Activity','ELF3 Activity','ColorVariable','Hours Until Dawn', ...
    'ColorLimits',[0 5],'Colormap',autumn)
set(gca,'fontname','times')
set(gca,"FontSize",12)
nexttile
heatmap(different_peaks,'LHY Activity','ELF3 Activity','ColorVariable','Peak Time Range', ...
    'ColorLimits',[0 5],'Colormap',parula)
set(gca,'fontname','times')
set(gca,"FontSize",12)
nexttile
heatmap(different_peaks_final,'LHY Activity','ELF3 Activity','ColorVariable','Hours Until Dawn', ...
    'ColorLimits',[0 5],'Colormap',hot)
set(gca,'fontname','times')
set(gca,"FontSize",12)
nexttile
diff_p_fin_matx = table2array(different_peaks_final);
plot(diff_p_fin_matx(diff_p_fin_matx(:,1) == 1,2), ...
    diff_p_fin_matx(diff_p_fin_matx(:,1) == 1,3),'-o', ...
    diff_p_fin_matx(diff_p_fin_matx(:,1) == 0.7,2), ...
    diff_p_fin_matx(diff_p_fin_matx(:,1) == 0.7,3),'-o', ...
    diff_p_fin_matx(339:364,2), ...
    diff_p_fin_matx(339:364,3),'-o', ...
    diff_p_fin_matx(diff_p_fin_matx(:,1) == 0,2), ...
    diff_p_fin_matx(diff_p_fin_matx(:,1) == 0,3),'-o')
lgd = legend("LHY Activity = +1 from \itArabidopsis\rm","+0.7","+0.4","+0");
lgd.Location = 'northwest';
ylim([0,6])
xlabel("ELF3 Involement in the EC compared to \itArabidopsis\rm")
ylabel("ELF3 Peak, Hours Until Dawn")
set(gca,'fontname','times')
set(gca,"FontSize",12)

heatmap(different_peaks_final,'LHY Activity','ELF3 Activity','ColorVariable','Hours Until Dawn', ...
    'ColorLimits',[0 5],'Colormap',hot)
set(gca,'fontname','times')
set(gca,"FontSize",12)











