
cd c:\Users\Jamila\Documents\'University Work'\'4th Year'\Project
currentFolder = pwd;

parms(1) = 1.022;
parms(2) = 9.866;
parms(3) = 5.353;
parms(4) = 2.278;
parms(5) = 5.917;
parms(6) = 4.365;

parms(7) = 0.409;
parms(8) = 2.021;
parms(9) = 0.03313;
parms(10) = 0.1;
parms(11) = 0.3853;
parms(12) = 0.2525;

parms(13) = 0.996;
parms(14) = 0.5889;
parms(15) = 0.3761;
parms(16) = 2.3;
parms(17) = 0.0133;
parms(18) = 0.64787;
parms(19) = 5.437;
parms(20) = 0.1225;
parms(21) = 0.01001;
parms(22) = 0.6771;
parms(23) = 1.998;
parms(24) = 0.276;
parms(25) = 4.916;
parms(26) = 0.0903;
parms(27) = 0.5383;
parms(28) = 0.04744;
parms(29) = 2.426;
parms(30) = 0.2;
parms(31) = 0.2;
parms(32) = 0.1;
parms(33) = 0.3012;
parms(34) = 0.1764;
parms(35) = 2.848;
parms(36) = 0.4176;
parms(37) = 1.57;
parms(38) = 0.1;
parms(39) = 0.02757; 
parms(40) = 0.01;
parms(41) = 5.491;
parms(42) = 0.3;
parms(43) = 5.681;
parms(44) = 13;
parms(45) = 0.1115;
parms(46) = 0.9188;
parms(47) = 0.5711;
parms(48) = 0.9391;
parms(49) = 7.975;
parms(50) = 0.216;
parms(51) = 0.3759;
parms(52) =  0.5214;
parms(53) = 0.3577;
parms(54) = 0.7944;
parms(55) = 0.7541;
parms(56) = 0.1293;

parms(57) = 0.23;
parms(58) = 20;
parms(59) = 0.1;

parms(60) = 0.6;
parms(61) = 0.3;
parms(62) = 0.2;
parms(63) = 1.78;
parms(64) = 8;
parms(65) = 0.7;
parms(66) = 0.3;
parms(67) = 3;
parms(68) = 0.4024;
parms(69) = 1.461;
parms(70) = 1.111;
parms(71) = 2.13;
parms(72) = 25.2;

parms(73) = 0.1217;
parms(74) = 0.2873;

parms(75) = 3.747;
parms(76) = 2.384;
parms(77) = 4.747; 
parms(78) = 16.3;
parms(79) = 0.1;
parms(80) = 0.4728;
parms(81) = 35.94;
parms(82) = 2.225;
parms(83) = 0.5885;
parms(84) = 21.086;
parms(85) = 2.086;
parms(86) = 6.033;
parms(87) = 1.053;
parms(88) = 12.66;
parms(89) = 6.743;
parms(90) = 0.1519;
parms(91) = 5.199;
parms(92) = 1.205;
parms(93) = 16.24;
parms(94) = 0.1465;
parms(95) = 5.127;
parms(96) = 1.971;
parms(97) = 7.1;
parms(98) = 16.33;
parms(99) = 1.027;
parms(100) = 5.466;
parms(101) = 6.864;
parms(102) = 8.392;
parms(103) = 0.1423;
parms(104) = 2.714;
parms(105) = 0.01041;
parms(106) = 4.775;
parms(107) = 0.9026;
parms(108) = 0.05704;
parms(109) = 0.02929;
parms(110) = 0.49;
parms(111) = 0.554;
parms(112) = 0.05062;
parms(113) = 1.051;

parms(114) = 1.103;
parms(115) = 0.5891;
parms(116) = 0.2317;
parms(117) = 0.1472;
parms(118) = 0.8543;

parms(119) = 2.8; %1
parms(120) = 1; %1
parms(121) = 0.1; %1

t_end = 480; 

LHYm_init = 0.6;
LHYp_init = 0.6;
CCA1m_init = 0.6;
CCA1p_init = 0.6;
Pp_init2 = 4;
P9m_init = 0.05;
P9p_init = 0.05;
P7m_init = 0.05;
P7p_init = 0.05;
P5m_init = 0.05;
P5pc_init = 0.05;
P5pn_init = 0.05;
TOC1m_init = 0.3;
TOC1pn_init = 0.3;
TOC1pc_init = 0.3;
E4m_init = 0.05;
E4p_init = 0.05;
E4D_init = 0.05;
E3m_init = 0.1;
E3p_init = 0.1;
E34_init = 0.05;
LUXm_init = 0.2;
LUXp_init = 0.2;
COP1pc_init = 0.4;
COP1pn_init = 0.4;
COP1D_init = 0.2;
ZTLp_init = 0.3;
ZGp_init = 0.2;
GIm_init = 0.3; 
GIpc_init = 0.2;
GIpn_init = 0.1;
NOXm_init = 0.2;
NOXp_init = 0.2;
RVE8m_init = 0.6;
RVE8p_init = 0.6;

init_conditions_fm = [LHYm_init,LHYp_init,CCA1m_init,CCA1p_init,Pp_init2,P9m_init,P9p_init,P7m_init,P7p_init,P5m_init,P5pc_init,P5pn_init,TOC1m_init,TOC1pn_init,TOC1pc_init,E4m_init,E4p_init,E4D_init,E3m_init,E3p_init,E34_init,LUXm_init,LUXp_init,COP1pc_init,COP1pn_init,COP1D_init,ZTLp_init,ZGp_init,GIm_init,GIpc_init,GIpn_init,NOXm_init,NOXp_init,RVE8m_init,RVE8p_init];
LD_cyc_typ = [0,0.5]; % LD cycle ratio
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD
[times_fm,vars_solved_fm] = ode15s(@(t,vars)arbdpss_F2014_mod(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_fm);
plot(times_fm,vars_solved_fm(:,13),times_fm,vars_solved_fm(:,1),times_fm,vars_solved_fm(:,19))

LDLD_or_LDLL = "LDLL";
init_conditions_fm = vars_solved_fm(end,:);
[times_fm2,vars_solved_fm2] = ode15s(@(t,vars)arbdpss_F2014_mod(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_fm);
plot(times_fm2,vars_solved_fm2(:,13),times_fm2,vars_solved_fm2(:,1),times_fm2,vars_solved_fm2(:,19))

parms(120) = 0;
init_conditions_mut = [LHYm_init,LHYp_init,CCA1m_init,CCA1p_init,Pp_init2,P9m_init,P9p_init,P7m_init,P7p_init,P5m_init,P5pc_init,P5pn_init,TOC1m_init,TOC1pn_init,TOC1pc_init,E4m_init,E4p_init,E4D_init,E3m_init,E3p_init,E34_init,LUXm_init,LUXp_init,COP1pc_init,COP1pn_init,COP1D_init,ZTLp_init,ZGp_init,GIm_init,GIpc_init,GIpn_init,NOXm_init,NOXp_init,RVE8m_init,RVE8p_init];
LD_cyc_typ = [0,0.5]; % LD cycle ratio
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD
[times_fm_mut,vars_solved_fm_mut] = ode15s(@(t,vars)arbdpss_F2014_mod(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_fm);

LDLD_or_LDLL = "LDLL";
init_conditions_fm_mut = vars_solved_fm_mut(end,:);
[times_fm_mut2,vars_solved_fm_mut2] = ode15s(@(t,vars)arbdpss_F2014_mod(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_fm);
plot(times_fm_mut2,vars_solved_fm_mut2(:,13),times_fm_mut2,vars_solved_fm_mut2(:,1),times_fm_mut2,vars_solved_fm_mut2(:,19))

cd c:\Users\Jamila\Documents\'University Work'\'4th Year'\Project\'Refined Models'
currentFolder = pwd;

%parms(121) = 0.1;
%parms(119) = 2;
init_conditions_w = [LHYm_init,LHYp_init,CCA1m_init,CCA1p_init,Pp_init2,P9m_init,P9p_init,P7m_init,P7p_init,P5m_init,P5pc_init,P5pn_init,TOC1m_init,TOC1pn_init,TOC1pc_init,E4m_init,E4p_init,E4D_init,E3m_init,E3p_init,E34_init,LUXm_init,LUXp_init,COP1pc_init,COP1pn_init,COP1D_init,ZTLp_init,ZGp_init,GIm_init,GIpc_init,GIpn_init,NOXm_init,NOXp_init,RVE8m_init,RVE8p_init];
LD_cyc_typ = [0,0.5]; % LD cycle ratio
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD
[times_wld,vars_solved_wld] = ode15s(@(t,vars)wheat_wt_large(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_w);

LDLD_or_LDLL = "LDLL";
init_conditions_w = vars_solved_wld(end,:);
[times_w,vars_solved_w] = ode15s(@(t,vars)wheat_wt_large(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_w);
plot(times_w,vars_solved_w(:,13),times_w,vars_solved_w(:,1),times_w,vars_solved_w(:,19))
legend("TOC1","LHY","ELF3")
xlim([0,120])
%plot(times_w,vars_solved_w(:,6))
xline([0:24:120],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])

%% Mutant Run 




%%
lc_testing_large = [0.1:0.1:3];
e3_testing_large = [0.1:0.1:2];
init_conditions_w_l = [LHYm_init,LHYp_init,CCA1m_init,CCA1p_init,Pp_init2,P9m_init,P9p_init,P7m_init,P7p_init,P5m_init,P5pc_init,P5pn_init,TOC1m_init,TOC1pn_init,TOC1pc_init,E4m_init,E4p_init,E4D_init,E3m_init,E3p_init,E34_init,LUXm_init,LUXp_init,COP1pc_init,COP1pn_init,COP1D_init,ZTLp_init,ZGp_init,GIm_init,GIpc_init,GIpn_init,NOXm_init,NOXp_init,RVE8m_init,RVE8p_init];
parm_input = parms;

different_peaks_l = parm_explore(@wheat_wt_large,parm_input,[119,121],lc_testing_large, ...
    e3_testing_large,init_conditions_w_l,480);

different_peaks_l(:,1) = different_peaks_l(:,1) - 1.0;
different_peaks_l(:,2) = different_peaks_l(:,2) - 1.0;

different_peaks_final_l = different_peaks_l;

for ri = 1:length(different_peaks_l(:,4))
    r = different_peaks_l(ri,4);
    if r < 1
        different_peaks_l(ri,4) = 0;
    else 
        different_peaks_final_l(ri,1:2) = NaN;
    end

end

find(different_peaks_final_l(:,3) == nanmin(different_peaks_final_l(:,3)))
different_peaks_final_l(541,1:2)


different_peaks_l = array2table(different_peaks_l);
different_peaks_l.Properties.VariableNames{1} = 'LHY Activity';
different_peaks_l.Properties.VariableNames{2} = 'ELF3 Activity';
different_peaks_l.Properties.VariableNames{3} = 'Hours Until Dawn';
different_peaks_l.Properties.VariableNames{4} = 'Peak Time Range';

different_peaks_final_l = array2table(different_peaks_final_l);
different_peaks_final_l.Properties.VariableNames{1} = 'LHY Activity';
different_peaks_final_l.Properties.VariableNames{2} = 'ELF3 Activity';
different_peaks_final_l.Properties.VariableNames{3} = 'Hours Until Dawn';
different_peaks_final_l.Properties.VariableNames{4} = 'Peak Time Range';


tiledlayout(2,2)
nexttile
heatmap(different_peaks_l,'LHY Activity','ELF3 Activity','ColorVariable','Hours Until Dawn', ...
    'ColorLimits',[0 15],'Colormap',autumn)
nexttile
heatmap(different_peaks_l,'LHY Activity','ELF3 Activity','ColorVariable','Peak Time Range', ...
    'ColorLimits',[0 15],'Colormap',parula)
nexttile
heatmap(different_peaks_final_l,'LHY Activity','ELF3 Activity','ColorVariable','Hours Until Dawn', ...
    'ColorLimits',[0 15],'Colormap',hot)
nexttile
diff_p_fin_matx_l = table2array(different_peaks_final_l);
plot(diff_p_fin_matx_l(diff_p_fin_matx_l(:,1) == 2,2), ...
    diff_p_fin_matx_l(diff_p_fin_matx_l(:,1) == 2,3),'-o', ...
    diff_p_fin_matx_l(diff_p_fin_matx_l(:,1) == 1.5,2), ...
    diff_p_fin_matx_l(diff_p_fin_matx_l(:,1) == 1.5,3),'-o', ...
    diff_p_fin_matx_l(diff_p_fin_matx_l(:,1) == 1,2), ...
    diff_p_fin_matx_l(diff_p_fin_matx_l(:,1) == 1,3),'-o', ...
    diff_p_fin_matx_l(diff_p_fin_matx_l(:,1) == 0,2), ...
    diff_p_fin_matx_l(diff_p_fin_matx_l(:,1) == 0,3),'-o')
lgd = legend("LHY Activity = +2 from Arabidopsis","+1.5","+1","+0");
lgd.Location = 'southeast';
ylim([0,11])
xlabel("ELF3 Involement in the EC compared to Arabidopsis")
ylabel("ELF3 Peak, Hours Until Dawn")
set(gca,'fontname','times')
set(gca,"FontSize",11)

tiledlayout(2,3)
 
nexttile
minlhy = min(vars_solved_w(:,1));
maxlhy = max(vars_solved_w(:,1));
plot1 = plot(times_w,(vars_solved_w(:,1)-minlhy)/(maxlhy-minlhy),"black");
xlim([0,144])
ylim([-0.02,1.02])
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])
plot1.LineStyle = "-";
plot1.LineWidth = 2;
set(gca,'fontname','times')
set(gca,"FontSize",15)
title("LHY mRNA")
ylab.FontSize = 25;

nexttile
minlhy = min(vars_solved_w(:,6));
maxlhy = max(vars_solved_w(:,6));
plot2 = plot(times_w,(vars_solved_w(:,6)-minlhy)/(maxlhy-minlhy),"black");
xlim([0,144])
ylim([-0.02,1.02])
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])
plot2.LineStyle = "-";
plot2.LineWidth = 2;
set(gca,'fontname','times')
set(gca,"FontSize",15)
title("PRR95 mRNA")
ylab.FontSize = 25;

nexttile
minlhy = min(vars_solved_w(:,13));
maxlhy = max(vars_solved_w(:,13));
plot3 = plot(times_w,(vars_solved_w(:,13)-minlhy)/(maxlhy-minlhy),"black");
xlim([0,144])
ylim([-0.02,1.02])
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])
plot3.LineStyle = "-";
plot3.LineWidth = 2;
set(gca,'fontname','times')
set(gca,"FontSize",15)
title("TOC1 mRNA")
ylab.FontSize = 25;

nexttile
minp9 = min(vars_solved_w(:,19));
maxp9 = max(vars_solved_w(:,19));
plot4 = plot(times_w,(vars_solved_w(:,19)-minp9)/(maxp9-minp9),"black");
xlim([0,144])
ylim([-0.02,1.02])
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])
plot4.LineStyle = "-";
plot4.LineWidth = 2;
set(gca,'fontname','times')
set(gca,"FontSize",15)
title("ELF3 mRNA")

nexttile
minp9 = min(vars_solved_w(:,16));
maxp9 = max(vars_solved_w(:,16));
plot4 = plot(times_w,(vars_solved_w(:,16)-minp9)/(maxp9-minp9),"black");
xlim([0,144])
ylim([-0.02,1.02])
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])
plot4.LineStyle = "-";
plot4.LineWidth = 2;
set(gca,'fontname','times')
set(gca,"FontSize",15)
title("ELF4 mRNA")

nexttile
EC_beh = parms(120)*((vars_solved_w(:,23)+parms(12)*vars_solved_w(:,33))*parms(121).*(vars_solved_w(:,21)+parms(7)*vars_solved_w(:,20)))./( ...
    1+parms(9)*(vars_solved_w(:,23)+parms(8)*vars_solved_w(:,33))+parms(10)*parms(121)*(vars_solved_w(:,21)+parms(7)*vars_solved_w(:,20)));
mint1 = min(EC_beh);
maxt1 = max(EC_beh);
plot5 = plot(times_w,(EC_beh-mint1)/(maxt1-mint1),"black");
xlim([0,144])
ylim([-0.02,1.02])
xline([0:24:240],':','HandleVisibility','off');
set(gcf,'color','w');
set(gca,'TickLength',[0,0])
plot5.LineStyle = "-";
plot5.LineWidth = 2;
set(gca,'fontname','times')
set(gca,"FontSize",15)
title("EC")




