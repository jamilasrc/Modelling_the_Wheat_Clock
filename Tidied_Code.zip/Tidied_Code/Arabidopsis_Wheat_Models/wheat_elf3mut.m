function solutions = wheat_elf3mut(t,vars,parms,LDLD_or_LDLL,LD_cyc)

% This Model is of my own creation, detailed in my master's project
% Modified from de Caluwe et al., 2016

% How mutant activity is captured - ELF3 mRNA production is removed from the model, ELF3
%  protein production is set to 0. This is a bit rough and ready, since the
%  wheat ELF3 mutants did have some ELF3 transcript production but at very
%  low levels.

% This model was used to see if the wheat models
% would capture the ELF3 mutant (once parameters were fitted to the wt).

%% Light/Dark Cycle

% This creates binary oscillations over 24h increments 
% A bit rough and ready, can only compute some short day, normal data and
% long day cycles. 

% Normal-Day = 12h/12h L/D 
% Long-Day = 16h/8h L/D
% Short-Day = 8h/16h L/D


if(LD_cyc == "Normal Day")

    LD_cyc_typ = [0,0.5];

elseif(LD_cyc == "Long Day")

    LD_cyc_typ = [30,0.75];

elseif(LD_cyc == "Short Day")

    LD_cyc_typ = [-30,0.25];

end

if(LDLD_or_LDLL == "LDLD")

    L = round(0.5*sind(15*t-LD_cyc_typ(1))+LD_cyc_typ(2)); 
    D = 1 - L;  

elseif(LDLD_or_LDLL == "LDLL")
    
    if(t > 24)
    
        L = 1;
        D = 0;

    else 
    
        L = round(0.5*sind(15*t-LD_cyc_typ(1))+LD_cyc_typ(2));
        D = 1 - L;

    end 

end 

%% Parameters 

par_v1 = parms(1);
par_v1L = parms(2);
par_v2A = parms(3);
parms_v2B = parms(4);
par_v2L = parms(5);
par_v3 = parms(6);
par_v3A = parms(7);
par_v4 = parms(8);
par_v5 = parms(9);
par_v6 = parms(10);

par_k1L = parms(11);
par_k1D = parms(12);
par_k2 = parms(13);
par_k3 = parms(14);
par_k4 = parms(15);
par_k5 = parms(16);
par_k6 = parms(17);
par_k7 = parms(18);

par_p1 = parms(19);
par_p1L = parms(20);
par_p2 = parms(21);
par_p3 = parms(22);
par_p4 = parms(23);
par_p5 = parms(24);
par_p6 = parms(25);
par_p7 = parms(26);
par_d1 = parms(27);
par_d2D = parms(28);
par_d2L = parms(29);
par_d3D = parms(30);
par_d3L = parms(31);
par_d4D = parms(32);
par_d4L = parms(33);
par_d5D = parms(34);
par_d5L = parms(35);
par_d6D = parms(36);
par_d6L = parms(37);
par_d7D = parms(38);
par_d7L = parms(39);
par_dp = parms(40);

par_K0 = parms(41);
par_K1 = parms(42);
par_K2 = parms(43);
par_K3 = parms(44);
par_K3act = parms(45);
par_K4 = parms(46);
par_K5 = parms(47);
par_K5b = parms(48);
par_K6 = parms(49);
par_K7 = parms(50);
par_K8 = parms(51);
par_K9 = parms(52);
par_K10 = parms(53);
par_K11 = parms(54);
par_K12 = parms(55);
par_K13 = parms(56);
par_K14 = parms(57);
par_K15 = parms(58);
par_K16 = parms(59);
par_K17 = parms(60);
par_K18 = parms(61);

par_w1 = parms(62);
par_w2 = parms(63);
par_w3 = parms(64);
par_w4 = parms(65);
par_w5 = parms(66);
par_w6 = parms(67);

%% Model Variables 
LHY_m = vars(1); % LHY mrna
LHY_p = vars(2); % LHY protein 
P_p = vars(3); % Dark Accumulator
P95_m = vars(4); % PRR95 mrna 
P95_p = vars(5); % PRR95 protein
P73_m = vars(6); % PRR73 mRNA
P73_p = vars(7); % PRR73 protein
P5T1_m = vars(8); % PRR59/TOC1 mrna
P5T1_p = vars(9); % PRR59/TOC1 protein 
E4_m = vars(10); % ELF4 mrna 
E4_p = vars(11); % ELF4 protein 
LUX_m = vars(12); % LUX mRNA
LUX_p = vars(13); % LUX protein
EC_p = vars(14); % Evening Complex

%% Non-ODE Equations

% LHY morning repression activity
LC = par_w1*LHY_p;
% PRR5/TOC1 Activity
P5T1_act = par_w5*P5T1_p;
% EC Activity
EC = par_w6*EC_p;
% ELF3 
E3_p = 0;

%% ODEs

% Change in LHY mRNA
dLHY_m = (par_v1+par_v1L*L*P_p)/(1+(LC/par_K0)^2+(P95_p/par_K1)^2+(P5T1_act/par_K2)^2+(P73_p/par_K3)^2) - ( ...
    par_k1L*L+par_k1D*D)*LHY_m;
% Change in LHY protein 
dLHY_p = (par_p1+par_p1L*L)*LHY_m - par_d1*LHY_p;
% Change in P (dark accumulator) protein 
dP_p = 0.3*(1-P_p)*D - par_dp*P_p*L;
% Change in PRR9 mRNA
dP95_m = (par_v2L*L*P_p+par_v2A+parms_v2B*((LC^2)/(par_K3act^2+LC^2)))/(1+(P5T1_act/par_K4)^2+(EC/par_K5)^2+(LC/par_K5b)^2) - ( ...
    par_k2*P95_m);
% Change in PRR9 protein 
dP95_p = par_p2*P95_m - (par_d2D*D+par_d2L*L)*P95_p;
% Change in PRR7 mRNA
dP73_m = (par_v3/(1+(P5T1_act/par_K6)^2+(EC/par_K7)^2+(LC/par_K8)^2) - ( ...
    par_k3*P73_m));
% Change in PRR7 protein 
dP73_p = par_p3*P73_m - (par_d3D*D+par_d3L*L)*P73_p;
% Change in PRR5/TOC1 mRNA
dP5T1_m = par_v4/(1+(LC/par_K9)^2+(P5T1_act/par_K10)^2+(EC/par_K7)^2) - par_k4*P5T1_m;
% Change in PRR5/TOC1 protein
dP5T1_p = par_p4*P5T1_m - (par_d4D*D+par_d4L*L)*P5T1_p;
% Change in ELF4 mRNA 
dE4_m = (par_v5)/(1+(LC/par_K11)^2+(P5T1_act/par_K12)^2+(EC/par_K13)^2) - ( ...
    par_k5*E4_m);
% Change in ELF4 protein
dE4_p = par_p5*E4_m - (par_d5D*D+par_d5L*L)*E4_p;
% Change in LUX mRNA
dLUX_m = (par_v6)/(1+(LC/par_K14)^2+(P5T1_act/par_K15)^2+(EC/par_K16)^2) - ( ...
    par_k6*LUX_m);
% Change in LUX 
dLUX_p = par_p6*LUX_m - (par_d6D*D+par_d6L*L)*LUX_p;
% Change in Evening Complex
dEC_p = par_w2*LUX_p*E4_p*(par_w3*E3_p) - par_w4*EC_p;


%%
solutions = [dLHY_m;dLHY_p;dP_p;dP95_m;dP95_p;dP73_m;dP73_p;dP5T1_m;dP5T1_p;
    dE4_m;dE4_p;dLUX_m;dLUX_p;dEC_p];

end