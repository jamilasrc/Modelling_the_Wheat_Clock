% Compact Models Only 

%% Arabidopsis 
CLm_init = 4.5;
CLp_init = 4.5;
P_init = 3;
P97m_init = 0.9;
P97p_init = 0.9;
T1P5m_init = 0.6;
T1P5p_init = 0.6;
ELm_init = 0.5;
ELp_init = 0.5;

init_cond_a = [CLm_init,CLp_init,P97m_init,P97p_init,T1P5m_init,T1P5p_init,ELm_init,ELp_init,P_init];

% 12/12 day

LD_cyc_typ = "Normal Day"; % LD cycle ratio
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD
t_end = 480;

% Run LDLD to get initial conditions
[t_araldld_12,v_araldld_12] = ode15s(@(t,vars)nspat_arbdps2(t,vars,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond_a);
init_conditions_upda12 = v_araldld_12(end,:);

% Model Testing 
LDLD_or_LDLL = "LDLL";
[t_ara_12,v_ara_12] = ode15s(@(t,vars)nspat_arbdps2(t,vars,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_upda12);

% long day 
LD_cyc_typ = "Long Day"; % LD cycle ratio
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD

[t_araldld_16,v_araldld_16] = ode15s(@(t,vars)nspat_arbdps2(t,vars,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond_a);
init_conditions_upda16 = v_araldld_16(end,:);

LDLD_or_LDLL = "LDLL";
[t_ara_16,v_ara_16] = ode15s(@(t,vars)nspat_arbdps2(t,vars,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_upda16);

%% Wheat - Wittern
parms(1) = 4.58;
parms(2) = 3.0; 
parms(3) = 1.27;
parms(4) = 0.5;
parms(5) = 5.0;
parms(6) = 1.0;
parms(7) = 1.1;
parms(8) = 1.1;
parms(9) = 1;
parms(10) = 2; 

parms(11) = 0.53;
parms(12) = 0.21;
parms(13) = 0.35;
parms(14) = 0.56;
parms(15) = 0.57;
parms(16) = 0.4;
parms(17) = 0.4;
parms(18) = 0.5;

parms(19) = 0.76;
parms(20) = 0.42;
parms(21) = 1.01;
parms(22) = 0.64;
parms(23) = 0.22;
parms(24) = 0.6;
parms(25) = 0.6;
parms(26) = 0.8;
parms(27) = 0.68;
parms(28) = 0.5;
parms(29) = 0.29; 
parms(30) = 0.48; 
parms(31) = 0.38;
parms(32) = 1.2;
parms(33) = 0.38;
parms(34) = 0.5;
parms(35) = 0.8;
parms(36) = 0.5;
parms(37) = 0.8;
parms(38) = 0.7;
parms(39) = 0.7;
parms(40) = 0.6;

parms(41) = 2.80;
parms(42) = 0.16;
parms(43) = 1.18;
parms(44) = 0.5;
parms(45) = 0.2; 
parms(46) = 0.23; 
parms(47) = 0.63;
parms(48) = 1.73;
parms(49) = 0.46;
parms(50) = 0.5; 
parms(51) = 0.6;
parms(52) = 0.3;
parms(53) = 1.9;
parms(54) = 0.3;
parms(55) = 0.5;
parms(56) = 2.0;
parms(57) = 0.3;
parms(58) = 0.5;
parms(59) = 2.0;
parms(60) = 0.8;
parms(61) = 1.9;

parms(62) = 2.3179; 
parms(63) = 0.7446;
parms(64) = 0.8441; 
parms(65) = 0.5210; 
parms(66) = 1;
parms(67) = 1.8965; 

LHYm_init = 4.5;
LHYp_init = 4.5;
Pp_init = 3;
P95m_init = 0.9;
P95p_init = 0.9;
P73m_init = 1.5;
P73p_init = 1.5;
P5T1m_init = 0.6;
P5T1p_init = 0.6;
E4m_init = 0.5;
E4p_init = 0.5;
LUXm_init = 0.5;
LUXp_init = 0.5;
E3m_init = 1.3;
E3p_init = 1.3;
EC_init = 0.5;

init_cond_wt = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init];

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD
t_end = 480;

% Run LDLD to get initial conditions
[t_wheatwt_ldldw,v_wheatwt_ldldw] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond_wt);
init_conditions_updw = v_wheatwt_ldldw(end,:);

% Model Testing 
LDLD_or_LDLL = "LDLL";
[t_wheatwtw,v_wheatwtw] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_updw);


%% Wheat - Rees
clear parms

parms(1) = 4.58;
parms(2) = 3.0; %3.0
parms(3) = 1.27;
parms(4) = 0.5;
parms(5) = 5.0;
parms(6) = 1.0;
parms(7) = 2.56;
parms(8) = 1.1;
parms(9) = 1;
parms(10) = 2;

parms(11) = 0.53;
parms(12) = 0.21;
parms(13) = 0.35;
parms(14) = 0.56;
parms(15) = 0.57;
parms(16) = 0.4;
parms(17) = 0.4;
parms(18) = 0.5;

parms(19) = 0.76;
parms(20) = 0.42;
parms(21) = 1.01;
parms(22) = 0.64;
parms(23) = 0.22;
parms(24) = 0.6;
parms(25) = 0.6;
parms(26) = 0.8;
parms(27) = 0.68;
parms(28) = 0.5;
parms(29) = 0.29;
parms(30) = 0.48; 
parms(31) = 0.38;
parms(32) = 1.2; 
parms(33) = 0.38;
parms(34) = 0.5;
parms(35) = 0.8;
parms(36) = 0.5;
parms(37) = 0.8;
parms(38) = 0.7;
parms(39) = 0.7;
parms(40) = 0.6;

parms(41) = 2.80;
parms(42) = 0.16;
parms(43) = 1.18;
parms(44) = 0.5;
parms(45) = 0.2; 
parms(46) = 0.23;
parms(47) = 0.63;
parms(48) = 1.73;
parms(49) = 0.46;
parms(50) = 0.5; 
parms(51) = 0.6;
parms(52) = 0.3;
parms(53) = 1.9;
parms(54) = 0.3;
parms(55) = 0.5;
parms(56) = 2.0;
parms(57) = 0.3;
parms(58) = 0.5;
parms(59) = 2.0;
parms(60) = 3.14;
parms(61) = 18.86;

parms(62) = 2.3179; 
parms(63) = 0.7446;
parms(64) = 0.9503; 
parms(65) = 0.5210; 
parms(66) = 1;
parms(67) = 1.8965; 

LHYm_init = 4.5;
LHYp_init = 4.5;
Pp_init = 3;
P95m_init = 0.9;
P95p_init = 0.9;
P73m_init = 1.5;
P73p_init = 1.5;
P5T1m_init = 0.6;
P5T1p_init = 0.6;
E4m_init = 0.5;
E4p_init = 0.5;
LUXm_init = 0.5;
LUXp_init = 0.5;
E3m_init = 1.3;
E3p_init = 1.3;
EC_init = 0.5;

init_cond_wt = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init];

LD_cyc = "Long Day"; % LD cycle ratio
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD
t_end = 480;

% Run LDLD to get initial conditions
[t_wheatwt_ldldr,v_wheatwt_ldldr] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond_wt);
init_conditions_updr = v_wheatwt_ldldr(end,:);

% Model Testing 
LDLD_or_LDLL = "LDLL";
[t_wheatwtr,v_wheatwtr] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_updr);

%% Wheat - Wittern Partially Optimised 
clear parms

parms(1) = 4.58;
parms(2) = 3.0; %3.0
parms(3) = 1.27;
parms(4) = 0.5;
parms(5) = 5.0;
parms(6) = 1.0;
parms(7) = 1.1;
parms(8) = 1.1;
parms(9) = 1;
parms(10) = 2;

parms(11) = 0.53;
parms(12) = 0.21;
parms(13) = 0.35;
parms(14) = 0.56;
parms(15) = 0.57;
parms(16) = 0.4;
parms(17) = 0.4;
parms(18) = 0.5;

parms(19) = 0.76;
parms(20) = 0.42;
parms(21) = 1.01;
parms(22) = 0.64;
parms(23) = 0.22;
parms(24) = 0.6;
parms(25) = 0.6;
parms(26) = 0.8;
parms(27) = 0.68;
parms(28) = 0.5;
parms(29) = 0.29;
parms(30) = 0.48; 
parms(31) = 0.38;
parms(32) = 1.2;
parms(33) = 0.38;
parms(34) = 0.5;
parms(35) = 0.8;
parms(36) = 0.5;
parms(37) = 0.8;
parms(38) = 0.7;
parms(39) = 0.7;
parms(40) = 0.6;

parms(41) = 2.80;
parms(42) = 0.16;
parms(43) = 1.18;
parms(44) = 0.5;
parms(45) = 0.2;
parms(46) = 0.23;
parms(47) = 0.63;
parms(48) = 1.73;
parms(49) = 0.46;
parms(50) = 0.5; 
parms(51) = 0.6;
parms(52) = 0.3;
parms(53) = 1.9;
parms(54) = 0.3;
parms(55) = 0.5;
parms(56) = 2.0;
parms(57) = 0.3;
parms(58) = 0.5;
parms(59) = 2.0;
parms(60) = 0.8;
parms(61) = 1.9;

parms(62) = 2;
parms(63) = 0.7;
parms(64) = 0.3;
parms(65) = 0.2; 
parms(66) = 1;
parms(67) = 3;

LHYm_init = 4.5;
LHYp_init = 4.5;
Pp_init = 3;
P95m_init = 0.9;
P95p_init = 0.9;
P73m_init = 1.5;
P73p_init = 1.5;
P5T1m_init = 0.6;
P5T1p_init = 0.6;
E4m_init = 0.5;
E4p_init = 0.5;
LUXm_init = 0.5;
LUXp_init = 0.5;
E3m_init = 1.3;
E3p_init = 1.3;
EC_init = 0.5;

init_cond_wtpp = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init];

LD_cyc_typ = "Long Day"; % LD cycle ratio
LDLD_or_LDLL = "LDLD"; % LDLL or LDLD
t_end = 480;

% Run LDLD to get initial conditions
[t_wheatwt_ldldpp,v_wheatwt_ldldpp] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond_wtpp);
init_conditions_updpp = v_wheatwt_ldldpp(end,:);

% Model Testing 
LDLD_or_LDLL = "LDLL";
[t_wheatwtpp,v_wheatwtpp] = ode15s(@(t,vars)wheat_wt(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_updpp);

%% Clock Plot

% get EC peak timings
peak_times_ec = [];

time_opt = {t_ara_12,t_wheatwtr,t_ara_16,t_wheatwtw,t_wheatwtpp};
v_opt = {v_ara_12(:,8),v_wheatwtr(:,16),v_ara_16(:,8),v_wheatwtw(:,16),v_wheatwtpp(:,16)};

% find peak timings within first 25h to keep results consistent
for i = 1:5
    times = time_opt{i};
    vs = v_opt{i};

    [~,t_range_e] = min(abs(times-25)); 
    new_times = times(1:t_range_e);
    [~,pt] = findpeaks(vs(1:t_range_e));
    peak_times_ec = [peak_times_ec,[new_times(pt)]'];
end 

peak_times_ec = peak_times_ec([1,3,4,6,7]); % a bit of manual cleaning needed to be done here, identified some local peaks that are not true EC peaks in activity

circ1 = nsidedpoly(1000, 'Center', [0,0], 'Radius', 8);
plot(circ1, 'FaceColor', 'white')
axis equal
text([0,0,6.7,-6.5],[7,-7,0,0],["ZT0","ZT12","ZT6","ZT18"],"FontSize",15,"FontName","times", ...
    "HorizontalAlignment","center","VerticalAlignment","middle")
hold on
for time = peak_times_ec
    angle = (time/24)*360;
    quiver(0,0,5.4*sind(angle),5.4*cosd(angle),"off","LineWidth",2)
end 
hold on
plot(0,0,"o","MarkerFaceColor","black","MarkerEdgeColor","black")
set(gca,'visible','off')
lab = categorical({'\itArabidopsis\rm (Normal Day)','\itT. aestivum\rm (Normal Day)', ...
    '\itArabidopsis\rm (Long Day)','\itT. turgidum\rm (Long Day)','Partially Optimised \itT. turgidum\rm (Long Day)'});
lab = reordercats(lab,{'\itArabidopsis\rm (Normal Day)','\itT. aestivum\rm (Normal Day)', ...
    '\itArabidopsis\rm (Long Day)','\itT. turgidum\rm (Long Day)','Partially Optimised \itT. turgidum\rm (Long Day)'});
legend(["",lab],"Location","southoutside")


Xlab = categorical({'\itArabidopsis\rm (Normal Day)','\itT. aestivum\rm (Normal Day)', ...
    '\itArabidopsis\rm (Long Day)','\itT. turgidum\rm (Long Day)','Partially Optimised \itT. turgidum\rm (Long Day)'});
Xlab = reordercats(Xlab,{'\itArabidopsis\rm (Normal Day)','\itT. aestivum\rm (Normal Day)', ...
    '\itArabidopsis\rm (Long Day)','\itT. turgidum\rm (Long Day)','Partially Optimised \itT. turgidum\rm (Long Day)'});
b = bar(Xlab,peak_times_ec,'FaceColor','flat');
b.CData(1:5,:) = [[0.175,0.54,0.60];[1,0.5,0.2];[0.850,0.91,0.166];[0.224,0.163,0.46];[0.4,0.25,0.8]];
ylim([0,24.5])
ylabel("Peak Timing (h)","FontSize",15,"FontName","times")

