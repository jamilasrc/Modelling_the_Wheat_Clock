function c_p_mat = circ_period(data,var_label)
% function for calculating the circadin phases of clock components

% data = matrix where column 1 = variable name, column 2 = peak timing
% var_label = variable index 

c_p_mat = [];

for v = var_label

    peak_ts = data(data(:,1) == v,2);
    peak_ts = str2double(peak_ts); % data ended up being a character matrix since it contained clock component names, convert peak timings back to double
 
    peaks_interest = peak_ts([peak_ts > 3 & peak_ts < 28.5]); % get peaks of interest to make sure circadian phase is reported within a 24h window (can't remember why peak timing has to be greater than 3h)
   
    % calculate difference in peak timing from 24h
    [~,abs_p_pos] = min(abs(peaks_interest-24));
    abs_phase = peaks_interest(abs_p_pos);
        
    % calculate average circadian period
    period = mean(diff(peak_ts));

    % calculate circadian phase, phase within first 24h * 24h / average
    % period
    circ_period = (abs_phase*24)/period;
    
    c_p_mat = [c_p_mat;[v,circ_period]];

end 


