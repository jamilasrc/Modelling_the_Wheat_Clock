function output = rAMP(vdata,tdata,peak_data,var_nam,var_no)
% function for calculating the relative amplitude rAMP of oscillations -
% difference between equillibrium value and peak of clock components

% v_data = clock model solutions/output variable values
% t_data = clock model time values 
% peak_data = peak timings, help locate peaks in v_data
% var_nam = names of clock components rAMP is being calculated for
% var_no = clock component/variable index in v_data

rAMP_out = [];

for v = 1:length(var_nam)
    
    % for each component 
    var = var_nam(v);
    var_ind = var_no(v);

    % get peak timings after first 24h
    p_v = str2double(peak_data(peak_data(:,1) == var,2));
    p_v = p_v(p_v >= 24);
    p_v = round(p_v,4); % can't remeber quite why I did this, might've just made numbers easier to work with during plotting

    % calculate equillibrium value of oscillations
    d_v = vdata(tdata >= 24 & tdata <= 72,var_ind); % get values in between 24h and 72h, best match for data I think/once oscillations are stable?
    baseline = mean(d_v); % mean value = equillibrium

    % calculate relative amplitude
    amp = mean(vdata(ismember(round(tdata,4),p_v),var_ind) - baseline); % find amplitude, difference between peak and equillbrium clock component activity
    rAMP = amp/baseline; % relative amplitude = amplitude/equillibrium

    rAMP_out = [rAMP_out,rAMP];

end 

output = rAMP_out;
