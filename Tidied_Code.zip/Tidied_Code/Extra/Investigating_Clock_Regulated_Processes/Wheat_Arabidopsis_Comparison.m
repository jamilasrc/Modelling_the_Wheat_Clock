%% Epidermis Models 

% Wheat 
parms(1) = 4.58;
parms(2) = 3.0; %3.0
parms(3) = 1.27;
parms(4) = 0.5;
parms(5) = 5.0;
parms(6) = 1.0;
parms(7) = 1.1;
parms(8) = 1.1;
parms(9) = 1;
parms(10) = 2; % 1

parms(11) = 0.53;
parms(12) = 0.21;
parms(13) = 0.35;
parms(14) = 0.56;
parms(15) = 0.57;
parms(16) = 0.4;
parms(17) = 0.4;
parms(18) = 0.5;

parms(19) = 0.76;
parms(20) = 0.42;
parms(21) = 1.01;
parms(22) = 0.64;
parms(23) = 0.22; % 0.6
parms(24) = 0.6;
parms(25) = 0.6;
parms(26) = 0.8;
parms(27) = 0.68;
parms(28) = 0.5;
parms(29) = 0.29; % 0.29
parms(30) = 0.48; 
parms(31) = 0.38;
parms(32) = 1.2; % 1.21
parms(33) = 0.38; % 0.38
parms(34) = 0.5;
parms(35) = 0.8;
parms(36) = 0.5;
parms(37) = 0.8;
parms(38) = 0.7;
parms(39) = 0.7;
parms(40) = 0.6;

parms(41) = 2.80;
parms(42) = 0.16; %0.16
parms(43) = 1.18;
parms(44) = 0.5;
parms(45) = 0.2; % 0.24
parms(46) = 0.23; % 0.28
parms(47) = 0.63; % 0.57
parms(48) = 1.73; % 1.73
parms(49) = 0.46;
parms(50) = 0.5; 
parms(51) = 0.6;
parms(52) = 0.3;
parms(53) = 1.9;
parms(54) = 0.3;
parms(55) = 0.5;
parms(56) = 2.0;
parms(57) = 0.3;
parms(58) = 0.5;
parms(59) = 2.0;
parms(60) = 0.8; % 0.8
parms(61) = 1.9;

parms(62) = 2.3179; 
parms(63) = 0.7446;
parms(64) = 0.8441; 
parms(65) = 0.5210; 
parms(66) = 1;
parms(67) = 1.8965; 

% growth
parms(68) = 0.1129;

parms(69) = 0.3322;
parms(70) = 0.86;

parms(71) = 0.5293; % 0.5293

parms(72) = 0.1591;

parms(73) = 0.4404; 
parms(74) = 5.0712;

parms(75) = 0.0005;
parms(76) = 0.18;

LHYm_init = 4.5;
LHYp_init = 4.5;
Pp_init = 3;
P95m_init = 0.9;
P95p_init = 0.9;
P73m_init = 1.5;
P73p_init = 1.5;
P5T1m_init = 0.6;
P5T1p_init = 0.6;
E4m_init = 0.5;
E4p_init = 0.5;
LUXm_init = 0.5;
LUXp_init = 0.5;
E3m_init = 1.3;
E3p_init = 1.3;
EC_init = 0.5;

% Growth
PIFm_init = 0.1;
PIFp_init = 0.1;
HYP_init = 0.1;

init_cond_ep = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init,PIFm_init,PIFp_init,HYP_init];

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480;

[t_ep_ldld_og,v_ep_ldld_og] = ode15s(@(t,vars)epidermis(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_ep);
init_cond_upd_ep_og = v_ep_ldld_og(end,:);
[t_ep_og,v_ep_og] = ode15s(@(t,vars)epidermis(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_upd_ep_og);
v_ep_og(end,19) % 1.4786


% Arabidopsis 
CLm_init = 4.5;
CLp_init = 4.5;
P_init = 3;
P97m_init = 0.9;
P97p_init = 0.9;
T1P5m_init = 0.6;
T1P5p_init = 0.6;
ELm_init = 0.5;
ELp_init = 0.5;

% Growth
a_PIFm_init = 0.1;
a_PIFp_init = 0.1;
a_HYP_init = 0.1;

init_cond_ep_a = [CLm_init,CLp_init,P97m_init,P97p_init,T1P5m_init,T1P5p_init,ELm_init,ELp_init,P_init,a_PIFm_init,a_PIFp_init,a_HYP_init];

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480;

[~,v_ep_ldld_a] = ode15s(@(t,vars)ara_epidermis(t,vars,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_ep_a);
init_cond_upd_ep_a = v_ep_ldld_a(end,:);
[t_ep_a,v_ep_a] = ode15s(@(t,vars)ara_epidermis(t,vars,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_upd_ep_a);

plot(t_ep_og,v_ep_og(:,19),t_ep_a,v_ep_a(:,12))
legend("Wheat","Arabidopsis")
xline(0:24:480,':','HandleVisibility','off');
xline(16:24:480,':','HandleVisibility','off');


% Calculate Day and Night Growth Rates
[~,ds_w] = min(abs(t_ep_og-240));
[~,de_w] = min(abs(t_ep_og-256));
[~,ne_w] = min(abs(t_ep_og-264));

[~,ds_a] = min(abs(t_ep_a-240));
[~,de_a] = min(abs(t_ep_a-256));
[~,ne_a] = min(abs(t_ep_a-264));

wheat_day = (v_ep_og(de_w,19)-v_ep_og(ds_w,19))/16;
ara_day = (v_ep_a(de_a,12)-v_ep_a(ds_a,12))/16;
wheat_night = (v_ep_og(ne_w,19)-v_ep_og(de_w,19))/8;
ara_night = (v_ep_a(ne_a,12)-v_ep_a(de_a,12))/8;

growth_rates = {"Wheat Day",wheat_day;"Wheat Night",wheat_night;"Arabidopsis Day",ara_day;"Arabidopsis Night",ara_night};
% 1 order of magnitude difference


% Plot Again
init_cond_upd_ep_2 = v_ep_ldld_og(end,:);
init_cond_upd_ep_2(19) = 0;
[t_ep_og2,v_ep_og2] = ode15s(@(t,vars)epidermis(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_upd_ep_2);
init_cond_upd_ep2_a = v_ep_ldld_a(end,:);
init_cond_upd_ep2_a(12) = 0;
[t_ep_a2,v_ep_a2] = ode15s(@(t,vars)ara_epidermis(t,vars,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_upd_ep2_a);

[~,ind48w] = min(abs(t_ep_og2-48));
[~,ind48a] = min(abs(t_ep_a2-48)); 

ming = min([v_ep_og2(1:ind48w,19);v_ep_a2(1:ind48a,12)]);
maxg = max([v_ep_og2(1:ind48w,19);v_ep_a2(1:ind48a,12)]);
 
ylim([0,1])
rectangle("Position",[16,0,8,1],"FaceColor",[0.8,0.8,0.8], ...
    "EdgeColor",[0.8,0.8,0.8])
rectangle("Position",[24+16,0,8,1],"FaceColor",[0.8,0.8,0.8], ...
    "EdgeColor",[0.8,0.8,0.8])
hold on 
plot1 = plot(t_ep_og2,(v_ep_og2(:,19)-ming)/(maxg-ming),"-.",t_ep_a2,(v_ep_a2(:,12)-ming)/(maxg-ming),"-.");
plot1(1).Color = "black";
plot1(2).Color = "red";
plot1(1).LineWidth = 2;
plot1(2).LineWidth = 2;
xline(0:24:480,':','HandleVisibility','off');
xline(16:24:480,':','HandleVisibility','off');
xlim([0,48])
set(gca,'fontname','times')
set(gca,"FontSize",15)
set(gca,'visible','off')
set(gca,'TickLength',[0,0])
set(gcf,'color','w');

% Calculate and plot derivatives
d_range_w = v_ep_og2(1:ind48w,19);
d_range_w_t = t_ep_og2(1:ind48w);
d_range_a = v_ep_a2(1:ind48a,12);
d_range_a_t = t_ep_a2(1:ind48a);

deriv_wheat = [];

for i = 1:(length(d_range_w)-1)

    deriv_w = derivative(d_range_w(i),d_range_w(i+1),(d_range_w_t(i+1)-d_range_w_t(i)));
    deriv_wheat = [deriv_wheat,deriv_w];

end 

deriv_ara = [];

for i = 1:(length(d_range_a)-1)

    deriv_a = derivative(d_range_a(i),d_range_a(i+1),(d_range_a_t(i+1)-d_range_a_t(i)));
    deriv_ara = [deriv_ara,deriv_a];
    
end 

rectangle("Position",[16,0,8,1],"FaceColor",[0.8,0.8,0.8], ...
    "EdgeColor",[0.8,0.8,0.8])
hold on 
ylim([0,0.025])
plot2 = plot(d_range_w_t(1:end-1),deriv_wheat,"black",d_range_a_t(1:end-1),deriv_ara,"red");
plot2(1).LineWidth = 2;
plot2(2).LineWidth = 2;
plot2(1).LineStyle = "-.";
plot2(2).LineStyle = "-.";
set(gca,'fontname','times')
set(gca,"FontSize",15)
xline(0:24:480,':','HandleVisibility','off');
xline(16:24:480,':','HandleVisibility','off');
xlim([0,24])
xlabel("t")
ylabel("Growth Rate")

plot(t_ep_a2,v_ep_a2(:,11),"red",t_ep_og2,v_ep_og2(:,18),"black")
xline(0:24:480,':','HandleVisibility','off');
xline(16:24:480,':','HandleVisibility','off');



%% Guard Cells 
clear workspace

% Wheat 

parms(1) = 4.58;
parms(2) = 3.0; %3.0
parms(3) = 1.27;
parms(4) = 0.5;
parms(5) = 5.0;
parms(6) = 1.0;
parms(7) = 1.1;
%parms(7) = 2;
parms(8) = 1.1;
parms(9) = 1;
parms(10) = 2; % 1

parms(11) = 0.53;
parms(12) = 0.21;
parms(13) = 0.35;
parms(14) = 0.56;
parms(15) = 0.57;
parms(16) = 0.4;
parms(17) = 0.4;
parms(18) = 0.5;

parms(19) = 0.76;
parms(20) = 0.42;
parms(21) = 1.01;
parms(22) = 0.64;
parms(23) = 0.22; % 0.6
parms(24) = 0.6;
parms(25) = 0.6;
parms(26) = 0.8;
parms(27) = 0.68;
parms(28) = 0.5;
parms(29) = 0.29; % 0.29
parms(30) = 0.48; 
parms(31) = 0.38;
parms(32) = 1.2; % 1.21
parms(33) = 0.38; % 0.38
parms(34) = 0.5;
parms(35) = 0.8;
parms(36) = 0.5;
parms(37) = 0.8;
parms(38) = 0.7;
parms(39) = 0.7;
parms(40) = 0.6;

parms(41) = 2.80;
parms(42) = 0.16; %0.16
parms(43) = 1.18;
parms(44) = 0.5;
parms(45) = 0.2; % 0.24
parms(46) = 0.23; % 0.28
parms(47) = 0.63; % 0.57
parms(48) = 1.73; % 1.73
parms(49) = 0.46;
parms(50) = 0.5; 
parms(51) = 0.6;
parms(52) = 0.3;
parms(53) = 1.9;
parms(54) = 0.3;
parms(55) = 0.5;
parms(56) = 2.0;
parms(57) = 0.3;
parms(58) = 0.5;
parms(59) = 2.0;
parms(60) = 0.8; % 0.8
parms(61) = 1.9;

parms(62) = 2.3179; 
parms(63) = 0.7446;
parms(64) = 0.8441; 
parms(65) = 0.5210; 
parms(66) = 1;
parms(67) = 1.8965; 

% sc
parms(68) = 0.5; % 0.5
parms(69) = 0.7; % 0.2
parms(70) = 0.3; % 0.5

parms(71) = 0.2; % 0.2
parms(72) = 0.1; % 0.1
parms(73) = 0.1; % 0.1
parms(74) = 0.5; % 0.1

parms(75) = 0.1; % 0.1
parms(76) = 0.3; % 0.3
parms(77) = 0.2; % 0.2
parms(78) = 0.3; % 0.3

parms(79) = 0.4; % 0.4

parms(80) = 0.2; % 0.2
parms(81) = 1; % 1
parms(82) = 0.3; % 0.3
parms(83) = 0.3;
parms(84) = 0.3; 


LHYm_init = 4.5;
LHYp_init = 4.5;
Pp_init = 3;
P95m_init = 0.9;
P95p_init = 0.9;
P73m_init = 1.5;
P73p_init = 1.5;
P5T1m_init = 0.6;
P5T1p_init = 0.6;
E4m_init = 0.5;
E4p_init = 0.5;
LUXm_init = 0.5;
LUXp_init = 0.5;
E3m_init = 1.3;
E3p_init = 1.3;
EC_init = 0.5;

% SC
ABARm_init = 0.3;
ABARp_init = 0.3;
AR_init = 0.2;
PP2C_init = 0.3;
SNRK2_init = 0.3;
SC_init = 0.1;

init_cond_gc = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init,ABARm_init,ABARp_init,AR_init,PP2C_init,SNRK2_init,SC_init];

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480;

[t_gc_ldld_og,v_gc_ldld_og] = ode15s(@(t,vars)guard_cells(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_gc);
init_cond_upd_gc_og = v_gc_ldld_og(end,:);
[t_gc_og,v_gc_og] = ode15s(@(t,vars)guard_cells(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_upd_gc_og);

% Arabidopsis 

CLm_init = 4.5;
CLp_init = 4.5;
P_init = 3;
P97m_init = 0.9;
P97p_init = 0.9;
T1P5m_init = 0.6;
T1P5p_init = 0.6;
ELm_init = 0.5;
ELp_init = 0.5;

% SC
aABARm_init = 0.3;
aABARp_init = 0.3;
aAR_init = 0.2;
aPP2C_init = 0.3;
aSNRK2_init = 0.3;
aSC_init = 0.1;

init_cond_gc_a = [CLm_init,CLp_init,P97m_init,P97p_init,T1P5m_init,T1P5p_init,ELm_init,ELp_init,P_init,aABARm_init,aABARp_init,aAR_init,aPP2C_init,aSNRK2_init,aSC_init];

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480;

[~,v_gc_ldld_a] = ode15s(@(t,vars)ara_guardcell(t,vars,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_gc_a);
init_cond_upd_gc_a = v_gc_ldld_a(end,:);
[t_gc_a,v_gc_a] = ode15s(@(t,vars)ara_guardcell(t,vars,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_upd_gc_a);


rectangle("Position",[16,0,8,1],"FaceColor",[0.8,0.8,0.8], ...
    "EdgeColor",[0.8,0.8,0.8])
rectangle("Position",[(24+16),0,8,1],"FaceColor",[0.8,0.8,0.8], ...
    "EdgeColor",[0.8,0.8,0.8])
hold on 
plot2 = plot(t_gc_og,normalize(v_gc_og(:,22),"range"),"black",t_gc_a,normalize(v_gc_a(:,15),"range"),"red");
xlim([0,48])
legend("Wheat","Arabidopsis")
xline(0:24:480,':','HandleVisibility','off');
xline(16:24:480,':','HandleVisibility','off');
plot2(1).LineWidth = 2;
plot2(2).LineWidth = 2;
plot2(1).LineStyle = "-.";
plot2(2).LineStyle = "-.";
set(gca,'fontname','times')
set(gca,"FontSize",15)
xlabel("t")
ylabel("Stomatal Opening")


% Calculate Phase Difference 
[~,ptw] = findpeaks(-v_gc_og(:,22),t_gc_og);
[~,pta] = findpeaks(-v_gc_a(:,15),t_gc_a);
phase_trough = mean(ptw-pta); % wheat troughs 2h ahead of Arabdopsis 
disp(phase_trough)

[~,ppw] = findpeaks(v_gc_og(:,22),t_gc_og);
[~,ppa] = findpeaks(v_gc_a(:,15),t_gc_a);
phase_peak = mean(ppw-ppa); % wheat peaks 1h ahead of Arabdopsis 
disp(phase_peak)

norm_sc_w = normalize(v_gc_og(:,22),"range");
norm_sc_a = normalize(v_gc_a(:,15),"range");

plot(t_gc_og,norm_sc_w,t_gc_a,norm_sc_a)
legend("Wheat","Arabidopsis")
xline(0:24:480,':','HandleVisibility','off');
xline(16:24:480,':','HandleVisibility','off');


% Calculate WUE in Arabidopsis vs Wheat assuming Arabidopsis peaks at solar noon
[~,wns] = min(abs(t_gc_og-232));
[~,wne] = min(abs(t_gc_og-240));
[~,arans] = min(abs(t_gc_a-230.26)); % push arabidopsis 1h back, since peak is 1h behind
[~,arane] = min(abs(t_gc_a-238.26));

wue_w = mean(norm_sc_w(wns:wne)); % 0.3229
wue_a = mean(norm_sc_a(arans:arane));
wue = {"Wheat",wue_w;"Arabidopsis",wue_a}; % WUE is higher in wheat than Arabidopsis 

[~,aranst] = min(abs(t_gc_a-232)); % push arabidopsis 1h back, since peak is 1h behind
[~,aranet] = min(abs(t_gc_a-240));
wue_at = mean(norm_sc_a(aranst:aranet));
disp(wue_at)

% Calculate SC activity during the day (photosynthesis estimate)
[~,wde] = min(abs(t_gc_og-(240+16)));
[~,arane_t] = min(abs(t_gc_a-240));
[~,arade] = min(abs(t_gc_a-(240+16)));

photo_w = mean(norm_sc_w(wne:wde)); % 0.6089
photo_a = mean(norm_sc_a(arane_t:arade));
photo_act = {"Wheat",photo_w;"Arabidopsis",photo_a};

%% Mesophyll
clear workspace

% Wheat
parms(1) = 4.58;
parms(2) = 3.0; %3.0
parms(3) = 1.27;
parms(4) = 0.5;
parms(5) = 5.0;
parms(6) = 1.0;
parms(7) = 1.1;
parms(8) = 1.1;
parms(9) = 1;
parms(10) = 2; % 1

parms(11) = 0.53;
parms(12) = 0.21;
parms(13) = 0.35;
parms(14) = 0.56;
parms(15) = 0.57;
parms(16) = 0.4;
parms(17) = 0.4;
parms(18) = 0.5;

parms(19) = 0.76;
parms(20) = 0.42;
parms(21) = 1.01;
parms(22) = 0.64;
parms(23) = 0.22; % 0.6
parms(24) = 0.6;
parms(25) = 0.6;
parms(26) = 0.8;
parms(27) = 0.68;
parms(28) = 0.5;
parms(29) = 0.29; % 0.29
parms(30) = 0.48; 
parms(31) = 0.38;
parms(32) = 1.2; % 1.21
parms(33) = 0.38; % 0.38
parms(34) = 0.5;
parms(35) = 0.8;
parms(36) = 0.5;
parms(37) = 0.8;
parms(38) = 0.7;
parms(39) = 0.7;
parms(40) = 0.6;

parms(41) = 2.80;
parms(42) = 0.16; %0.16
parms(43) = 1.18;
parms(44) = 0.5;
parms(45) = 0.2; % 0.24
parms(46) = 0.23; % 0.28
parms(47) = 0.63; % 0.57
parms(48) = 1.73; % 1.73
parms(49) = 0.46;
parms(50) = 0.5; 
parms(51) = 0.6;
parms(52) = 0.3;
parms(53) = 1.9;
parms(54) = 0.3;
parms(55) = 0.5;
parms(56) = 2.0;
parms(57) = 0.3;
parms(58) = 0.5;
parms(59) = 2.0;
parms(60) = 0.8; % 0.8
parms(61) = 1.9;

parms(62) = 2.3179; 
parms(63) = 0.7446;
parms(64) = 0.8441; 
parms(65) = 0.5210; 
parms(66) = 1;
parms(67) = 1.8965; 

% Starch-Sucrose Metabolism
parms(68) = 5;
parms(69) = 0.2; % 0.2
parms(70) = 0.6;
parms(71) = 0.0023;
parms(72) = 0.02;
parms(73) = 0.06;
parms(74) = 0.012;
parms(75) = 0.02;
parms(76) = 0.5; % 0.23
parms(77) = 0.03;

parms(78) = 1;
parms(79) = 1;
parms(80) = 0.2;
parms(81) = 0.4;
parms(82) = 0.2;
parms(83) = 0.2;
parms(84) = 0.07;

parms(85) = 0.2;
parms(86) = 1;
parms(87) = 0.5;
parms(88) = 0;

parms(89) = 3;
parms(90) = 0.05;
parms(91) = 0.3;

LHYm_init = 4.5;
LHYp_init = 4.5;
Pp_init = 3;
P95m_init = 0.9;
P95p_init = 0.9;
P73m_init = 1.5;
P73p_init = 1.5;
P5T1m_init = 0.6;
P5T1p_init = 0.6;
E4m_init = 0.5;
E4p_init = 0.5;
LUXm_init = 0.5;
LUXp_init = 0.5;
E3m_init = 1.3;
E3p_init = 1.3;
EC_init = 0.5;

Suc_init = 5;
S_prod_init = 0.1;
Suc_sen_init = 1;
Sdr_init = 0.5;
Beta_init = 0.05;
Alpha_init = 0.05;

init_cond_ss = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init,Suc_init,S_prod_init,Suc_sen_init,Sdr_init,Beta_init,Alpha_init];

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480;

[t_m_ldld_og,v_m_ldld_og] = ode15s(@(t,vars)mesophyll(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_ss);
init_cond_upd_m_og = v_m_ldld_og(end,:);
[t_m_og,v_m_og] = ode15s(@(t,vars)mesophyll(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_upd_m_og);

[~,t_start] = min(abs(t_m_og-46));
[~,t_end] = min(abs(t_m_og-48));

norm_v_m = normalize(v_m_og(:,18),"range");
starch_dev = abs((norm_v_m(t_end) - norm_v_m(t_start))/2); % 0.0621


% Arabidopsis
CLm_init = 4.5;
CLp_init = 4.5;
P_init = 3;
P97m_init = 0.9;
P97p_init = 0.9;
T1P5m_init = 0.6;
T1P5p_init = 0.6;
ELm_init = 0.5;
ELp_init = 0.5;

aSuc_init = 5;
aS_prod_init = 0.1;
aSuc_sen_init = 1;
aSdr_init = 0.5;
aBeta_init = 0.05;
aAlpha_init = 0.05;

init_cond_m_a = [CLm_init,CLp_init,P97m_init,P97p_init,T1P5m_init,T1P5p_init,ELm_init,ELp_init,P_init,aSuc_init,aS_prod_init,aSuc_sen_init,aSdr_init,aBeta_init,aAlpha_init];

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480;

[~,v_m_ldld_a] = ode15s(@(t,vars)ara_mesophyll(t,vars,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_m_a);
init_cond_upd_m_a = v_m_ldld_a(end,:);
[t_m_a,v_m_a] = ode15s(@(t,vars)ara_mesophyll(t,vars,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_upd_m_a);

plot(t_m_og,normalize(v_m_og(:,18),"range"),"black",t_m_a,normalize(v_m_a(:,11),"range"),"red");


tiledlayout(2,1)

nexttile
rectangle("Position",[448,0,8,1],"FaceColor",[0.8,0.8,0.8], ...
    "EdgeColor",[0.8,0.8,0.8])
rectangle("Position",[472,0,8,1],"FaceColor",[0.8,0.8,0.8], ...
    "EdgeColor",[0.8,0.8,0.8])
hold on 
plot3 = plot(t_m_og,normalize(v_m_og(:,17),"range"),"black",t_m_a,normalize(v_m_a(:,10),"range"),"red");
xlim([(480-48),480])
xline(0:24:480,':','HandleVisibility','off');
xline(16:24:480,':','HandleVisibility','off');
plot3(1).LineWidth = 2;
plot3(2).LineWidth = 2;
plot3(1).LineStyle = "-.";
plot3(2).LineStyle = "-.";
set(gca,'fontname','times')
set(gca,"FontSize",15)
title("Sucrose")
set(gca,'XTick',[], 'YTick', [])

nexttile 
rectangle("Position",[448,0,8,1],"FaceColor",[0.8,0.8,0.8], ...
    "EdgeColor",[0.8,0.8,0.8])
rectangle("Position",[472,0,8,1],"FaceColor",[0.8,0.8,0.8], ...
    "EdgeColor",[0.8,0.8,0.8])
hold on 
plot3 = plot(t_m_og,normalize(v_m_og(:,18),"range"),"black",t_m_a,normalize(v_m_a(:,11),"range"),"red");
xlim([(480-48),480])
xline(0:24:480,':','HandleVisibility','off');
xline(16:24:480,':','HandleVisibility','off');
plot3(1).LineWidth = 2;
plot3(2).LineWidth = 2;
plot3(1).LineStyle = "-.";
plot3(2).LineStyle = "-.";
set(gca,'fontname','times')
set(gca,"FontSize",15)
title("Starch")
set(gca,'XTick',[], 'YTick', [])


