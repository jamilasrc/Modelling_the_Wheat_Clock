function answer = derivative(y,y_delta,delta_x)
answer = (y_delta-y)/delta_x;
end