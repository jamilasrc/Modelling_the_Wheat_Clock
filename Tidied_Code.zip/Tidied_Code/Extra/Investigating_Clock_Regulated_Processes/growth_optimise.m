function cost = growth_optimise(parameters,parm_ind,parms_init,init_cond)
% Single Objective GA Optimisation

parms = parms_init;
parms(parm_ind) = parameters;

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; 
t_end = 960;

[~,v_ep] = ode15s(@(t,vars)epidermis(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond);

tot_growth = v_ep(end,19); % get final hypocotyl elongation

cost = 1/tot_growth; % ga minimises function, so to maximise growth the inverse is minimised