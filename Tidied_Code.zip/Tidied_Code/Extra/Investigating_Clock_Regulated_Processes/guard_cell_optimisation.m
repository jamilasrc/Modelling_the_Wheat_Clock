%% Initialising the Optimisation

parms(1) = 4.58;
parms(2) = 3.0; %3.0
parms(3) = 1.27;
parms(4) = 0.5;
parms(5) = 5.0;
parms(6) = 1.0;
parms(7) = 1.1;
%parms(7) = 2;
parms(8) = 1.1;
parms(9) = 1;
parms(10) = 2; % 1

parms(11) = 0.53;
parms(12) = 0.21;
parms(13) = 0.35;
parms(14) = 0.56;
parms(15) = 0.57;
parms(16) = 0.4;
parms(17) = 0.4;
parms(18) = 0.5;

parms(19) = 0.76;
parms(20) = 0.42;
parms(21) = 1.01;
parms(22) = 0.64;
parms(23) = 0.22; % 0.6
parms(24) = 0.6;
parms(25) = 0.6;
parms(26) = 0.8;
parms(27) = 0.68;
parms(28) = 0.5;
parms(29) = 0.29; % 0.29
parms(30) = 0.48; 
parms(31) = 0.38;
parms(32) = 1.2; % 1.21
parms(33) = 0.38; % 0.38
parms(34) = 0.5;
parms(35) = 0.8;
parms(36) = 0.5;
parms(37) = 0.8;
parms(38) = 0.7;
parms(39) = 0.7;
parms(40) = 0.6;

parms(41) = 2.80;
parms(42) = 0.16; %0.16
parms(43) = 1.18;
parms(44) = 0.5;
parms(45) = 0.2; % 0.24
parms(46) = 0.23; % 0.28
parms(47) = 0.63; % 0.57
parms(48) = 1.73; % 1.73
parms(49) = 0.46;
parms(50) = 0.5; 
parms(51) = 0.6;
parms(52) = 0.3;
parms(53) = 1.9;
parms(54) = 0.3;
parms(55) = 0.5;
parms(56) = 2.0;
parms(57) = 0.3;
parms(58) = 0.5;
parms(59) = 2.0;
parms(60) = 0.8; % 0.8
parms(61) = 1.9;

parms(62) = 2.3179; 
parms(63) = 0.7446;
parms(64) = 0.8441; 
parms(65) = 0.5210; 
parms(66) = 1;
parms(67) = 1.8965; 

% sc
parms(68) = 0.5; % 0.5
parms(69) = 0.7; % 0.2
parms(70) = 0.3; % 0.5

parms(71) = 0.2; % 0.2
parms(72) = 0.1; % 0.1
parms(73) = 0.1; % 0.1
parms(74) = 0.5; % 0.1

parms(75) = 0.1; % 0.1
parms(76) = 0.3; % 0.3
parms(77) = 0.2; % 0.2
parms(78) = 0.3; % 0.3

parms(79) = 0.4; % 0.4

parms(80) = 0.2; % 0.2
parms(81) = 1; % 1
parms(82) = 0.3; % 0.3
parms(83) = 0.3;
parms(84) = 0.3; 

parms_to_fit_sc = parms;
clear parms

LHYm_init = 4.5;
LHYp_init = 4.5;
Pp_init = 3;
P95m_init = 0.9;
P95p_init = 0.9;
P73m_init = 1.5;
P73p_init = 1.5;
P5T1m_init = 0.6;
P5T1p_init = 0.6;
E4m_init = 0.5;
E4p_init = 0.5;
LUXm_init = 0.5;
LUXp_init = 0.5;
E3m_init = 1.3;
E3p_init = 1.3;
EC_init = 0.5;

% SC
ABARm_init = 0.3;
ABARp_init = 0.3;
AR_init = 0.2;
PP2C_init = 0.3;
SNRK2_init = 0.3;
SC_init = 0.1;

init_cond_gc = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init,ABARm_init,ABARp_init,AR_init,PP2C_init,SNRK2_init,SC_init];

%% Fitting with MGA

options_mga = optimoptions('gamultiobj','InitialPopulationMatrix',parms_to_fit_sc([1,7:10]), ...
    'MaxGenerations',5000,'MaxStallGenerations',70,...
     'FunctionTolerance',1e-1,'ConstraintTolerance',1e-12);

[a0mga,~,~,~] = gamultiobj(@(parameters)stomata_optimise_mga(parameters,[1,7:10],parms_to_fit_sc,init_cond_gc), ...
    5,[],[],[],[],[0,0,0,0,0],[10,10,10,10,10],[],options_mga);


%% Simulation - testing the results 

parms = parms_to_fit_sc; 

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480;

[t_gc_ldld_og,v_gc_ldld_og] = ode15s(@(t,vars)guard_cells(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_gc);
init_cond_upd_gc_og = v_gc_ldld_og(end,:);
[t_gc_og,v_gc_og] = ode15s(@(t,vars)guard_cells(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_upd_gc_og);

plot(t_gc_og,v_gc_og(:,22))
xline([0:24:480],':','HandleVisibility','off');

clear parms

parms = parms_to_fit_sc; 
parms([1,7:10]) = a0mga(12,:);
% 6.64957838369328	1.03171774344129	9.45318200947799	0.220197919543164	2.24432234554821
% LHY more expression best fit, always increased, increased TOC1 most
% important, similar ELF3, lower ELF4 and LUX for optimal phenotype (but
% ELF4 often higher, LUX always low)

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480;

[t_gc_ldld,v_gc_ldld] = ode15s(@(t,vars)guard_cells(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_gc);
init_cond_upd_gc = v_gc_ldld(end,:);
[t_gc,v_gc] = ode15s(@(t,vars)guard_cells(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_upd_gc);

plot(t_gc_og,normalize(v_gc_og(:,22),"range"),t_gc,normalize(v_gc(:,22),"range"))
xline([0:24:480],':','HandleVisibility','off');
xline([16:24:480],':','HandleVisibility','off');
legend("Unfitted","Fitted")



[~,ogns] = min(abs(t_gc_og-232));
[~,ogne] = min(abs(t_gc_og-240));
[~,opts] = min(abs(t_gc-232)); % push arabidopsis 1h back, since peak is 1h behind
[~,optne] = min(abs(t_gc-240));

norm_og = normalize(v_gc_og(:,22),"range");
norm_opt = normalize(v_gc(:,22),"range");

wue_og = mean(norm_og(ogns:ogne));
wue_opt = mean(norm_opt(opts:optne));

[~,ogds] = min(abs(t_gc_og-216));
[~,opds] = min(abs(t_gc-216)); 

pho_og = mean(norm_og(ogds:ogns));
pho_opt = mean(norm_opt(opds:opts));


