%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Running the Spatial System %%%%%%%%%%%%%%%%

%% Set Coupling Values

% gc and epidermis should be more coupled than with mesophyll
% gc-meso and ep-meso should be similar since meso is an equal distance to
% both

% gc-epidermis = 0.4;
% gc-mesophyll = 0.1;
% ep-mesophyll = 0.1;

%% Create Parameter Lists
parms_list = {};

% Guard Cell Model 
              
parms(1) = 6.65;
parms(2) = 3.0; %3.0
parms(3) = 1.27;
parms(4) = 0.5;
parms(5) = 5.0;
parms(6) = 1.0;
parms(7) = 1.03;
parms(8) = 9.45;
parms(9) = 0.220;
parms(10) = 2.24; 

parms(11) = 0.53;
parms(12) = 0.21;
parms(13) = 0.35;
parms(14) = 0.56;
parms(15) = 0.57;
parms(16) = 0.4;
parms(17) = 0.4;
parms(18) = 0.5;

parms(19) = 0.76;
parms(20) = 0.42;
parms(21) = 1.01;
parms(22) = 0.64;
parms(23) = 0.22; % 0.6
parms(24) = 0.6;
parms(25) = 0.6;
parms(26) = 0.8;
parms(27) = 0.68;
parms(28) = 0.5;
parms(29) = 0.29; % 0.29
parms(30) = 0.48; 
parms(31) = 0.38;
parms(32) = 1.2; % 1.21
parms(33) = 0.38; % 0.38
parms(34) = 0.5;
parms(35) = 0.8;
parms(36) = 0.5;
parms(37) = 0.8;
parms(38) = 0.7;
parms(39) = 0.7;
parms(40) = 0.6;

parms(41) = 2.80;
parms(42) = 0.16; %0.16
parms(43) = 1.18;
parms(44) = 0.5;
parms(45) = 0.2; % 0.24
parms(46) = 0.23; % 0.28
parms(47) = 0.63; % 0.57
parms(48) = 1.73; % 1.73
parms(49) = 0.46;
parms(50) = 0.5; 
parms(51) = 0.6;
parms(52) = 0.3;
parms(53) = 1.9;
parms(54) = 0.3;
parms(55) = 0.5;
parms(56) = 2.0;
parms(57) = 0.3;
parms(58) = 0.5;
parms(59) = 2.0;
parms(60) = 0.8; % 0.8
parms(61) = 1.9;

parms(62) = 2.3179; 
parms(63) = 0.7446;
parms(64) = 0.8441; 
parms(65) = 0.5210; 
parms(66) = 1;
parms(67) = 1.8965; 

parms(68) = 0; % mesophyll second model
parms(69) = 0; % epidermis thrird

% sc
parms(70) = 0.5; % 0.5
parms(71) = 0.7; % 0.2
parms(72) = 0.3; % 0.5

parms(73) = 0.2; % 0.2
parms(74) = 0.1; % 0.1
parms(75) = 0.1; % 0.1
parms(76) = 0.5; % 0.1

parms(77) = 0.1; % 0.1
parms(78) = 0.3; % 0.3
parms(79) = 0.2; % 0.2
parms(80) = 0.3; % 0.3

parms(81) = 0.4; % 0.4

parms(82) = 0.2; % 0.2
parms(83) = 1; % 1
parms(84) = 0.3; % 0.3
parms(85) = 0.3;
parms(86) = 0.3; 

parms_to_fit_sc = parms;
parms_list{1} = parms_to_fit_sc;
clear parms

% Mesophyll Model

parms(1) = 0.233;
parms(2) = 3.0; %3.0
parms(3) = 1.27;
parms(4) = 0.5;
parms(5) = 5.0;
parms(6) = 1.0;
parms(7) = 7.72;
parms(8) = 8.06;
parms(9) = 7.93;
parms(10) = 8.31; % 1

parms(11) = 0.53;
parms(12) = 0.21;
parms(13) = 0.35;
parms(14) = 0.56;
parms(15) = 0.57;
parms(16) = 0.4;
parms(17) = 0.4;
parms(18) = 0.5;

parms(19) = 0.76;
parms(20) = 0.42;
parms(21) = 1.01;
parms(22) = 0.64;
parms(23) = 0.22; % 0.6
parms(24) = 0.6;
parms(25) = 0.6;
parms(26) = 0.8;
parms(27) = 0.68;
parms(28) = 0.5;
parms(29) = 0.29; % 0.29
parms(30) = 0.48; 
parms(31) = 0.38;
parms(32) = 1.2; % 1.21
parms(33) = 0.38; % 0.38
parms(34) = 0.5;
parms(35) = 0.8;
parms(36) = 0.5;
parms(37) = 0.8;
parms(38) = 0.7;
parms(39) = 0.7;
parms(40) = 0.6;

parms(41) = 2.80;
parms(42) = 0.16; %0.16
parms(43) = 1.18;
parms(44) = 0.5;
parms(45) = 0.2; % 0.24
parms(46) = 0.23; % 0.28
parms(47) = 0.63; % 0.57
parms(48) = 1.73; % 1.73
parms(49) = 0.46;
parms(50) = 0.5; 
parms(51) = 0.6;
parms(52) = 0.3;
parms(53) = 1.9;
parms(54) = 0.3;
parms(55) = 0.5;
parms(56) = 2.0;
parms(57) = 0.3;
parms(58) = 0.5;
parms(59) = 2.0;
parms(60) = 0.8; % 0.8
parms(61) = 1.9;

parms(62) = 2.3179; 
parms(63) = 0.7446;
parms(64) = 0.8441; 
parms(65) = 0.5210; 
parms(66) = 1;
parms(67) = 1.8965; 

parms(68) = 0; % mesophyll to guard cell
parms(69) = 0; % to epidermis

% Starch-Sucrose Metabolism
parms(70) = 5;
parms(71) = 0.2; % 0.2
parms(72) = 0.6;
parms(73) = 0.0023;
parms(74) = 0.02;
parms(75) = 0.06;
parms(76) = 0.012;
parms(77) = 0.02;
parms(78) = 0.5; % 0.23
parms(79) = 0.03;

parms(80) = 1;
parms(81) = 1;
parms(82) = 0.2;
parms(83) = 0.4;
parms(84) = 0.2;
parms(85) = 0.2;
parms(86) = 0.07;

parms(87) = 0.2;
parms(88) = 1;
parms(89) = 0.5;
parms(90) = 0;

parms(91) = 3;
parms(92) = 0.05;
parms(93) = 0.3;

parms_fit_ss = parms;
parms_list{2} = parms_fit_ss;
clear parms

% Epidermis Model 

parms(1) = 7.1751;
parms(2) = 3.0; %3.0
parms(3) = 1.27;
parms(4) = 0.5;
parms(5) = 5.0;
parms(6) = 1.0;
parms(7) = 0.0124;
parms(8) = 9.93;
parms(9) = 0.125;
parms(10) = 0.736; % 1

parms(11) = 0.53;
parms(12) = 0.21;
parms(13) = 0.35;
parms(14) = 0.56;
parms(15) = 0.57;
parms(16) = 0.4;
parms(17) = 0.4;
parms(18) = 0.5;

parms(19) = 0.76;
parms(20) = 0.42;
parms(21) = 1.01;
parms(22) = 0.64;
parms(23) = 0.22; % 0.6
parms(24) = 0.6;
parms(25) = 0.6;
parms(26) = 0.8;
parms(27) = 0.68;
parms(28) = 0.5;
parms(29) = 0.29; % 0.29
parms(30) = 0.48; 
parms(31) = 0.38;
parms(32) = 1.2; % 1.21
parms(33) = 0.38; % 0.38
parms(34) = 0.5;
parms(35) = 0.8;
parms(36) = 0.5;
parms(37) = 0.8;
parms(38) = 0.7;
parms(39) = 0.7;
parms(40) = 0.6;

parms(41) = 2.80;
parms(42) = 0.16; %0.16
parms(43) = 1.18;
parms(44) = 0.5;
parms(45) = 0.2; % 0.24
parms(46) = 0.23; % 0.28
parms(47) = 0.63; % 0.57
parms(48) = 1.73; % 1.73
parms(49) = 0.46;
parms(50) = 0.5; 
parms(51) = 0.6;
parms(52) = 0.3;
parms(53) = 1.9;
parms(54) = 0.3;
parms(55) = 0.5;
parms(56) = 2.0;
parms(57) = 0.3;
parms(58) = 0.5;
parms(59) = 2.0;
parms(60) = 0.8; % 0.8
parms(61) = 1.9;

parms(62) = 2.3179; 
parms(63) = 0.7446;
parms(64) = 0.8441; 
parms(65) = 0.5210; 
parms(66) = 1;
parms(67) = 1.8965; 

parms(68) = 0; % epidermis to gc
parms(69) = 0; % epidermis to mesophyll

% growth
parms(70) = 0.1129;

parms(71) = 0.3322;
parms(72) = 0.86;

parms(73) = 0.5293; % 0.5293

parms(74) = 0.1591;

parms(75) = 0.4404; 
parms(76) = 5.0712;

parms(77) = 0.0005;
parms(78) = 0.18;

parms_fit_growth = parms;
parms_list{3} = parms_fit_growth;
clear parms

% Initial Conditions 
init_cond = [];

LHYm_init = 4.5;
LHYp_init = 4.5;
Pp_init = 3;
P95m_init = 0.9;
P95p_init = 0.9;
P73m_init = 1.5;
P73p_init = 1.5;
P5T1m_init = 0.6;
P5T1p_init = 0.6;
E4m_init = 0.5;
E4p_init = 0.5;
LUXm_init = 0.5;
LUXp_init = 0.5;
E3m_init = 1.3;
E3p_init = 1.3;
EC_init = 0.5;

init_cond_clock = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init];
init_cond = [init_cond,init_cond_clock,init_cond_clock,init_cond_clock];

ABARm_init = 0.3;
ABARp_init = 0.3;
AR_init = 0.2;
PP2C_init = 0.3;
SNRK2_init = 0.3;
SC_init = 0.1;

init_cond_sc = [ABARm_init,ABARp_init,AR_init,PP2C_init,SNRK2_init,SC_init];

Suc_init = 5;
S_prod_init = 0.1;
Suc_sen_init = 1;
Sdr_init = 0.5;
Beta_init = 0.05;
Alpha_init = 0.05;

init_cond_ss = [Suc_init,S_prod_init,Suc_sen_init,Sdr_init,Beta_init,Alpha_init];

PIFm_init = 0.1;
PIFp_init = 0.1;
HYP_init = 0.1;

init_cond_g = [PIFm_init,PIFp_init,HYP_init]; 

init_cond = [init_cond,init_cond_sc,init_cond_ss,init_cond_g];

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480;

[~,v_ldld] = ode15s(@(t,vars_comp)unconnected_spatial_system(t,vars_comp,parms_list, ...
    LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond);
init_cond_upd = v_ldld(end,:);
[t_ldld2,v_ldld2] = ode15s(@(t,vars_comp)unconnected_spatial_system(t,vars_comp,parms_list, ...
    LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_upd);
% clock conditions

plot(t_ldld2,v_ldld2(:,1),t_ldld2,v_ldld2(:,17),t_ldld2,v_ldld2(:,(2*16+1)))
legend("Guard Cell","Mesophyll","Epidermis")
xline([0:24:960],':','HandleVisibility','off');
xline([16:24:960],':','HandleVisibility','off');
xlim([0,72])

save forinputs_coupling.mat t_ldld2 v_ldld2 
% clear workspace
load forinputs_coupling.mat

couplingconstant1 = [0,0.1,0.5,1,2,4];
couplingconstant2 = [0,0.2,1,2,4,8];

couplingvary = coupling_changes(t_ldld2,v_ldld2,couplingconstant1,couplingconstant2);
% Phase Shift Plot 
phase_vals = couplingvary{2};
phase_vals = [couplingconstant1',couplingconstant2',phase_vals];

t = tiledlayout(1,1);
ax1 = axes(t);
phase_p = plot(ax1,phase_vals(:,1),phase_vals(:,3:5),"-o",'LineWidth',1.5,'LineStyle','-.');
phase_p(1).Color = [0.6500,0.1750,0.0980];
phase_p(2).Color = [0.3010,0.88,1];
phase_p(3).Color = [0.95,0.2,0.2];
hold on 
plot(phase_vals(:,1),zeros(1,length(phase_vals(:,1))),"Color","black",'LineWidth',0.6,'LineStyle','--')
ax1.XColor = 'black';
ax1.YColor = 'black';
xlabel("Epidermis-Mesophyll Coupling Strength");
set(gca,'fontname','times')
set(gca,"FontSize",15)
ylim([-1,0.5])
xlim([-0.01,4.01])
ylabel("Phase Shift from the Optimised Clock (hours)")
ax2 = axes(t);
phase_p2 = plot(ax2,phase_vals(:,2),phase_vals(:,3:5),"-o",'LineWidth',1.5,'LineStyle','-.');
phase_p2(1).Color = [0.6500,0.1750,0.0980];
phase_p2(2).Color = [0.3010,0.88,1];
phase_p2(3).Color = [0.95,0.2,0.2];
ax2.XAxisLocation = 'top';
ax2.YAxisLocation = 'left';
xlabel("Epidermis-Guard Cell Coupling Strength");
legend("Guard Cell","Mesophyll","Epidermis")
ax2.Color = 'none';
set(gca,'fontname','times')
set(gca,"FontSize",15)
ax1.Box = 'off';
ax2.Box = 'off';
ylim([-1,0.5])
xlim([-0.02,8.02])
title("(LHY mRNA) Phase Shifts")



% Growth Plot
growth_vals = couplingvary{5};
growth_vals = [couplingconstant1;couplingconstant2;growth_vals];

t = tiledlayout(1,1);
ax1 = axes(t);
plot(ax1,growth_vals(1,:),growth_vals(3,:),"-o","Color",'black','LineWidth',3,'LineStyle','-.')
ax1.XColor = 'black';
ax1.YColor = 'black';
xlabel("Epidermis-Mesophyll Coupling Strength");
set(gca,'fontname','times')
set(gca,"FontSize",15)
ylim([20,25])
xlim([-0.1,4.1])
ax2 = axes(t);
plot(ax2,growth_vals(2,:),growth_vals(3,:),"-o","Color",'black','LineWidth',3,'LineStyle','-.')
ax2.XAxisLocation = 'top';
ax2.YAxisLocation = 'left';
xlabel("Epidermis-Guard Cell Coupling Strength");
ax2.Color = 'none';
set(gca,'fontname','times')
set(gca,"FontSize",15)
ax1.Box = 'off';
ax2.Box = 'off';
ylim([20,25])
xlim([-0.2,8.2])
title("Final Growth")
% old wheat = 1.4786, don't bother adding to plot

% Stomatal Activity
stomata_vals = couplingvary{3};
t = tiledlayout(1,1);
ax1 = axes(t);
plot(ax1,couplingconstant1,stomata_vals(:,1),"-o","Color",[0.3010 0.7450 0.9330], ...
    'LineWidth',3,'LineStyle','-.')
hold on 
plot(ax1,couplingconstant1,stomata_vals(:,2),"-o","Color",[0.4660 0.6740 0.1880], ...
    'LineWidth',3,'LineStyle','-.')
ax1.XColor = 'black';
ax1.YColor = 'black';
xlabel("Guard Cell - Mesophyll Coupling Strength");
set(gca,'fontname','times')
set(gca,"FontSize",15)
ylim([0.25,0.75])
xlim([-0.1,4.1])
legend("Nighttime Stomatal Opening","Daytime Stomatal Opening","Location","east");
ax2 = axes(t);
plot_old_wheat_w = zeros(1,length(couplingconstant2)+2);
plot_old_wheat_w(1:end) = 0.3229;
plot(ax2,[-0.2,couplingconstant2,8.2],plot_old_wheat_w,"Color","red", ...
    'LineWidth',1,'LineStyle',':')
hold on 
plot_old_wheat_p = zeros(1,length(couplingconstant2)+2);
plot_old_wheat_p(1:end) = 0.6089;
plot(ax2,[-0.2,couplingconstant2,8.2],plot_old_wheat_p,"Color","red", ...
    'LineWidth',1,'LineStyle',':')
hold on 
plot(ax2,couplingconstant2,stomata_vals(:,1),"-o","Color",[0.3010 0.7450 0.9330], ...
    'LineWidth',3,'LineStyle','-.')
hold on 
plot(ax2,couplingconstant2,stomata_vals(:,2),"-o","Color",[0.4660 0.6740 0.1880], ...
    'LineWidth',3,'LineStyle','-.')
ax2.XAxisLocation = 'top';
ax2.YAxisLocation = 'left';
xlabel("Guard Cell - Epidermis Coupling Strength");
ax2.Color = 'none';
set(gca,'fontname','times')
set(gca,"FontSize",15)
ax1.Box = 'off';
ax2.Box = 'off';
ylim([0.25,0.75])
xlim([-0.2,8.2])
title("Stomatal Activity")

starch_vals = couplingvary{4};

starch_dev_endofnight = [];

for i = 1:2:11
    
    [~,t_start] = min(abs(starch_vals(:,i)-46));
    [~,t_end] = min(abs(starch_vals(:,i)-48));

    starch_dev = abs((starch_vals(t_end,i+1)-starch_vals(t_start,i+1))/2);

    starch_dev_endofnight = [starch_dev_endofnight,starch_dev];

end 

plot(couplingconstant1,starch_dev_endofnight,"-o","Color","black", ...
    'LineWidth',3,'LineStyle','-.')
hold on 
plot_old_wheat_s = zeros(1,length(couplingconstant1)+2);
plot_old_wheat_s(1:end) = 0.0621;
plot([-0.2,couplingconstant1,8.2],plot_old_wheat_s,"Color","red", ...
    'LineWidth',1,'LineStyle',':');
xlabel("Mesophyll - Guard Cell/Epidermis Coupling Strength");
set(gca,'fontname','times')
set(gca,"FontSize",15)
ylim([0,0.2])
xlim([-0.1,4.1])
title("Absolute Starch Degradation Rate (End of the Night)")


