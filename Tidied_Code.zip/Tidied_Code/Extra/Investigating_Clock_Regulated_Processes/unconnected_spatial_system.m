function solutions = unconnected_spatial_system(t,vars_comp,parms_list,LDLD_or_LDLL,LD_cyc)

solutions = zeros(length(vars_comp),1);

%% L/D activation
if(LD_cyc == "Normal Day")

    LD_cyc_typ = [0,0.5];
    Photosynthesis_term = sind(15*t); % generates oscillations between 0 and 1 over the daylight period

elseif(LD_cyc == "Long Day")

    LD_cyc_typ = [30,0.75];
    Photosynthesis_term = sind(15*t-30) + 0.5;

end

if(LDLD_or_LDLL == "LDLD")

    L = round(0.5*sind(15*t-LD_cyc_typ(1))+LD_cyc_typ(2)); % this means L starts as 1, so a standard LDLD cycle occurs
    D = 1 - L; % So D is always the opposite of L

elseif(LDLD_or_LDLL == "LDLL")

    if(t > 24)
        L = 1;
        D = 0;
    else
        L = round(0.5*sind(15*t-LD_cyc_typ(1))+LD_cyc_typ(2));
        D = 1 - L;
    end

end

% Systems for Each Model
% m = 1 = guard cell model, m = 2 = mesophyll model, m = 3 = epidermis
% model

num_mod = 1:3;

for m = 1:3

    clear vars
    clear parms
    
    %% Extract Correct Parameters
    parms = parms_list{m};

    %% Clock Model Parameters
    par_v1 = parms(1);
    par_v1L = parms(2);
    par_v2A = parms(3);
    parms_v2B = parms(4);
    par_v2L = parms(5);
    par_v3 = parms(6);
    par_v3A = parms(7);
    par_v4 = parms(8);
    par_v5 = parms(9);
    par_v6 = parms(10);

    par_k1L = parms(11);
    par_k1D = parms(12);
    par_k2 = parms(13);
    par_k3 = parms(14);
    par_k4 = parms(15);
    par_k5 = parms(16);
    par_k6 = parms(17);
    par_k7 = parms(18);

    par_p1 = parms(19);
    par_p1L = parms(20);
    par_p2 = parms(21);
    par_p3 = parms(22);
    par_p4 = parms(23);
    par_p5 = parms(24);
    par_p6 = parms(25);
    par_p7 = parms(26);
    par_d1 = parms(27);
    par_d2D = parms(28);
    par_d2L = parms(29);
    par_d3D = parms(30);
    par_d3L = parms(31);
    par_d4D = parms(32);
    par_d4L = parms(33);
    par_d5D = parms(34);
    par_d5L = parms(35);
    par_d6D = parms(36);
    par_d6L = parms(37);
    par_d7D = parms(38);
    par_d7L = parms(39);
    par_dp = parms(40);

    par_K0 = parms(41);
    par_K1 = parms(42);
    par_K2 = parms(43);
    par_K3 = parms(44);
    par_K3act = parms(45);
    par_K4 = parms(46);
    par_K5 = parms(47);
    par_K5b = parms(48);
    par_K6 = parms(49);
    par_K7 = parms(50);
    par_K8 = parms(51);
    par_K9 = parms(52);
    par_K10 = parms(53);
    par_K11 = parms(54);
    par_K12 = parms(55);
    par_K13 = parms(56);
    par_K14 = parms(57);
    par_K15 = parms(58);
    par_K16 = parms(59);
    par_K17 = parms(60);
    par_K18 = parms(61);

    par_w1 = parms(62);
    par_w2 = parms(63);
    par_w3 = parms(64);
    par_w4 = parms(65);
    par_w5 = parms(66);
    par_w6 = parms(67);

    Jlocal_a = parms(68);
    Jlocal_b = parms(69);

    %% Extract Clock Variables
    % Each clock is laid out in order e.g. lhy1, pp1, p961 ... et

    vars = vars_comp((1:16) + (m-1)*16); % total of 16 clock variables per model

    %% Clock Model Variables
    LHY_m = vars(1); % LHY mrna
    LHY_p = vars(2); % LHY protein
    P_p = vars(3); % Dark Accumulator
    P95_m = vars(4); % PRR95 mrna
    P95_p = vars(5); % PRR95 protein
    P73_m = vars(6); % PRR73 mRNA
    P73_p = vars(7); % PRR73 protein
    P5T1_m = vars(8); % PRR59/TOC1 mrna
    P5T1_p = vars(9); % PRR59/TOC1 protein
    E4_m = vars(10); % ELF4 mrna
    E4_p = vars(11); % ELF4 protein
    LUX_m = vars(12); % LUX mRNA
    LUX_p = vars(13); % LUX protein
    E3_m = vars(14); % ELF3 mRNA
    E3_p = vars(15); % ELF3 protein
    EC_p = vars(16); % Evening Complex

    % Load in Other LHYs from the different models for coupling 
    mod_to_load = num_mod(num_mod ~= m);
    LHY_local_a = vars_comp(1+16*(mod_to_load(1)-1));
    LHY_local_b = vars_comp(1+16*(mod_to_load(2)-1));


    %% Non-ODE Equations

    % LHY morning repression activity
    LC = par_w1*LHY_p;
    % PRR5/TOC1 Activity
    P5T1_act = par_w5*P5T1_p;
    % EC Activity
    EC = par_w6*EC_p;

    %% ODEs

    % Change in LHY mRNA
    dLHY_m = (par_v1+par_v1L*L*P_p)/(1+(LC/par_K0)^2+(P95_p/par_K1)^2+(P5T1_act/par_K2)^2+(P73_p/par_K3)^2) - ( ...
        par_k1L*L+par_k1D*D)*LHY_m + (Jlocal_a*(LHY_local_a-LHY_m) + Jlocal_b*(LHY_local_b-LHY_m));
   % dLHY_m = (par_v1+par_v1L*L*P_p)/(1+(LC/par_K0)^2+(P95_p/par_K1)^2+(P5T1_act/par_K2)^2+(P73_p/par_K3)^2) - ( ...
    %    par_k1L*L+par_k1D*D)*LHY_m;
    % Change in LHY protein
    dLHY_p = (par_p1+par_p1L*L)*LHY_m - par_d1*LHY_p;
    % Change in P (dark accumulator) protein
    dP_p = 0.3*(1-P_p)*D - par_dp*P_p*L;
    % Change in PRR9 mRNA
    dP95_m = (par_v2L*L*P_p+par_v2A+parms_v2B*((LC^2)/(par_K3act^2+LC^2)))/(1+(P5T1_act/par_K4)^2+(EC/par_K5)^2+(LC/par_K5b)^2) - ( ...
        par_k2*P95_m);
    % Change in PRR9 protein
    dP95_p = par_p2*P95_m - (par_d2D*D+par_d2L*L)*P95_p;
    % Change in PRR7 mRNA
    dP73_m = (par_v3/(1+(P5T1_act/par_K6)^2+(EC/par_K7)^2+(LC/par_K8)^2) - ( ...
        par_k3*P73_m));
    % Change in PRR7 protein
    dP73_p = par_p3*P73_m - (par_d3D*D+par_d3L*L)*P73_p;
    % Change in PRR5/TOC1 mRNA
    dP5T1_m = par_v4/(1+(LC/par_K9)^2+(P5T1_act/par_K10)^2+(EC/par_K7)^2) - par_k4*P5T1_m;
    % Change in PRR5/TOC1 protein
    dP5T1_p = par_p4*P5T1_m - (par_d4D*D+par_d4L*L)*P5T1_p;
     % Change in ELF4 mRNA
    dE4_m = (par_v5)/(1+(LC/par_K11)^2+(P5T1_act/par_K12)^2+(EC/par_K13)^2) - ( ...
        par_k5*E4_m);
    % Change in ELF4 protein
    dE4_p = par_p5*E4_m - (par_d5D*D+par_d5L*L)*E4_p;
    % Change in LUX mRNA
    dLUX_m = (par_v6)/(1+(LC/par_K14)^2+(P5T1_act/par_K15)^2+(EC/par_K16)^2) - ( ...
        par_k6*LUX_m);
    % Change in LUX
    dLUX_p = par_p6*LUX_m - (par_d6D*D+par_d6L*L)*LUX_p;
    % Change in ELF3 mRNA
    dE3_m = (par_v3A)/(1+(P5T1_p/par_K17)^2+(LC/par_K18)^2) - ( ...
        par_k7*E3_m);
    % Change in ELF3 protein
    dE3_p = par_p7*E3_m - (par_d7D*D+par_d7L*L)*E3_p;
       % Change in Evening Complex
    dEC_p = par_w2*LUX_p*E4_p*(par_w3*E3_p) - par_w4*EC_p;

    solutions((16*(m-1)+1):(16*m)) = [dLHY_m;dLHY_p;dP_p;dP95_m;dP95_p;dP73_m;dP73_p;dP5T1_m;dP5T1_p;
        dE4_m;dE4_p;dLUX_m;dLUX_p;dE3_m;dE3_p;dEC_p];

    if(m == 1)

        %% Stomatal Conductance (SC) Parameters
        par_vsc1 = parms(70); % 0.5
        par_vsc4 = parms(71); % 0.2
        par_vsc4L = parms(72); % 0.5

        par_psc2 = parms(73); % 0.2
        par_psc3 = parms(74); % 0.1
        par_psc5 = parms(75); % 0.1
        par_psc6 = parms(76); % 0.1

        par_Ksc1act = parms(77); % 0.1
        par_Ksc1 = parms(78); % 0.3
        par_Ksc2 = parms(79); % 0.2
        par_Ksc4 = parms(80); % 0.3

        par_msc1 = parms(81); % 0.4

        par_dsc2 = parms(82); % 0.2
        par_dsc3 = parms(83); % 1
        par_dsc4 = parms(84); % 0.3
        par_dsc5 = parms(85); % 0.3
        par_dsc6 = parms(86); % 0.3


        %% SC Variables
        % index after all clock model variables, so first index = 3*16 + 1
        % = 49

        ABAR_m = vars_comp(49);
        ABAR_p = vars_comp(50);
        AR = vars_comp(51);
        PP2C = vars_comp(52);
        SNRK2 = vars_comp(53);
        Stomatal_C = vars_comp(54);

        %% SC Non-ODEs
        ABA = 1;

        %% SC ODEs
        % ABAR mRNA
        dABAR_m = par_vsc1*(LC^2/(par_Ksc1act^2+LC^2))*(1/(1+(P5T1_act/par_Ksc1)^2)) - par_msc1*ABAR_m;
        % ABAR protein
        dABAR_p = par_psc6*ABAR_m - par_dsc6*ABAR_p;
        % ABAR-ABA Complex
        dAR = par_psc5*ABAR_p*ABA - par_dsc5*AR;
        % PP2C protein
        dPP2C = par_psc2/(1+(AR/par_Ksc2)^2) - par_dsc2*PP2C;
        % SNRK2 protein
        dSNRK2 = par_psc3 - par_dsc3*PP2C*SNRK2;
        % Stomatal Conductance
        dStomatal_C = ((par_vsc4+par_vsc4L*L)/(1+(SNRK2/par_Ksc4)^2))*(1-Stomatal_C) - par_dsc4*Stomatal_C;

        solutions(49:54) = [dABAR_m;dABAR_p;dAR;dPP2C;dSNRK2;dStomatal_C];

    elseif(m == 2)

        %% Photosynthesis and Starch Usage (P+SC) Parameters
        par_ppsu1 = parms(70); % 5
        par_ppsu2 = parms(71); % 0.55
        par_ppsu3 = parms(72); % 0.6
        par_ppsu4 = parms(73); % 0.0023
        par_ppsu5 = parms(74); % 0.02
        par_ppsu6 = parms(75); % 0.06
        par_ppsu7 = parms(76); % 0.012
        par_ppsu8 = parms(77); % 0.02
        par_ppsu9 = parms(78); % 0.23
        par_ppsu10 = parms(79); % 0.03

        par_Kpsu1 = parms(80); % 1
        par_Kpsu2 = parms(81); % 1
        par_Kpsu3 = parms(82); % 0.2
        par_Kpsu4 = parms(83); % 0.4
        par_Kpsu4act = parms(84); % 0.2
        par_Kpsu5 = parms(85); % 0.2
        par_Kpsu6 = parms(86); % 0.07

        par_dpsu3 = parms(87); % 0.2
        par_dpsu4 = parms(88); % 1
        par_dpsu5 = parms(89); % 0.5
        par_dpsu6 = parms(90); % 0

        par_gpsu1 = parms(91); % 3
        par_gpsu2 = parms(92);
        par_gpsu3 = parms(93);

        %% P+SC Variables
        Sucrose = vars_comp(55);
        Starch = vars_comp(56);
        Suc_sensor = vars_comp(57);
        S_deg_regulator = vars_comp(58);
        Beta = vars_comp(59);
        Alpha = vars_comp(60);

        %% P+SC Non-ODEs
        Photosynthesis = par_ppsu1*L*Photosynthesis_term;
        F_Alpha_plus = (par_ppsu7+par_ppsu8+par_ppsu9*L*P_p)/(1+(LC/par_Kpsu5)^2);
        F_Alpha_minus = (par_ppsu10+D)/(1+(P95_p/par_Kpsu6)^2);

        %% P+SC ODEs
        % Sucrose Availibity
        dSucrose = par_ppsu9*Starch*(par_dpsu6+S_deg_regulator*D) + (1-par_ppsu2)*Photosynthesis - par_gpsu1*Sucrose*(par_gpsu2+par_gpsu3*D);
        % Starch Production
        dStarch = par_ppsu2*Photosynthesis - par_ppsu9*Starch*(par_dpsu6+S_deg_regulator*D);
        % Carbon Availibility/Sucrose Sensor
        dSuc_sensor = par_ppsu3*Beta*(1-(Sucrose^3/(Sucrose^3+par_Kpsu1^3))) - par_dpsu3*Suc_sensor;
        % Starch Degradation
        dS_deg_regulator = par_ppsu4*Alpha*Starch*L*(1+par_Kpsu2/(1+(Suc_sensor/par_Kpsu3)^2) ...
            ) - par_dpsu4*L*S_deg_regulator;
        % Beta
        dBeta = par_ppsu5/(1+(P5T1_act/par_Kpsu4)^2) + par_ppsu6*((LC^2)/(LC^2+par_Kpsu4act^2)) - par_dpsu5*Beta*L;
        % Alpha
        dAlpha = F_Alpha_plus - F_Alpha_minus*Alpha;


        solutions(55:60) = [dSucrose;dStarch;dSuc_sensor;dS_deg_regulator;dBeta;dAlpha];

    elseif(m == 3)

        %% Growth Parameters
        par_vg1 = parms(70); % 0.1129

        par_Kg1 = parms(71); % 0.3322
        par_Kg2act = parms(72); % 0.86

        par_pg1 = parms(73); % 0.5293

        par_mg1 = parms(74); % 0.1591

        par_dg1D = parms(75); % 0.4404
        par_dg1L = parms(76); % 5.0712

        par_g1 = parms(77); % 0.001
        par_g2 = parms(78); % 0.18

        %% Growth Variables
        PIF_m = vars_comp(61);
        PIF_p = vars_comp(62);
        Hyp_Elongation = vars_comp(63);

        %% Growth ODEs
        % PIF4 mRNA
        dPIF_m = par_vg1/(1+(EC/par_Kg1)^2) - par_mg1*PIF_m;
        % PIF4 protein
        dPIF_p = par_pg1*PIF_m - (par_dg1D*D+par_dg1L*L)*PIF_p;
        % Hypocotyl Elongation/Growth
        dHYP = par_g1 + par_g2*((PIF_p^2)/(par_Kg2act^2+PIF_p^2));

        solutions(61:63) = [dPIF_m;dPIF_p;dHYP];

    end

end