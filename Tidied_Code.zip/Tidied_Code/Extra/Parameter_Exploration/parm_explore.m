function time_until_dawn = parm_explore(model,parm_init,parms_ind,parmset1,parmset2,init_cond,t_end)
% Function for exploring ELF3 activity (difference in peak timing to dawn)
% through varying parameter values for LHY activity and ELF3 activity in
% the EC

% model = wheat model used for simulations, @wheat_wt or @wheat_wt_large
% parms_init = complete set of initial parameter values 
% parms_ind = indices for parameters being varied (within parms_init array)
% parmset1 = parameter values evaluated for parameter 1 (e.g. LHY
% activity)
% parmset2 = parameter values evaluated for parameter 2 (e.g. ELF3
% activity)
% init_cond = intial variable values
% t_end = simulation run time

model_name = func2str(model);

time_until_dawn = [];

LD_cyc= "Long Day";

% for each parameter value combination

for p1 = parmset1

    for p2 = parmset2

        %% Find difference in ELF3 peak timing from dawn
        
        clear parms
        parms = parm_init;
        parms(parms_ind(1)) = p1;
        parms(parms_ind(2)) = p2;

        % run simulations
        LDLD_or_LDLL = "LDLD";
        [~,v_m_ldld] = ode15s(@(t,vars)model(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond);
        init_cond_upd = v_m_ldld(end,:);

        LDLD_or_LDLL = "LDLL";
        [t_m_out,v_m_out] = ode15s(@(t,vars)model(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_upd);

        % get data from first 24h (before peak starts shifting from dawn
        % due to period lengthening)
        data_needed_t = t_m_out(t_m_out <= 24);

        % extract ELF3 mRNA data from model output
        if(model_name == "wheat_wt")
            data_needed_v = v_m_out(:,14);
        elseif(model_name == "wheat_wt_large")
            data_needed_v = v_m_out(:,19);
        end

        % get ELF3 mRNA data for first 24h 
        data_needed_v = data_needed_v(t_m_out <= 24);

        % find ELF3 peak time
        [~,peaks_pos] = findpeaks(data_needed_v);
        peak_times = data_needed_t(peaks_pos)';

        % check - make sure clock is still oscillating by the end of
        % simulations, so that the parameter value combination isn't
        % inducing a clock LoF phenotype (not interested in such results)
        [~,osc_check_t] = min(abs(t_m_out-(t_end-12)));
        still_oscillating = (v_m_out(end,1) - v_m_out(osc_check_t,1))/12;


        if(length(peak_times) == 1 && still_oscillating ~= 0) % if ELF3 peaks within first 24h (not ultra long period) and the clock is still oscillating

            % calculate difference in timing of ELF3 peak from dawn
            t_f_dawn = 24 - peak_times;

            %% Check for variation in ELF3 peak times, make sure it is not a photo-period insensitive mutant 
            
            % run LDLD simulation for time = 120, LDLL irrevelant since
            % only first 24h are used 
            LDLD_or_LDLL = "LDLD";
            [~,v_m_ld_rt] = ode15s(@(t,vars)model(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,120],init_cond);
            init_cond_upd2 = v_m_ld_rt(end,:);

            LDLD_or_LDLL = "LDLL";
            [t_m_rt,v_m_rt] = ode15s(@(t,vars)model(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,120],init_cond_upd2);

            % Get data for find peak timings
            data_needed_t2 = t_m_rt(t_m_rt <= 24);

            % run LDLD simulation for time = 240
            LDLD_or_LDLL = "LDLD";
            [~,v_m_ld_rt2] = ode15s(@(t,vars)model(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,240],init_cond);
            init_cond_upd3 = v_m_ld_rt2(end,:);

            LDLD_or_LDLL = "LDLL";
            [t_m_rt2,v_m_rt2] = ode15s(@(t,vars)model(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,120],init_cond_upd3);

            % Get data for find peak timings
            data_needed_t3 = t_m_rt2(t_m_rt2 <= 24);

            % get ELF3 data
            if(model_name == "wheat_wt")
                data_needed_v2 = v_m_rt(:,14);
                data_needed_v3 = v_m_rt2(:,14);
            elseif(model_name == "wheat_wt_large")
                data_needed_v2 = v_m_rt(:,19);
                data_needed_v3 = v_m_rt2(:,19);
            end

            data_needed_v2 = data_needed_v2(t_m_rt <= 24);
            data_needed_v3 = data_needed_v3(t_m_rt2 <= 24);

            % calculate peak timings 
            [~,peaks_pos2] = findpeaks(data_needed_v2);
            peak_times2 = data_needed_t2(peaks_pos2)';
            t_f_dawnr = 24 - peak_times2;
            [~,peaks_pos3] = findpeaks(data_needed_v3);
            peak_times3 = data_needed_t3(peaks_pos3)';
            t_f_dawnr2 = 24 - peak_times3;

            % calculate range of peak timings when LDLD is run for 120h,
            % 240h and t_endh - if the clock is not photoperiod-insenstive,
            % the range should be 0 (but we will include phenotypes with
            % very low variation too)
            range_test = range([t_f_dawn,t_f_dawnr,t_f_dawnr2]);
            
            % output
            time_until_dawn = [time_until_dawn;[p1,p2,t_f_dawn,range_test]];

        else

            % output for clock LoF or period lengthening mutant
            time_until_dawn = [time_until_dawn;[p1,p2,NaN,NaN]];

        end

    end

end








