function cost = cost_function_mga(data_in,times_i,sol_i,var_correspond)
% Objective/Cost Function for the Genetic Algorithm
% 2 objectives: minimise the mean square difference between experimental
% and simulated peaks from wt data/model; barrier function to ensure the clock keeps
% oscillating enough 

objective_pk = []; % initialise vector for 2 objective functions

for  var = var_correspond(2,:)                


    obj_pk = [];

    % Get data corresponding to a specific clock component/variable from
    % experimental and model data
    corr_v_ind = var_correspond(1,var_correspond(2,:) == var);
    sub_data = data_in(data_in(:,2) == corr_v_ind,:); 
    sim_data = sol_i(:,var); 

    %% Peak Timings

    % Find peak timings
    [~,peaks_wheat] = findpeaks(sim_data);
    peak_times_sim = times_i(peaks_wheat);

    % Find the absolute difference in peak timings between simulated and
    % experimetnal data
    peak_diffs = [];
    
    for rep = unique(data_in(:,1))' % iterate over each experimental repeat
        
        data_rep = sub_data(sub_data(:,1) == rep,:);
        
        for p = 1:height(data_rep)
            
            [~,c_p_ind] = min(abs(peak_times_sim - data_rep(p,3))); % find distance between the 2 closest peaks (1 from experiments, other from simulations)
            closest_peak = peak_times_sim(c_p_ind);
            closest_peak = closest_peak(1);

            p_diff = sqrt((closest_peak-data_rep(p,3))^2); % find mean square/absolute difference 
            
            peak_diffs = [peak_diffs,p_diff];

        end 

    end 

   obj_pk = mean(peak_diffs); % get average difference in peak timings for a given repeat
   objective_pk = [objective_pk,obj_pk];

end 

%% Keep LHY/clock oscillating
[~,end_12_from] = min(abs(times_i - (times_i(end)-12))); % get data from the final 12h of simulations
dycond_dt = (sol_i(end,1)-sol_i(end_12_from,1))/12; % get dy/dt between end time point and 12h before - gradient should not be 0 if oscillating
dycond_dt_term = abs(dycond_dt) + 10^-70; % if it is 0, means it can still be plugged into the cost function without causing a math error 
cost_osc = abs((1/6)*(-log(dycond_dt_term))); % goes exponteital only when gradient is VERY close to 0 aka the clock has stopped oscillating. 
           
cost = [sum(objective_pk),cost_osc]; % cost(1) = sum of average peak difference over repeats and variables
