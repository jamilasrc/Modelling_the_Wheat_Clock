function outputs = parms_test_ga(parameters,model,parm_ind,parms_init,data_in,var_correspond_wt,init_cond_wt)
% Objective/Cost Function for the Genetic Algorithm
% 2 objectives: minimise the mean square difference between experimental
% and simulated peaks from wt data/model; barrier function to ensure the clock keeps
% oscillating enough 

% Parameters = parameter set being optimised
% model = model being optimised over: @wheat_wt or @wheat_wt_large
% parm_ind = indices of parameters being optimised 
% parms_init = all model parameters, initial values before optimisation 
% data_in = experimental data on peak timings
% var_correpsond_wt = index of a given componet in experimental data frame
% and model solution outputs (e.g. LHY index = 3 for experimental datasets,
% = 1 for the models)
% init_cond_wt = initial variable values/condition


%% Running Simulations with a Parameter Set
parms = parms_init;
parms(parm_ind) = parameters;

data = data_in;

init_conditions_wheatwt = init_cond_wt;

LDLD_or_LDLL = "LDLD";
% LD_cyc_typ = "Long Day";
% LD_cyc_typ = "Normal Day";
t_end = 480;

[~,sol_init_LD] = ode15s(@(t,vars)model(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_conditions_wheatwt);
init_cond_upd = sol_init_LD(end,:);

LDLD_or_LDLL = "LDLL";
[times_i,sol_i] = ode15s(@(t,vars)model(t,vars,parms,LDLD_or_LDLL,LD_cyc_typ),[0,t_end],init_cond_upd);

cost_wt = cost_function_mga(data,times_i,sol_i,var_correspond_wt);
           
outputs = cost_wt;
disp(outputs)

end 